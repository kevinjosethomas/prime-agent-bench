#!/bin/bash
# The arm's parked-children A/B census v4: ABBA (B=base 28107df4f, C=candidate a0ae6f1a0),
# sha-asserted per leg, fresh mock provider PER LEG (the cursor-carry trap), spawn-verified
# legs (a failed leg aborts + retries once), probe_v09 pre/mid/post around the battery.
set -uo pipefail
cd /root/bench-harness
export CENSUS_MOCK_PORT=8901
PY=python3
LANE=/root/lane
OUT=/root/idleb
BASE=/root/base-src/target/release/prime-agent
CAND=/root/arm-src/target/release/prime-agent
run_leg() {
  local trial=$1 bin=$2 sha=$3 out=$4
  for attempt in 1 2; do
    pkill -f bench.drivers.mock_provider 2>/dev/null; sleep 1
    $PY $LANE/parked_census.py /root/idleb/$trial $bin rust $out 8 1 $sha 2>&1 | tail -4
    if $PY -c "import json,sys; d=json.load(open('$out')); sys.exit(0 if 'error' not in d or not d.get('error') else 1)" 2>/dev/null; then
      return 0
    fi
    echo "leg $trial attempt $attempt failed; retrying"
    pkill -f bench.drivers.mock_provider; sleep 1
  done
  echo "leg $trial FAILED twice"
  return 1
}
echo "=== ARM ABBA CENSUS v4 START $(date -u +%Y-%m-%dT%H:%M:%SZ) ==="
sha256sum $BASE $CAND | tee $OUT/arm-v4-binary-shas.txt
mkdir -p /root/probe-v09
echo "--- probe pre" | tee $OUT/arm-v4-probe-pre.txt
$PY $LANE/probe_v09.py /root/probe-v09 pre 20 >> $OUT/arm-v4-probe-pre.txt 2>&1 || echo "probe pre failed" >> $OUT/arm-v4-probe-pre.txt
run_leg trial-ab-b1 $BASE  9e35d59bd713a95977618f3ab5c34109ef6219ff5aa6e4f27a45175808f4f050 $OUT/census-ab-b1.json
run_leg trial-ab-c1 $CAND  b0ee13d8376459774e337b4fd07d318493908db527c5350b331f64b51bb4653a $OUT/census-ab-c1.json
run_leg trial-ab-c2 $CAND  b0ee13d8376459774e337b4fd07d318493908db527c5350b331f64b51bb4653a $OUT/census-ab-c2.json
echo "--- probe mid" | tee $OUT/arm-v4-probe-mid.txt
$PY $LANE/probe_v09.py /root/probe-v09 mid 20 >> $OUT/arm-v4-probe-mid.txt 2>&1 || echo "probe mid failed" >> $OUT/arm-v4-probe-mid.txt
run_leg trial-ab-b2 $BASE  9e35d59bd713a95977618f3ab5c34109ef6219ff5aa6e4f27a45175808f4f050 $OUT/census-ab-b2.json
echo "--- probe post" | tee $OUT/arm-v4-probe-post.txt
$PY $LANE/probe_v09.py /root/probe-v09 post 20 >> $OUT/arm-v4-probe-post.txt 2>&1 || echo "probe post failed" >> $OUT/arm-v4-probe-post.txt
pkill -f bench.drivers.mock_provider 2>/dev/null
echo "=== ARM ABBA CENSUS v4 DONE $(date -u +%Y-%m-%dT%H:%M:%SZ) ==="
