#!/usr/bin/env python3
"""Wave-6 idle-rebaseline: the parked-children census + idle wake/RSS probe.

One trial: boot the staged binary (rust tip or official TS 0.9.6) in daemon
mode with the offline mock provider; create a parent session; spawn K RLM
children through the parent's kernel (rlm.spawn), each child running an
ipython cell (kernel boots, marker set) then settling; then a fixed
wall-clock schedule of census + wake windows:

  t0            children settled -> CENSUS-1 + WAKE-1 (the settle floor)
  t0 + 150s     CENSUS-2 + WAKE-2 (TS tier-1 passivation window, 1-min
                idleEvictionMinutes + 60s sweep cadence)
  disconnect    (the owner client detaches; TS tier-2 whole-worker
                eviction window opens)
  t0 + 300s     CENSUS-3 + WAKE-3 (the post-eviction tree)
  revival       prompt child-1 (READ-MARK) -> latency + census; prompt
                parent (REVIVE-PARENT) -> latency + census

Every process row: RSS (statm), PSS (smaps_rollup), utime/stime, and the
per-thread voluntary/nonvoluntary context-switch deltas for each wake
window. A `sleep 600` noop control rides every window. Raw wire responses
for get_rlm_children/list are logged to the trial record (the #2983
driver's empty-children observation is re-checked live, not trusted).

Harness only; not part of any product.
Usage: parked_census.py <trial-dir> <binary> <role rust|ts> <out.json> [K] [idle_minutes]
"""
import json, os, pathlib, select, shutil, socket, subprocess, sys, time

MOCK_PORT = int(os.environ.get("CENSUS_MOCK_PORT", "8890"))
WAKE_WINDOW_S = 120.0
MARK2_S = 150.0
MARK3_S = 360.0
SETTLE_GRACE_S = 12.0


def write_agent_dir(agent: pathlib.Path, base: str):
    agent.mkdir(parents=True, exist_ok=True)
    models = {"providers": {"prime-inference": {
        "api": "openai-completions", "baseUrl": base, "apiKey": "sk-bench",
        "models": [{"id": "mock-1", "name": "Mock 1", "api": "openai-completions",
                    "baseUrl": base, "contextWindow": 128000, "maxTokens": 4096}]}}}
    (agent / "models.json").write_text(json.dumps(models, indent=1))


def write_settings(home: pathlib.Path, agent: pathlib.Path, idle_minutes):
    """The idleEvictionMinutes surface (the product's own global daemon
    policy; a settings value, not a clock hack). Written to BOTH the agent
    dir (PRIME_AGENT_CODING_AGENT_DIR is the live config root under the
    harness env override) and the default ~/.prime/agent layout."""
    for d in (agent, home / ".prime" / "agent"):
        d.mkdir(parents=True, exist_ok=True)
        s = d / "settings.json"
        cur = {}
        if s.exists():
            try:
                cur = json.loads(s.read_text())
            except ValueError:
                cur = {}
        # The setting is a NUMBER or "off" (the product's TS-parity
        # parse: a string number falls to the default) — write the int.
        value = idle_minutes
        if value not in ("off", "none"):
            try:
                value = int(value)
            except ValueError:
                pass
        cur["idleEvictionMinutes"] = value
        s.write_text(json.dumps(cur, indent=1))
    d = home / ".prime" / "agent"
    s = d / "settings.json"


def mock_script(k: int) -> dict:
    spawn_cell = (
        "import rlm\n"
        "hs = []\n"
        + "".join(
            f"hs.append(await rlm.spawn('Child task {i}: run the census cell. Prompt token: CHILD-{i}-MARK.', name='census-child-{i}'))\n"
            for i in range(1, k + 1))
        + "hs")
    # Order matters: pick() serves the FIRST queue whose match strings are
    # all present in the concatenated USER text. A revived child's request
    # still contains its spawn prompt (CHILD-i-MARK), so the revival queues
    # must precede the child queues.
    queues = [{
        "name": "revive-parent", "match": ["REVIVE-PARENT"],
        "responses": [{"text": "parent revived: the turn served"}]},
        {"name": "revive-child", "match": ["READ-MARK"],
         "responses": [
             {"toolCall": {"id": "call_r1", "name": "ipython",
                           "arguments": {"code": "marker_1"}}},
             {"text": "revived: the marker served"}]},
        {"name": "parent", "match": ["GO-SPAWN"],
        "responses": [
            {"toolCall": {"id": "call_p1", "name": "ipython",
                          "arguments": {"code": spawn_cell}}},
            {"text": "spawned; waiting for the settle"}]}]
    for i in range(1, k + 1):
        queues.append({
            "name": f"child-{i}", "match": [f"CHILD-{i}-MARK"],
            "responses": [
                {"toolCall": {"id": f"call_c{i}", "name": "ipython",
                              "arguments": {"code": f"marker_{i} = {i}\nmarker_{i}"}}},
                {"text": f"child {i}: the cell ran; the kernel holds the marker"}]})
    return {"responses": [{"text": "acknowledge."}], "queues": queues}


def parent_of(pid):
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("PPid:"):
                    return int(line.split()[1])
    except OSError:
        pass
    return None


def tree_rows(root_pid: int, extra_roots=()):
    """The daemon's descendants with role attribution, RSS + PSS."""
    by_parent = {}
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        pp = parent_of(int(pid))
        if pp is not None:
            by_parent.setdefault(pp, []).append(int(pid))
    rows = []
    def walk(pid, depth):
        for child in sorted(by_parent.get(pid, [])):
            try:
                with open(f"/proc/{child}/cmdline", "rb") as f:
                    cmd = f.read().decode(errors="replace").replace("\x00", " ").strip()
                with open(f"/proc/{child}/statm") as f:
                    rss_pages = int(f.read().split()[1])
                pss = None
                try:
                    with open(f"/proc/{child}/smaps_rollup") as f:
                        for line in f:
                            if line.startswith("Pss:"):
                                pss = int(line.split()[1])
                                break
                except OSError:
                    pass
                argv = cmd.split()
                cls = "kernel-python" if "python" in argv[0] else "other"
                if "prime-agent" in cmd or cmd.endswith("bin-rust") or cmd.endswith("bin-ts"):
                    cls = "prime-agent"
                role = "daemon-child"
                if cls == "prime-agent" and depth == 1:
                    role = "worker"
                elif cls == "prime-agent" and depth == 2:
                    role = "child-worker"
                rows.append({"pid": child, "ppid": pid, "depth": depth, "class": cls,
                             "role": role,
                             "rss_mb": round(rss_pages * 4096 / (1 << 20), 1),
                             "pss_kb": pss, "cmd": " ".join(argv)[:140]})
            except (OSError, IndexError, ValueError):
                continue
            walk(child, depth + 1)
    walk(root_pid, 1)
    for r in extra_roots:
        walk(r, 1)
    return rows


def counters(pid):
    """utime/stime ticks + per-thread ctxt switches for one process."""
    try:
        with open(f"/proc/{pid}/stat", "rb") as f:
            s = f.read().decode(errors="replace")
        after = s[s.rfind(")") + 2:].split()
        utime, stime = int(after[11]), int(after[12])
    except (OSError, ValueError, IndexError):
        return None
    vol = nonvol = 0
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("voluntary_ctxt_switches:"):
                    vol = int(line.split()[1])
                elif line.startswith("nonvol_ctxt_switches:"):
                    nonvol = int(line.split()[1])
    except OSError:
        pass
    threads = {}
    try:
        for tid in os.listdir(f"/proc/{pid}/task"):
            tvol = tnon = 0
            try:
                with open(f"/proc/{pid}/task/{tid}/status") as f:
                    for line in f:
                        if line.startswith("voluntary_ctxt_switches:"):
                            tvol = int(line.split()[1])
                        elif line.startswith("nonvol_ctxt_switches:"):
                            tnon = int(line.split()[1])
            except OSError:
                continue
            threads[tid] = {"vol": tvol, "nonvol": tnon}
    except OSError:
        pass
    return {"utime": utime, "stime": stime, "vol": vol, "nonvol": nonvol,
            "threads": threads}


def wake_window(pids, seconds):
    """Endpoint-only sampling: snapshot counters, sleep, snapshot again."""
    before = {p: counters(p) for p in pids}
    t0 = time.monotonic()
    time.sleep(seconds)
    dt = time.monotonic() - t0
    after = {p: counters(p) for p in pids}
    out = []
    for p in pids:
        a, b = before.get(p), after.get(p)
        if not a or not b:
            continue
        ticks = (b["utime"] + b["stime"]) - (a["utime"] + a["stime"])
        vol = b["vol"] - a["vol"]
        trows = []
        for tid, ta in a["threads"].items():
            tb = b["threads"].get(tid)
            if tb:
                d = tb["vol"] - ta["vol"]
                if d:
                    trows.append({"tid": int(tid), "vol": d,
                                  "nonvol": tb["nonvol"] - ta["nonvol"]})
        trows.sort(key=lambda r: -r["vol"])
        # /proc/PID/status ctxt counters are the LEADER THREAD's; the true
        # process wake rate is the sum over its threads.
        tsum = sum(r["vol"] for r in trows)
        tsum_nonvol = sum(r["nonvol"] for r in trows)
        try:
            cmd = open(f"/proc/{p}/cmdline", "rb").read().decode(errors="replace").replace("\x00", " ").strip()[:100]
        except OSError:
            cmd = ""
        out.append({"pid": p, "cmd": cmd, "cpu_ms": round(ticks * 1000.0 / 100.0, 1),
                    "wakeups_leader": vol, "wakeups_leader_per_s": round(vol / dt, 2),
                    "wakeups_thread_sum": tsum,
                    "wakeups_thread_sum_per_s": round(tsum / dt, 2),
                    "nonvol": b["nonvol"] - a["nonvol"],
                    "nonvol_thread_sum": tsum_nonvol,
                    "threads": trows})
    tot_leader = sum(r["wakeups_leader"] for r in out)
    tot_threads = sum(r["wakeups_thread_sum"] for r in out)
    return {"window_s": round(dt, 1), "processes": out,
            "tree_wakeups_leader_per_s": round(tot_leader / dt, 2),
            "tree_wakeups_thread_sum_per_s": round(tot_threads / dt, 2)}


class Conn:
    def __init__(self, path):
        self.sock = socket.socket(socket.AF_UNIX)
        self.sock.connect(str(path))
        self.buf = b""
        self.frames = []

    def read_frames(self, timeout_s):
        fd = self.sock.fileno()
        os.set_blocking(fd, False)
        t0 = time.monotonic()
        while time.monotonic() - t0 < timeout_s:
            ready, _, _ = select.select([fd], [], [], 0.05)
            if ready:
                chunk = os.read(fd, 1 << 20)
                if chunk:
                    self.buf += chunk
                while b"\n" in self.buf:
                    raw, self.buf = self.buf.split(b"\n", 1)
                    if raw.strip():
                        try:
                            self.frames.append(json.loads(raw))
                        except ValueError:
                            pass

    def send(self, command):
        envelope = {"type": "command", "id": command.get("id", "e1"),
                    "protocol": {"name": "prime-agent.daemon", "version": 7},
                    "clientId": "parked-census-client",
                    "command": command}
        self.sock.sendall((json.dumps(envelope) + "\n").encode())

    def recv(self, rid, timeout_s=60.0):
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            before = len(self.frames)
            self.read_frames(0.05)
            for obj in self.frames[before:]:
                if obj.get("type") == "response" and obj.get("id") == rid:
                    return obj
            time.sleep(0.02)
        raise TimeoutError(f"no response for {rid}")

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


def main():
    trial = pathlib.Path(sys.argv[1]).resolve()
    binary = sys.argv[2]
    role = sys.argv[3]
    out_path = sys.argv[4]
    k = int(sys.argv[5]) if len(sys.argv) > 5 else 8
    idle_minutes = sys.argv[6] if len(sys.argv) > 6 else "1"
    expected_sha = sys.argv[7] if len(sys.argv) > 7 else None

    if trial.exists():
        shutil.rmtree(trial)
    trial.mkdir(parents=True)
    # the offline mock provider on 8890 (the harness module; live-reload script)
    mock_path = pathlib.Path("/root/idleb/mock-census.json")
    mock_path.parent.mkdir(parents=True, exist_ok=True)
    mock_path.write_text(json.dumps(mock_script(k), indent=1))
    try:
        with socket.create_connection(("127.0.0.1", MOCK_PORT), timeout=0.5):
            mock_live = True
    except OSError:
        mock_live = False
    if not mock_live:
        mlog = open("/root/idleb/mock-provider.log", "ab")
        subprocess.Popen([sys.executable, "-m", "bench.drivers.mock_provider",
                          str(mock_path), str(MOCK_PORT)],
                         cwd="/root/bench-harness", stdout=mlog, stderr=mlog)
        time.sleep(1.0)
    write_agent_dir(trial / "agent", f"http://127.0.0.1:{MOCK_PORT}/v1")
    write_settings(trial / "home", trial / "agent", idle_minutes)
    (trial / "home").mkdir(exist_ok=True)
    (trial / "tmp").mkdir()
    sock = trial / "d.sock"

    venvs = json.load(open("/root/idleb-trials/venv-envs.json"))
    env = {"HOME": str(trial / "home"), "TMPDIR": str(trial / "tmp"),
           "PRIME_AGENT_CODING_AGENT_DIR": str(trial / "agent"),
           "PRIME_API_KEY": "sk-bench", "PRIME_TEAM_ID": "bench-team",
           "RUST_LOG": "error",
           "PATH": "/root/.cargo/bin:/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"}
    env.update(venvs[role]["env"])

    log = open(trial / "daemon.out", "wb")
    proc = subprocess.Popen([binary, "--mode", "daemon", "--daemon-socket", str(sock)],
                            env=env, cwd=str(trial), stdout=log, stderr=subprocess.STDOUT)
    deadline = time.time() + 40
    while not sock.exists() and time.time() < deadline:
        time.sleep(0.1)
    if not sock.exists():
        json.dump({"error": "daemon socket never appeared", "role": role},
                  open(out_path, "w"), indent=1)
        proc.kill()
        return

    noop = subprocess.Popen(["sleep", "600"])
    binary_sha = subprocess.run(["sha256sum", binary], capture_output=True,
                                 text=True).stdout.split()[0]
    if expected_sha and binary_sha != expected_sha:
        json.dump({"error": f"binary sha mismatch: {binary_sha} != expected {expected_sha}"},
                  open(out_path, "w"), indent=1)
        return
    rec = {"role": role, "k": k, "idle_eviction_minutes_setting": idle_minutes,
           "trial": str(trial), "binary": binary,
           "binary_sha256": binary_sha,
           "settings_file": (trial / "home" / ".prime" / "agent" / "settings.json").read_text(),
           "stages": {}, "raw": {}}
    conn = Conn(sock)
    conn.read_frames(5)

    # parent session
    conn.send({"type": "create", "id": "cr1", "config": {
        "provider": "prime-inference", "model": "mock-1", "cwd": str(trial)}})
    resp = conn.recv("cr1", 120)
    rec["raw"]["create"] = {k2: resp.get(k2) for k2 in ("success", "error")}
    data = resp.get("data") or {}
    parent_id = (data.get("session") or {}).get("activeSessionId") or data.get("activeSessionId")
    rec["parent_active_session_id"] = parent_id
    if not parent_id:
        rec["error"] = "create failed"
        json.dump(rec, open(out_path, "w"), indent=1)
        teardown(proc, conn, noop)
        return

    # spawn turn
    t_send = time.monotonic()
    conn.send({"type": "prompt_and_wait", "id": "p1",
               "activeSessionId": parent_id, "message": "GO-SPAWN"})
    resp = conn.recv("p1", 400 if k else 120)
    rec["stages"]["parent_spawn_turn"] = {
        "success": resp.get("success"),
        "prompt_to_done_s": round(time.monotonic() - t_send, 2)}

    # settle: children done (poll roster raw) + grace
    deadline = time.monotonic() + 150
    roster = None
    while time.monotonic() < deadline:
        conn.send({"type": "get_rlm_children", "id": "rc1", "activeSessionId": parent_id})
        r = conn.recv("rc1", 30)
        roster = r.get("data")
        txt = json.dumps(roster)
        if txt.count("sessionId") >= k or txt.count('"done"') >= k:
            break
        time.sleep(1.0)
    rec["raw"]["get_rlm_children_settle"] = roster
    # The leg's validity gate: K children must exist. A leg whose spawns
    # never happened (a mock/provider mismatch) aborts loudly instead of
    # recording an empty census as a pass.
    n_children = 0
    if isinstance(roster, dict):
        rows = roster.get("children") or []
        n_children = len([r for r in rows if isinstance(r, dict)])
    if n_children < k:
        rec["error"] = f"spawn verification failed: {n_children}/{k} children in the roster"
        json.dump(rec, open(out_path, "w"), indent=1)
        teardown(proc, conn, noop)
        return
    time.sleep(SETTLE_GRACE_S)

    def census_point(name):
        rows = tree_rows(proc.pid, extra_roots=[noop.pid])
        loadavg = open("/proc/loadavg").read().strip()
        rec["stages"][name] = {"census": rows, "loadavg": loadavg,
                               "t_monotonic": round(time.monotonic() - t0_ref, 1)}

    def wake_point(name):
        pids = [proc.pid, noop.pid] + [r["pid"] for r in tree_rows(proc.pid)]
        rec["stages"][name] = wake_window(sorted(set(pids)), WAKE_WINDOW_S)

    t0_ref = time.monotonic()
    census_point("census_1_settle")
    wake_point("wake_1_settle")

    # ---- mark 2 (+150s): the TS tier-1 passivation window ----
    while time.monotonic() - t0_ref < MARK2_S:
        time.sleep(2.0)
    census_point("census_2_idle150")
    wake_point("wake_2_idle150")
    conn.send({"type": "get_rlm_children", "id": "rc2", "activeSessionId": parent_id})
    rec["raw"]["get_rlm_children_150"] = conn.recv("rc2", 30).get("data")
    conn.send({"type": "list", "id": "ls2", "all": True})
    rec["raw"]["list_150"] = conn.recv("ls2", 30).get("data")

    # ---- detach the owner client: the TS tier-2 eviction window ----
    conn.close()
    rec["stages"]["client_detach_t"] = round(time.monotonic() - t0_ref, 1)
    while time.monotonic() - t0_ref < MARK3_S:
        time.sleep(2.0)

    conn2 = Conn(sock)
    conn2.read_frames(2)
    census_point("census_3_idle300")
    wake_point("wake_3_idle300")
    conn2.send({"type": "list", "id": "ls3", "all": True})
    rec["raw"]["list_300"] = conn2.recv("ls3", 30).get("data")
    conn2.send({"type": "get_rlm_children", "id": "rc3", "activeSessionId": parent_id})
    rec["raw"]["get_rlm_children_300"] = conn2.recv("rc3", 30).get("data")

    # ---- revival: child-1 then the parent ----
    child_id = None
    rc = rec["raw"].get("get_rlm_children_300") or rec["raw"].get("get_rlm_children_150")
    if isinstance(rc, dict):
        for row in (rc.get("children") or rc.get("subagents") or rc.get("rows") or []):
            if isinstance(row, dict) and "census-child-1" in json.dumps(row):
                child_id = row.get("activeSessionId") or row.get("sessionId")
                break
    rec["revival_child_id"] = child_id
    # The durable id for the revival (the passive row keeps the session
    # id; the live routing id dies with the worker).
    durable_id = None
    for key in ("get_rlm_children_300", "get_rlm_children_150", "get_rlm_children_settle"):
        rc_raw = rec["raw"].get(key)
        if isinstance(rc_raw, dict):
            for row in (rc_raw.get("children") or []):
                if isinstance(row, dict) and row.get("id", "").startswith("sub-"):
                    sid = (row.get("sessionId") or row.get("session_id")
                           or (row.get("sessionDir", "") + "/").rsplit("/", 2)[-2])
                    if sid:
                        durable_id = sid
                        break
        if durable_id:
            break
    rec["revive_durable_id"] = durable_id
    target_id = child_id or durable_id
    if target_id:
        t0 = time.monotonic()
        conn2.send({"type": "prompt_and_wait", "id": "pv1",
                   "activeSessionId": target_id, "message": "READ-MARK"})
        r = conn2.recv("pv1", 240)
        rec["stages"]["revive_child"] = {
            "success": r.get("success"), "error": r.get("error"),
            "selector": target_id,
            "prompt_to_done_s": round(time.monotonic() - t0, 2)}
        # The durable retry: a routing-id miss wakes nothing (the passive
        # row strips it); the session id resolves through the ledger.
        if not r.get("success") and str(r.get("error") or "").startswith("Unknown active session") and durable_id and durable_id != target_id:
            t0 = time.monotonic()
            conn2.send({"type": "prompt_and_wait", "id": "pv1b",
                       "activeSessionId": durable_id, "message": "READ-MARK"})
            r = conn2.recv("pv1b", 240)
            rec["stages"]["revive_child_durable_retry"] = {
                "success": r.get("success"), "error": r.get("error"),
                "selector": durable_id,
                "prompt_to_done_s": round(time.monotonic() - t0, 2)}
            r = rec["stages"]["revive_child_durable_retry"]
        rec["stages"]["census_after_child_revive"] = tree_rows(proc.pid)
    t0 = time.monotonic()
    conn2.send({"type": "prompt_and_wait", "id": "pv2",
               "activeSessionId": parent_id, "message": "REVIVE-PARENT"})
    r = conn2.recv("pv2", 240)
    rec["stages"]["revive_parent"] = {
        "success": r.get("success"), "error": r.get("error"),
        "prompt_to_done_s": round(time.monotonic() - t0, 2)}
    rec["stages"]["census_after_parent_revive"] = tree_rows(proc.pid)

    json.dump(rec, open(out_path, "w"), indent=1)
    print(json.dumps({"role": role, "k": k,
                      "census_1_workers": sum(1 for r in rec["stages"]["census_1_settle"]["census"] if r["class"] == "prime-agent"),
                      "census_1_kernels": sum(1 for r in rec["stages"]["census_1_settle"]["census"] if r["class"] == "kernel-python"),
                      "census_3_workers": sum(1 for r in rec["stages"]["census_3_idle300"]["census"] if r["class"] == "prime-agent"),
                      "census_3_kernels": sum(1 for r in rec["stages"]["census_3_idle300"]["census"] if r["class"] == "kernel-python"),
                      "revive_child": rec["stages"].get("revive_child"),
                      "revive_parent": rec["stages"].get("revive_parent")}, indent=1)[:1200])
    teardown(proc, conn2, noop)


def teardown(proc, conn, noop):
    try:
        conn.send({"type": "shutdown", "id": "sd1"})
        conn.recv("sd1", 10)
    except Exception:
        pass
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
    noop.kill()
    noop.wait()


if __name__ == "__main__":
    main()
