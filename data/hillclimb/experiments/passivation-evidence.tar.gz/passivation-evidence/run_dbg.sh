#!/bin/bash
set -uo pipefail
cd /root/bench-harness
export CENSUS_MOCK_PORT=8899
python3 /root/lane/parked_census.py /root/idleb/trial-dbg /root/arm-dbg/prime-agent rust /root/idleb/census-dbg.json 8 1  2>&1 | tail -4
echo "=== worker stderr logs ==="
for f in /root/idleb/trial-dbg/agent/logs/worker-*.stderr.log; do
  echo "--- $f"; grep -E 'passivation-debug' "$f" | head -6
done
echo "=== done ==="
