#!/bin/bash
# The autobg triage: solo runs of a_blocking_bash_await_degrades at the exact gate head.
set -uo pipefail
cd /root/solo-src
export PATH=/root/.cargo/bin:$PATH
echo "=== SOLO BUILD START $(date -u +%H:%M:%S) ==="
cargo +1.98.1 test -p pa-daemon --test autobg_headless_e2e --no-run 2>&1 | tail -3
echo "BUILD_RC=$?"
echo "=== SOLO RUN 1 $(date -u +%H:%M:%S) ==="
cargo +1.98.1 test -p pa-daemon --test autobg_headless_e2e 2>&1 | tail -12
echo "RUN1_RC=$?"
echo "=== SOLO RUN 2 (the identity-cache warm run) $(date -u +%H:%M:%S) ==="
cargo +1.98.1 test -p pa-daemon --test autobg_headless_e2e 2>&1 | tail -8
echo "RUN2_RC=$?"
echo "=== SOLO DONE $(date -u +%H:%M:%S) ==="
