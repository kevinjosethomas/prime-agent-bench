#!/bin/bash
# The arm's parked-children A/B census v2: ABBA (B=base 28107df4f, C=candidate a0ae6f1a0),
# sha-asserted per leg, fresh mock port per run, spawn-verified legs (a failed leg aborts + retries once).
set -uo pipefail
cd /root/bench-harness
export CENSUS_MOCK_PORT=8893
PY=python3
LANE=/root/lane
OUT=/root/idleb
BASE=/root/base-src/target/release/prime-agent
CAND=/root/arm-src/target/release/prime-agent
run_leg() {
  local trial=$1 bin=$2 sha=$3 out=$4
  for attempt in 1 2; do
    $PY $LANE/parked_census.py /root/idleb/$trial $bin rust $out 8 1 $sha 2>&1 | tail -4
    if $PY -c "import json,sys; d=json.load(open('$out')); sys.exit(0 if 'error' not in d or not d.get('error') else 1)" 2>/dev/null; then
      return 0
    fi
    echo "leg $trial attempt $attempt failed; retrying"
    pkill -f mock_provider; sleep 1
  done
  echo "leg $trial FAILED twice"
  return 1
}
echo "=== ARM ABBA CENSUS v2 START $(date -u +%Y-%m-%dT%H:%M:%SZ) ==="
sha256sum $BASE $CAND | tee $OUT/arm-binary-shas.txt
run_leg trial-arm-b1 $BASE  9e35d59bd713a95977618f3ab5c34109ef6219ff5aa6e4f27a45175808f4f050 $OUT/census-arm-b1.json
run_leg trial-arm-c1 $CAND  b0ee13d8376459774e337b4fd07d318493908db527c5350b331f64b51bb4653a $OUT/census-arm-c1.json
run_leg trial-arm-c2 $CAND  b0ee13d8376459774e337b4fd07d318493908db527c5350b331f64b51bb4653a $OUT/census-arm-c2.json
run_leg trial-arm-b2 $BASE  9e35d59bd713a95977618f3ab5c34109ef6219ff5aa6e4f27a45175808f4f050 $OUT/census-arm-b2.json
echo "=== ARM ABBA CENSUS v2 DONE $(date -u +%Y-%m-%dT%H:%M:%SZ) ==="
