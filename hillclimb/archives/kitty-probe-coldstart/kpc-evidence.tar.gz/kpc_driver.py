#!/usr/bin/env python3
"""kitty-probe-coldstart lane driver: early-typing delivery in the probe window.

Per trial: fresh trial dir, pre-started per-trial resident daemon, PTYSession
launch (per-chunk timestamp ledger + pyte screen + reader-thread echo watch).
The probe's query bytes are timestamped chunk-accurately from the raw ledger;
terminal classes are emulated by answer writes at known offsets:
  silent  - never answers (the worst case: full window hold)
  da1    - DA1 answer at +20ms (non-kitty answering terminal: candidate C path)
  kitty  - flags + DA1 at +20ms (kitty terminal: the upgrade path)
Keys at known offsets after the query bytes; the echo watch timestamps when
the key first becomes visible on the cursor rows. The control key lands after
the window; its latency isolates the render pipeline. TTFF proves first draw
is not gated by the probe. ABBA blocks with unlink-then-copy sha-asserted
binary swaps; noop + fsync + isolated-fresh calibration legs around them.
"""
import hashlib, json, os, shutil, socket, statistics, subprocess, sys, threading, time, uuid
from pathlib import Path

sys.path.insert(0, "/root/bench-harness")
from bench.core.config import load_config
from bench.core.registry import discover
from bench.adapters.terminals.pty import PTYSession

QUERY = b"\x1b[?u\x1b[c"          # the probe's exact query write (flags query + DA1 query)
KITTY_PUSH = b"\x1b[>7u"           # the flags push when the probe answers true
DA1_ANSWER = b"\x1b[?62;c"         # a non-kitty terminal's DA1 reply
KITTY_ANSWER = b"\x1b[?7u\x1b[?62;c"  # a kitty terminal: flags reply then DA1 (BOTH - PR#302 lesson)
BIN = "/root/bench-cmp5/pa-rust-prefix/bin/prime-agent-rust"
RESULTS = Path("/root/results-kpc")
TRIALS = Path("/root/bench-root/trials")

def sha256f(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def swap(arm, expect_sha=None):
    """Fleet-standard atomic binary swap: unlink-then-copy + sha assert."""
    src = f"/root/bins/bin-{arm}"
    got_before = sha256f(src)
    if expect_sha and got_before != expect_sha:
        raise RuntimeError(f"staged {arm} sha {got_before} != expected {expect_sha}")
    if os.path.exists(BIN):
        os.unlink(BIN)
    shutil.copy2(src, BIN)
    got = sha256f(BIN)
    if got != got_before:
        raise RuntimeError(f"swap sha mismatch {arm}: {got} != {got_before}")
    os.chmod(BIN, 0o755)
    return got

def wait_daemon_socket(socket_path, timeout=90.0):
    deadline = time.perf_counter() + timeout
    while time.perf_counter() < deadline:
        if socket_path.exists():
            try:
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                    s.settimeout(2)
                    s.connect(str(socket_path))
                return True
            except OSError:
                pass
        time.sleep(0.005)
    return False

def wait_for_bytes(app, needle, timeout=30.0):
    """Chunk-accurate first-arrival time of needle in the raw stream."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        with app._lock:
            raw = bytes(app.raw)
            idx = raw.find(needle)
            if idx >= 0:
                for t, end in app.chunks:
                    if idx < end:
                        return t
        time.sleep(0.0005)
    return None

def busy_until(t_target):
    while time.monotonic() < t_target:
        pass

def run_trial(product, driver, variant, offset_ms, arm_sha, round_idx):
    td = TRIALS / f"kpc-{uuid.uuid4().hex[:10]}"
    ctx = product.new_trial(td)
    dproc = subprocess.Popen(product.daemon_argv(ctx), env=product.env(ctx),
                             cwd=str(ctx["work"]), stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    daemon_ok = wait_daemon_socket(ctx["daemon_socket"], 90)
    rec = {"arm_sha": arm_sha[:12], "variant": variant, "offset_ms": offset_ms,
           "round": round_idx, "trial": td.name, "daemon_ok": daemon_ok,
           "valid": False}
    app = None
    try:
        app = product.launch(ctx, driver)
        t_query = wait_for_bytes(app, QUERY, 30)
        rec["query_seen"] = t_query is not None
        if t_query is None:
            rec["fail"] = "no probe query on the wire"
            return rec
        rec["query_after_spawn_ms"] = round((t_query - app.t_spawn) * 1000, 1)

        # Terminal-class emulation: the answer write at +20ms after the query.
        t_answer_sent = None
        if variant != "silent":
            busy_until(t_query + 0.020)
            answer = DA1_ANSWER if variant == "da1" else KITTY_ANSWER
            os.write(app.master, answer)
            t_answer_sent = time.monotonic()
        if variant == "kitty":
            t_push = wait_for_bytes(app, KITTY_PUSH, 10)
            rec["upgrade_ms_after_answer"] = (round((t_push - t_answer_sent) * 1000, 1)
                                              if (t_push and t_answer_sent) else None)
            rec["upgrade_seen"] = t_push is not None

        # The measured key: sent at query + offset; visible when rendered.
        busy_until(t_query + offset_ms / 1000.0)
        app.start_echo_watch("Kq91")
        t_send = app.send("Kq91")
        try:
            t_vis = app.wait_echo(8)
            rec["key_vis_ms"] = round((t_vis - t_send) * 1000, 1)
            rec["key_send_after_query_ms"] = round((t_send - t_query) * 1000, 1)
        except TimeoutError:
            rec["fail"] = "key never rendered"
            return rec
        try:
            t_react = app.wait_output_after(t_send, 2)
            rec["key_react_ms"] = round((t_react - t_send) * 1000, 1)
        except TimeoutError:
            rec["key_react_ms"] = None

        # Control key after the window: isolates the render pipeline.
        busy_until(t_query + 0.900)
        app.start_echo_watch("Zw72")
        t_send2 = app.send("Zw72")
        try:
            t_vis2 = app.wait_echo(4)
            rec["control_vis_ms"] = round((t_vis2 - t_send2) * 1000, 1)
        except TimeoutError:
            rec["fail"] = "control key never rendered"
            return rec
        try:
            t_react2 = app.wait_output_after(t_send2, 2)
            rec["control_react_ms"] = round((t_react2 - t_send2) * 1000, 1)
        except TimeoutError:
            rec["control_react_ms"] = None

        rec["ttff_ms"] = round((app.t_first_paint - app.t_spawn) * 1000, 1) if app.t_first_paint else None
        rec["first_byte_ms"] = round((app.t_first_byte - app.t_spawn) * 1000, 1) if app.t_first_byte else None
        rec["bytes_out"] = app.bytes_out()
        with app._lock:
            prev = 0
            ledger = []
            for t, end in app.chunks:
                ledger.append([round((t - app.t_spawn) * 1000, 1), end - prev])
                prev = end
            rec["chunks"] = ledger[:40]
        rec["screen_tail"] = "\n".join(app.screen_text().splitlines()[-6:])
        rec["valid"] = True
        return rec
    finally:
        if app is not None:
            app.kill_tree()
        dproc.terminate()
        try:
            dproc.wait(timeout=10)
        except Exception:
            dproc.kill()
        try:
            product.reap(ctx)
        except Exception:
            pass

def calibration(label):
    """noop + repeat-fsync + isolated-fresh legs (I/O advisory v1.0)."""
    out = {"label": label}
    r = subprocess.run([sys.executable, "-c",
        "import sys; sys.path.insert(0,'/root/bench-harness');"
        "from bench.core.registry import discover;"
        "from bench.core.config import load_config;"
        "reg=discover(load_config('/root/bench-harness/configs/sandbox.yaml'));"
        "import json; print(json.dumps(reg.driver().noop_control(30)))"],
        capture_output=True, text=True)
    out["noop"] = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-300:]
    out["noop_rc"] = r.returncode
    for name, path, args in (("fsync", "/root/kpc-probe-fsync.py", []),
                             ("fresh", "/root/kpc-probe-fresh.py", [])):
        r = subprocess.run([sys.executable, path] + args, capture_output=True, text=True)
        out[name] = r.stdout.strip() or r.stderr[-300:]
    return out

def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    TRIALS.mkdir(parents=True, exist_ok=True)
    arm_plan = (sys.argv[1].split(",") if len(sys.argv) > 1 else ["base"])
    rounds = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    cfg = load_config("/root/bench-harness/configs/sandbox.yaml")
    reg = discover(cfg)
    product = reg.product("rust")
    driver = reg.driver()
    # per-block trial plan: silent at 4 offsets + da1 + kitty, per round
    plan = ([("silent", off) for off in (10, 50, 120, 200, 400)]
            + [("da1", off) for off in (50, 120, 200)]
            + [("kitty", 50), ("kitty", 200)]) * rounds
    rows_path = RESULTS / "trials.jsonl"
    cal_path = RESULTS / "calibration.jsonl"

    cal = calibration("pre")
    with open(cal_path, "a") as f:
        f.write(json.dumps(cal) + "\n")
    print("KPC-CAL pre", json.dumps(cal), flush=True)

    for block, arm in enumerate(arm_plan):
        arm_sha = swap(arm)
        print(f"KPC-BLOCK {block} arm={arm} sha={arm_sha[:12]} plan={len(plan)}", flush=True)
        for i, (variant, offset) in enumerate(plan):
            rec = run_trial(product, driver, variant, offset, arm_sha, i)
            rec["block"] = block
            with open(rows_path, "a") as f:
                f.write(json.dumps(rec) + "\n")
            print("KPC-ROW " + json.dumps(rec), flush=True)
        if block == 1 and len(arm_plan) > 2:
            cal = calibration("mid")
            with open(cal_path, "a") as f:
                f.write(json.dumps(cal) + "\n")
            print("KPC-CAL mid", json.dumps(cal), flush=True)

    cal = calibration("post")
    with open(cal_path, "a") as f:
        f.write(json.dumps(cal) + "\n")
    print("KPC-CAL post", json.dumps(cal), flush=True)
    print("KPC-DONE", flush=True)

if __name__ == "__main__":
    main()
