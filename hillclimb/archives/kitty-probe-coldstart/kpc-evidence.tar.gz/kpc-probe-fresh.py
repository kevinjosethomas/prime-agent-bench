#!/usr/bin/env python3
"""Isolated fresh-write+sync_all+rename+stat probe @0.5s spacing (I/O advisory
v1.0: >=40 isolated ops); REGIME-DEGRADED if stall-rate(>20ms) > 2% or any op
>50ms. Host-relative: classify legs against the pre leg, not absolutes."""
import os, statistics, sys, time
n = int(sys.argv[1]) if len(sys.argv) > 1 else 40
base = "/root/kpc-fresh-probe"
stable = base + ".stable"
data = os.urandom(4096)
lat = []
for i in range(n):
    if lat:
        time.sleep(0.5)
    tmp = base + ".tmp"
    t0 = time.perf_counter()
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.rename(tmp, stable)
    os.stat(stable)
    lat.append((time.perf_counter() - t0) * 1000.0)
try:
    os.unlink(stable)
except OSError:
    pass
lat.sort()
stall20 = sum(1 for x in lat if x > 20.0)
big = sum(1 for x in lat if x > 50.0)
rate20 = 100.0 * stall20 / len(lat)
verdict = "REGIME-DEGRADED" if (rate20 > 2.0 or big > 0) else "REGIME-HEALTHY"
print("FRESH_ISOLATED_MS n=%d min=%.2f p50=%.2f p90=%.2f max=%.2f stall20=%d gt50=%d rate20=%.1f%% verdict=%s" % (
    len(lat), lat[0], statistics.median(lat), lat[int(len(lat)*0.9)-1], lat[-1],
    stall20, big, rate20, verdict))
