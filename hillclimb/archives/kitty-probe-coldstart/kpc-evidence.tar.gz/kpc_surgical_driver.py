#!/usr/bin/env python3
"""Surgical early-typing suite (child-mode seam): the probe window isolated
from the session-create paint. The repo's own pty-e2e child mode runs the
REAL run_interactive surface against an instant mock supervisor (no daemon
worker spawn: the attach snapshot paints at mock speed, so key visibility ==
delivery + render inside the window on every offset). ABBA over the two TEST
binaries (base/cand), unlink-then-copy sha-asserted swaps, pyte echo watch on
the cursor rows, chunk-accurate query/answer/paint ledger per trial."""
import hashlib, json, os, shutil, socket, statistics, subprocess, sys, threading, time, uuid
from pathlib import Path
sys.path.insert(0, "/root/bench-harness")
from bench.adapters.terminals.pty import PTYSession

CHILD_ENV = "PA_KITTY_CHILD_SOCKET"
QUERY = b"\x1b[?u\x1b[c"
KITTY_PUSH = b"\x1b[>7u"
DA1_ANSWER = b"\x1b[?62;c"
KITTY_ANSWER = b"\x1b[?7u\x1b[?62;c"
SWAP_PATH = "/root/bins/kpc-child-under-test"
RESULTS = Path("/root/results-kpc")

def sha256f(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def swap(arm):
    src = f"/root/bins/kpc-child-{arm.upper()}"
    if os.path.exists(SWAP_PATH):
        os.unlink(SWAP_PATH)
    shutil.copy2(src, SWAP_PATH)
    os.chmod(SWAP_PATH, 0o755)
    got = sha256f(SWAP_PATH)
    assert got == sha256f(src), "swap sha mismatch"
    return got

ATTACH = {
    "type": "response", "command": "attach", "success": True,
    "data": {
        "protocol": {"name": "prime-agent.daemon", "version": 7},
        "activeSessionId": "s1",
        "snapshot": {
            "activeSessionId": "s1",
            "summary": {"id": "s1", "cwd": "/tmp"},
            "state": {
                "activeSessionId": "s1", "cwd": "/tmp", "sessionId": "sess-1",
                "sessionName": "kitty surgical", "model": None,
                "isStreaming": False, "isCompacting": False,
                "sessionActions": {"queuedCount": 0, "steering": [], "followUps": []},
            },
            "messages": [
                {"role": "user" if i % 2 == 0 else "assistant",
                 "content": [{"type": "text", "text": f"row {i}"}]} for i in range(4)
            ],
            "lastEventSequence": 0, "lastEventCursor": None,
        },
        "client": {"id": "mock", "capabilities": []},
        "lastEventSequence": 0, "lastEventCursor": None,
    },
}

def handle_conn(conn):
    f = conn.makefile("rw")
    def send(obj):
        try:
            f.write(json.dumps(obj) + "\n"); f.flush()
        except OSError:
            pass
    send({"type": "daemon_hello",
          "protocol": {"name": "prime-agent.daemon", "version": 7},
          "serverCapabilities": [], "clientId": "mock"})
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            env = json.loads(line)
        except ValueError:
            continue
        cid = env.get("id", "")
        cmd = env.get("command", {})
        ctype = cmd.get("type", "") if isinstance(cmd, dict) else ""
        if ctype == "create":
            send({"type": "response", "id": cid, "command": "create", "success": True,
                  "data": {"activeSessionId": "s1", "id": "s1", "sessionId": "sess-1",
                           "sessionFile": "/tmp/sess-1.jsonl"}})
        elif ctype == "attach":
            m = dict(ATTACH); m["id"] = cid; send(m)
        else:
            send({"type": "response", "id": cid, "command": ctype, "success": True, "data": {}})

def start_mock(directory):
    sock = directory / "tui.sock"
    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.bind(str(sock)); listener.listen(4); listener.settimeout(0.2)
    stop = threading.Event()
    def accept_loop():
        conns = []
        while not stop.is_set():
            try:
                conn, _ = listener.accept()
            except socket.timeout:
                continue
            conns.append(conn)
            threading.Thread(target=handle_conn, args=(conn,), daemon=True).start()
        for c in conns:
            try: c.close()
            except OSError: pass
    t = threading.Thread(target=accept_loop, daemon=True)
    t.start()
    return listener, stop

def wait_for_bytes(app, needle, timeout=20.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        with app._lock:
            raw = bytes(app.raw)
            idx = raw.find(needle)
            if idx >= 0:
                for t, end in app.chunks:
                    if idx < end:
                        return t
        time.sleep(0.0005)
    return None

def busy_until(t):
    while time.monotonic() < t:
        pass

def run_trial(variant, offset_ms, arm_sha, round_idx):
    td = Path("/root/results-kpc/surgical-trials") / f"k-{uuid.uuid4().hex[:10]}"
    td.mkdir(parents=True, exist_ok=True)
    listener, stop = start_mock(td)
    env = {"HOME": str(td), "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
           "TMPDIR": str(td), CHILD_ENV: str(td / "tui.sock")}
    rec = {"arm_sha": arm_sha[:12], "variant": variant, "offset_ms": offset_ms,
           "round": round_idx, "trial": td.name}
    app = None
    try:
        app = PTYSession([SWAP_PATH, "--exact", "kitty_child_mode"], env=env, cwd=str(td))
        t_query = wait_for_bytes(app, QUERY, 20)
        rec["query_seen"] = t_query is not None
        if t_query is None:
            rec["valid"] = False; rec["fail"] = "no query"
            return rec
        rec["query_after_spawn_ms"] = round((t_query - app.t_spawn) * 1000, 1)
        if variant != "silent":
            busy_until(t_query + 0.020)
            os.write(app.master, DA1_ANSWER if variant == "da1" else KITTY_ANSWER)
        if variant == "kitty":
            t_push = wait_for_bytes(app, KITTY_PUSH, 10)
            rec["upgrade_after_answer_ms"] = round((t_push - (t_query + 0.020)) * 1000, 1) if t_push else None
        busy_until(t_query + offset_ms / 1000.0)
        app.start_echo_watch("Kq91")
        t_send = app.send("Kq91")
        try:
            t_vis = app.wait_echo(8)
            rec["key_vis_ms"] = round((t_vis - t_send) * 1000, 1)
        except TimeoutError:
            rec["valid"] = False; rec["fail"] = "key never rendered"
            return rec
        try:
            t_react = app.wait_output_after(t_send, 2)
            rec["key_react_ms"] = round((t_react - t_send) * 1000, 1)
        except TimeoutError:
            rec["key_react_ms"] = None
        busy_until(t_query + 0.900)
        app.start_echo_watch("Zw72")
        t_send2 = app.send("Zw72")
        try:
            t_vis2 = app.wait_echo(4)
            rec["control_vis_ms"] = round((t_vis2 - t_send2) * 1000, 1)
        except TimeoutError:
            rec["control_vis_ms"] = None
        rec["ttff_ms"] = round((app.t_first_paint - app.t_spawn) * 1000, 1) if app.t_first_paint else None
        with app._lock:
            prev = 0; ledger = []
            for t, end in app.chunks:
                ledger.append([round((t - app.t_spawn) * 1000, 1), end - prev]); prev = end
            rec["chunks"] = ledger[:40]
        rec["screen_tail"] = "\n".join(app.screen_text().splitlines()[-6:])
        rec["valid"] = True
        return rec
    finally:
        if app is not None:
            app.kill_tree()
        stop.set()
        try: listener.close()
        except OSError: pass

def main():
    arm_plan = sys.argv[1].split(",") if len(sys.argv) > 1 else ["base"]
    rounds = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    plan = ([("silent", off) for off in (10, 50, 120, 200)]
            + [("da1", 50), ("kitty", 50)]) * rounds
    rows_path = RESULTS / "surgical.jsonl"
    for block, arm in enumerate(arm_plan):
        arm_sha = swap(arm)
        print(f"KPC-SURGICAL-BLOCK {block} arm={arm} sha={arm_sha[:12]} n={len(plan)}", flush=True)
        for i, (variant, offset) in enumerate(plan):
            rec = run_trial(variant, offset, arm_sha, i)
            rec["block"] = block
            with open(rows_path, "a") as f:
                f.write(json.dumps(rec) + "\n")
            print("KPC-SROW " + json.dumps(rec), flush=True)
    print("KPC-SURGICAL-DONE", flush=True)

if __name__ == "__main__":
    main()
