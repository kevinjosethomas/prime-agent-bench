#!/usr/bin/env python3
"""4KB repeat-fsync probe (I/O advisory v1.0: >=20 samples)."""
import os, statistics, sys, time
path = "/root/kpc-fsync-probe.bin"
lat = []
data = os.urandom(4096)
with open(path, "wb+") as f:
    for _ in range(20):
        f.seek(0)
        f.write(data)
        t0 = time.perf_counter()
        os.fsync(f.fileno())
        lat.append((time.perf_counter() - t0) * 1000.0)
os.unlink(path)
lat.sort()
stall20 = sum(1 for x in lat if x > 20.0)
print("FSYNC_MS n=%d min=%.2f p50=%.2f p90=%.2f max=%.2f stall20=%d" % (
    len(lat), lat[0], statistics.median(lat), lat[int(len(lat)*0.9)-1], lat[-1], stall20))
