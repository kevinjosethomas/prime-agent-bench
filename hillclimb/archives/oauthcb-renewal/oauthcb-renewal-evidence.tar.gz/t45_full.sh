
set -o pipefail
export HOME=/root
export PATH="/root/.cargo/bin:/root/.local/bin:$PATH"
REPO=/workspace/prime-agent
{
  echo "T4_VENV_START $(date -u +%FT%TZ)"
  uv venv --clear /opt/kernel-venv >/dev/null 2>&1 || uv venv /opt/kernel-venv
  uv pip install --python /opt/kernel-venv/bin/python $REPO/prime-agent-runtime
  uv pip install --python /opt/kernel-venv/bin/python dill requests httpx pyyaml tomli python-dotenv pandas numpy scipy beautifulsoup4 lxml pydantic tyro
  uv pip install --python /opt/kernel-venv/bin/python $REPO/skills/goal $REPO/skills/refine $REPO/skills/rlm-heartbeat $REPO/skills/websearch $REPO/skills/agent-observe $REPO/skills/agent-message $REPO/skills/edit $REPO/skills/attach-image $REPO/skills/compact $REPO/skills/linear $REPO/skills/notion
  /opt/kernel-venv/bin/python -c "import dill, requests, httpx, yaml, tomli, dotenv, pandas, numpy, scipy, bs4, lxml, pydantic, tyro, goal, refine, rlm_heartbeat, websearch, agent_observe, agent_message, edit, attach_image, compact" && echo VENV_OK
} > /workspace/logs/t4_venv.log 2>&1
VRC=$?
tail -3 /workspace/logs/t4_venv.log
[ $VRC -eq 0 ] || { echo "VENV_FAILED"; exit $VRC; }

run_full() {
  TAG=$1
  echo "=== FULL-SUITE $TAG $(date -u +%FT%TZ)"
  cd $REPO
  export PRIME_AGENT_KERNEL_PYTHON=/opt/kernel-venv/bin/python
  export PA_E2E_KERNEL_PYTHON=/opt/kernel-venv/bin/python
  export PI_PACKAGE_DIR=$REPO
  export CARGO_INCREMENTAL=0
  s=$(date +%s)
  cargo +1.98.1 test --workspace --no-fail-fast > /workspace/logs/p3_full_$TAG.log 2>&1
  RC=$?
  echo "FULL_RC_$TAG=$RC dur=$(( $(date +%s) - s ))s"
  echo "--- oauth_callback module status lines:"
  grep -E '^test mcp::oauth_callback::tests::\w+ \.\.\.' /workspace/logs/p3_full_$TAG.log || echo "module_lines=MISSING"
  echo "--- collision msgs:"
  grep -c 'ports 53700-53709 are all in use' /workspace/logs/p3_full_$TAG.log || true
  echo "--- pa-core lib section:"
  grep -A1 -B1 'pa-core#lib\|error: test failed, to rerun pass -p pa-core' /workspace/logs/p3_full_$TAG.log | head -6 || true
  grep '^test result:' /workspace/logs/p3_full_$TAG.log | grep -B0 -A0 '9[0-9][0-9] passed\|8[0-9][0-9] passed' | head -4 || true
  echo "--- summaries:"
  grep '^test result:' /workspace/logs/p3_full_$TAG.log | sort | uniq -c | sort -rn | head -20
  echo "--- failnames:"
  grep -E '^---- .+ stdout ----$' /workspace/logs/p3_full_$TAG.log | sed 's/^---- //; s/ stdout ----$//' | sort -u || true
}
{
  run_full run1
  run_full run2
  echo "T5_DONE $(date -u +%FT%TZ)"
} > /workspace/logs/t5_full.log 2>&1
RC=$?
tail -70 /workspace/logs/t5_full.log
exit $RC
