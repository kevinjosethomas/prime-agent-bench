
import subprocess, json, os, time

OUT = '/home/ubuntu/worktrees/perf-oauth-renewal/_lane/ci-scan'
REPO = 'PrimeIntellect-ai/prime-agent'
WF = '272993499'

def gh_api(path, retries=4):
    for i in range(retries):
        r = subprocess.run(['gh', 'api', path], capture_output=True, text=True)
        if r.returncode == 0:
            return json.loads(r.stdout)
        time.sleep(2 * (i + 1))
    return None

all_runs = []
page = 1
while page <= 12:
    data = gh_api(f'repos/{REPO}/actions/workflows/{WF}/runs?per_page=100&page={page}&created=2026-09-24..2026-09-25T19:04:12Z')
    if not data or not data.get('workflow_runs'):
        break
    all_runs.extend(data['workflow_runs'])
    if len(data['workflow_runs']) < 100:
        break
    page += 1
    print(f'page {page}: {len(all_runs)}', flush=True)
uniq = {}
for r in all_runs:
    uniq[r['id']] = r
runs = sorted(uniq.values(), key=lambda r: r['created_at'])
print(f'EARLY-WINDOW runs: {len(runs)}; oldest {runs[0]["created_at"]} newest {runs[-1]["created_at"]}', flush=True)
json.dump([{'id': r['id'], 'head_sha': r['head_sha'], 'branch': r['head_branch'],
            'created': r['created_at'], 'conclusion': r['conclusion'], 'status': r['status']} for r in runs],
          open(f'{OUT}/runs_early.json', 'w'), indent=1)
print('EARLY ENUM DONE', flush=True)
