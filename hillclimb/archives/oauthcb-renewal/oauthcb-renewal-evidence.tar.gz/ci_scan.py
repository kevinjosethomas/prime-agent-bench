
import subprocess, json, os, time, math

OUT = '/home/ubuntu/worktrees/perf-oauth-renewal/_lane/ci-scan'
os.makedirs(OUT, exist_ok=True)
REPO = 'PrimeIntellect-ai/prime-agent'
WF = '272993499'
SINCE = '2026-09-24'

def gh_api(path, retries=4):
    for i in range(retries):
        r = subprocess.run(['gh', 'api', path], capture_output=True, text=True)
        if r.returncode == 0:
            return json.loads(r.stdout)
        time.sleep(2 * (i + 1))
    return None

# 1) enumerate all workflow runs since 2026-09-24 via API pagination
all_runs = []
page = 1
while True:
    data = gh_api(f'repos/{REPO}/actions/workflows/{WF}/runs?per_page=100&page={page}&created=>={SINCE}')
    if not data or not data.get('workflow_runs'):
        break
    all_runs.extend(data['workflow_runs'])
    if len(data['workflow_runs']) < 100:
        break
    page += 1
    print(f'page {page}: total so far {len(all_runs)}', flush=True)
    if page > 30:
        break
# de-dup + sort by created_at
uniq = {}
for r in all_runs:
    uniq[r['id']] = r
runs = sorted(uniq.values(), key=lambda r: r['created_at'])
print(f'total unique CI runs since {SINCE}: {len(runs)}', flush=True)
json.dump([{'id': r['id'], 'head_sha': r['head_sha'], 'branch': r['head_branch'],
            'created': r['created_at'], 'conclusion': r['conclusion'], 'status': r['status']} for r in runs],
          open(f'{OUT}/runs.json', 'w'), indent=1)

# 2) per-run: shard 2/4 job conclusion (jobs endpoint)
census, logfetch = [], []
for i, run in enumerate(runs):
    rid = run['id']
    data = gh_api(f'repos/{REPO}/actions/runs/{rid}/jobs?per_page=100')
    if not data:
        census.append({'run': rid, 'head': run['head_sha'], 'branch': run['head_branch'],
                       'created': run['created_at'], 'run_level': run['conclusion'], 'shard2': 'MISSING'})
        continue
    s2 = next((j for j in data.get('jobs', []) if j['name'] == 'test shard 2/4'), None)
    entry = {'run': rid, 'head': run['head_sha'], 'branch': run['head_branch'],
             'created': run['created_at'], 'run_level': run['conclusion'],
             'shard2': (s2 or {}).get('conclusion'), 'shard2_job_id': (s2 or {}).get('id')}
    census.append(entry)
    if entry['shard2'] != 'success' and entry['shard2_job_id']:
        logfetch.append(entry)
    if (i + 1) % 100 == 0:
        print(f'census {i+1}/{len(runs)}', flush=True)
        json.dump(census, open(f'{OUT}/shard2_census.json', 'w'), indent=1)
json.dump(census, open(f'{OUT}/shard2_census.json', 'w'), indent=1)
print(f'shard2 census done: {len(census)}; non-success needing log fetch: {len(logfetch)}', flush=True)

# 3) fetch logs for non-success shard-2 runs
details = []
for j, entry in enumerate(logfetch):
    r = subprocess.run(['gh', 'run', 'view', '--job', str(entry['shard2_job_id']), '-R', REPO, '--log'],
                       capture_output=True, text=True)
    out = r.stdout or ''
    lines = out.split('\n')
    oauth_lines = [l for l in lines if 'oauth_callback' in l]
    failed_oauth = [l for l in oauth_lines if 'FAILED' in l]
    pacore = [l for l in lines if 'pa-core#lib' in l and (' RUN ' in l or ' PASS ' in l or ' FAIL ' in l)]
    details.append({**entry, 'log_saved': bool(out),
                     'oauth_line_count': len(oauth_lines),
                     'oauth_failed': len(failed_oauth),
                     'oauth_failed_lines': failed_oauth[:5],
                     'pacore_lib_lines': pacore[:4],
                     'collision_msgs': [l for l in lines if '53700-53709' in l][:3]})
    with open(f"{OUT}/shard2_job_{entry['shard2_job_id']}.log", 'w') as fh:
        fh.write(out)
    if (j + 1) % 10 == 0:
        print(f'logfetch {j+1}/{len(logfetch)}', flush=True)
json.dump(details, open(f'{OUT}/shard2_nonsuccess_details.json', 'w'), indent=1)
succ = sum(1 for c in census if c['shard2'] == 'success')
print(f'shard2 success: {succ} | non-success: {len(logfetch)} | other: {len(census)-succ-len(logfetch)}', flush=True)
print('CI SCAN DONE', flush=True)
