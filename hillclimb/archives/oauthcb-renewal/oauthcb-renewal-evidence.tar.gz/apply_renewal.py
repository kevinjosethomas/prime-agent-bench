
import json, os, datetime, shutil

KR = '/home/ubuntu/.prime/agent/fleet-tools/known_reds.json'
stamp = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
shutil.copy(KR, KR + '.bak-oauth-renewal')

with open(KR) as f:
    reg = json.load(f)

entry = None
for r in reg['reds']:
    if r.get('id') == 'mcp_oauth_callback_family':
        entry = r
        break
assert entry is not None, 'entry not found'

entry['classification'] = CLASSIFICATION
entry['evidence'] = EVIDENCE
entry['expiry'] = '2026-10-01'
entry['renewed'] = '2026-09-27 (oauth-callback-renewal wave-5 hygiene lane, triage VM v5evmdg73zktmj6dhmnctnzn at tip a5235b123c7c4465ec4c9f1c29704aef5b57d7b8; record 20260927-<TS>-other-oauth-callback-known-red-renewal)'
entry['reopen_trigger'] = REOPEN

reg['updated'] = '2026-09-27'
tmp = KR + '.tmp'
with open(tmp, 'w') as f:
    json.dump(reg, f, indent=1)
    f.write('\n')
os.replace(tmp, KR)
print('APPLIED')

# verify: simulate fleet_pipeline _classify on the known failnames
with open(KR) as f:
    reg2 = json.load(f)
today = '2026-09-27'
for name in ['mcp::oauth_callback::tests::callback_flow_settles_code_and_state',
             'mcp::oauth_callback::tests::error_callback_settles_none',
             'mcp::oauth_callback::tests::unknown_route_is_404_without_settling',
             'mcp::oauth_callback::tests::falls_back_to_the_next_free_port']:
    hit = None
    for r in reg2['reds']:
        if r.get('pattern') and r['pattern'] in name:
            hit = r
            break
    expired = bool(hit and hit.get('expiry') and hit['expiry'] < today)
    print(f'{name} -> entry={hit["id"] if hit else None} expired={expired} known_red={bool(hit and not expired)}')
