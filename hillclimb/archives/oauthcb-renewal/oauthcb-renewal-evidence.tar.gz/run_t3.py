
import sys
sys.path.insert(0, '/home/ubuntu/.venvs/psb/lib/python3.11/site-packages')
from prime_sandboxes import APIClient, SandboxClient
client = SandboxClient(api_client=APIClient())
script = open('/home/ubuntu/worktrees/perf-oauth-renewal/_lane/t3_solo.sh').read()
resp = client.execute_command('v5evmdg73zktmj6dhmnctnzn', script, timeout=900)
rc = getattr(resp, 'exit_code', -1)
out = (getattr(resp, 'stdout', '') or '') + (getattr(resp, 'stderr', '') or '')
print('RC', rc)
print(out[-5000:])
