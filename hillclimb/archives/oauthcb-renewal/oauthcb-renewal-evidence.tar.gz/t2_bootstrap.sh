
set -o pipefail
export HOME=/root
mkdir -p /root/triage /workspace/logs
{
  echo "T2_START $(date -u +%s)"
  dpkg --configure -a || true
  apt-get update -q
  DEBIAN_FRONTEND=noninteractive apt-get install -y -q iproute2 lsof nodejs npm curl git ca-certificates pkg-config build-essential > /dev/null 2>&1
  export PATH="/root/.local/bin:$PATH"
  command -v uv >/dev/null 2>&1 || curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="/root/.cargo/bin:$PATH"
  rustup toolchain install 1.98.1 --profile minimal --component rustfmt --component clippy
  rustup default 1.98.1
  rustup component add rustfmt clippy || true
  rustc -V | grep -q "1.98.1" || { echo "TOOLCHAIN_PIN_FAILED"; exit 3; }
  echo "TOOLCHAIN_OK"
  mkdir -p /workspace/prime-agent
  cd /workspace/prime-agent
  if [ ! -d .git ]; then git clone --depth 100 -b rust https://github.com/PrimeIntellect-ai/prime-agent.git /workspace/prime-agent 2>&1 | tail -2; fi
  git fetch --depth 100 origin '+refs/heads/rust:refs/remotes/origin/rust' 2>&1 | tail -2
  git checkout --detach a5235b123c7c4465ec4c9f1c29704aef5b57d7b8 2>&1 | tail -1
  echo "HEAD=$(git rev-parse HEAD)"
  echo "SOLO_RELEASE_COMPILE_START $(date -u +%s)"
  cargo +1.98.1 test --release --locked -p pa-core --lib --no-run
  echo "SOLO_RELEASE_COMPILE_RC=$?"
  echo "SOLO_DEBUG_COMPILE_START $(date -u +%s)"
  cargo +1.98.1 test --locked -p pa-core --lib --no-run
  echo "SOLO_DEBUG_COMPILE_RC=$?"
  echo "T2_DONE $(date -u +%s)"
} > /workspace/logs/t2_bootstrap.log 2>&1
RC=$?
tail -25 /workspace/logs/t2_bootstrap.log
exit $RC
