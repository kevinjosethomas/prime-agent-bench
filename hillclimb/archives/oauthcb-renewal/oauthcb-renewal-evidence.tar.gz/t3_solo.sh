
set -o pipefail
export HOME=/root
export PATH="/root/.cargo/bin:/root/.local/bin:$PATH"
{
  echo "T3_START $(date -u +%FT%TZ)"
  # range sanity BEFORE the matrix: all 10 candidates free?
  for p in 53700 53701 53702 53703 53704 53705 53706 53707 53708 53709; do
    python3 -c "import socket;s=socket.socket();s.bind(('127.0.0.1',$p));s.close()" 2>/dev/null && echo "port $p FREE" || echo "port $p HELD"
  done
  cd /workspace/prime-agent
  for i in 1 2 3 4 5; do
    echo "=== SOLO RELEASE run $i $(date -u +%T)"
    s=$(date +%s)
    cargo +1.98.1 test --release --locked -p pa-core --lib mcp::oauth_callback::tests::callback_flow_settles_code_and_state 2>&1 | tail -3
    echo "SOLO_RELEASE_RC_$i=${PIPESTATUS[0]} dur=$(( $(date +%s) - s ))s"
  done
  for i in 1 2 3 4 5; do
    echo "=== SOLO DEBUG run $i $(date -u +%T)"
    s=$(date +%s)
    cargo +1.98.1 test --locked -p pa-core --lib mcp::oauth_callback::tests::callback_flow_settles_code_and_state 2>&1 | tail -3
    echo "SOLO_DEBUG_RC_$i=${PIPESTATUS[0]} dur=$(( $(date +%s) - s ))s"
  done
  echo "T3_DONE $(date -u +%FT%TZ)"
} > /workspace/logs/t3_solo.log 2>&1
RC=$?
tail -30 /workspace/logs/t3_solo.log
exit $RC
