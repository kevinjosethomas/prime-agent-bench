
import subprocess, json, os, time

OUT = '/home/ubuntu/worktrees/perf-oauth-renewal/_lane/ci-scan'
REPO = 'PrimeIntellect-ai/prime-agent'
WF = '272993499'

def gh_api(path, retries=4):
    for i in range(retries):
        r = subprocess.run(['gh', 'api', path], capture_output=True, text=True)
        if r.returncode == 0:
            return json.loads(r.stdout)
        time.sleep(2 * (i + 1))
    return None

# fetch ALL runs since 2026-09-24 (properly encoded created filter)
all_runs = []
page = 1
while page <= 20:
    data = gh_api(f'repos/{REPO}/actions/workflows/{WF}/runs?per_page=100&page={page}&created=%3E%3D2026-09-24')
    if not data or not data.get('workflow_runs'):
        break
    runs_pg = data['workflow_runs']
    all_runs.extend(runs_pg)
    oldest = runs_pg[-1]['created_at']
    if len(runs_pg) < 100 or oldest < '2026-09-24':
        break
    page += 1
    print(f'page {page}: total {len(all_runs)}, oldest {oldest}', flush=True)

uniq = {}
for r in all_runs:
    uniq[r['id']] = r
runs = sorted(uniq.values(), key=lambda r: r['created_at'])
print(f'total unique CI runs since 2026-09-24: {len(runs)}; oldest {runs[0]["created_at"]}', flush=True)
json.dump([{'id': r['id'], 'head_sha': r['head_sha'], 'branch': r['head_branch'],
            'created': r['created_at'], 'conclusion': r['conclusion'], 'status': r['status']} for r in runs],
          open(f'{OUT}/runs_full.json', 'w'), indent=1)
print('ENUM DONE', flush=True)
