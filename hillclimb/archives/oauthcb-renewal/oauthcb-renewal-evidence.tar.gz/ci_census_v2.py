
import subprocess, json, os, time
from concurrent.futures import ThreadPoolExecutor, as_completed

OUT = '/home/ubuntu/worktrees/perf-oauth-renewal/_lane/ci-scan'
REPO = 'PrimeIntellect-ai/prime-agent'

runs_all = json.load(open(f'{OUT}/runs.json')) + json.load(open(f'{OUT}/runs_early.json'))
uniq = {}
for r in runs_all:
    uniq[r['id']] = r
runs = sorted(uniq.values(), key=lambda r: r.get('created') or r.get('created_at'))
print(f'total runs: {len(runs)}', flush=True)

def get_jobs(run):
    rid = run['id']
    for attempt in range(3):
        r = subprocess.run(['gh', 'api', f'repos/{REPO}/actions/runs/{rid}/jobs?per_page=100'],
                           capture_output=True, text=True)
        if r.returncode == 0:
            data = json.loads(r.stdout)
            s2 = next((j for j in data.get('jobs', []) if j['name'] == 'test shard 2/4'), None)
            return {'run': rid, 'head': run.get('head_sha'), 'branch': run.get('branch') or run.get('head_branch'),
                    'created': run.get('created') or run.get('created_at'), 'run_level': run['conclusion'],
                    'shard2': (s2 or {}).get('conclusion'), 'shard2_job_id': (s2 or {}).get('id'),
                    'shard2_status': (s2 or {}).get('status')}
        time.sleep(1.5 * (attempt + 1))
    return {'run': rid, 'head': run.get('head_sha'), 'branch': run.get('branch') or run.get('head_branch'),
            'created': run.get('created') or run.get('created_at'), 'run_level': run['conclusion'], 'shard2': 'MISSING'}

census = []
# success runs: inferred green (sample-verified x3)
for run in runs:
    if run['conclusion'] == 'success':
        census.append({'run': run['id'], 'head': run.get('head_sha'), 'branch': run.get('branch') or run.get('head_branch'),
                       'created': run.get('created') or run.get('created_at'), 'run_level': 'success',
                       'shard2': 'success', 'shard2_job_id': None,
                       'shard2_status': 'inferred-by-run-success (sample-verified)'})
json.dump(census, open(f'{OUT}/census_success_inferred.json', 'w'), indent=1)
print(f'inferred-green from run success: {len(census)}', flush=True)

non_success = [r for r in runs if r['conclusion'] != 'success']
print(f'jobs calls needed: {len(non_success)}', flush=True)
ns_census = []
with ThreadPoolExecutor(max_workers=12) as ex:
    futs = {ex.submit(get_jobs, r): r for r in non_success}
    done = 0
    for fut in as_completed(futs):
        ns_census.append(fut.result())
        done += 1
        if done % 50 == 0:
            print(f'jobs {done}/{len(non_success)}', flush=True)
            json.dump(ns_census, open(f'{OUT}/census_nonsuccess_jobs.json', 'w'), indent=1)
json.dump(ns_census, open(f'{OUT}/census_nonsuccess_jobs.json', 'w'), indent=1)
print(f'non-success census done: {len(ns_census)}', flush=True)

need_log = [c for c in ns_census if c['shard2'] not in ('success', None) and c.get('shard2_job_id')]
print(f'shard-2 logs to fetch: {len(need_log)}', flush=True)

def fetch_log(c):
    r = subprocess.run(['gh', 'run', 'view', '--job', str(c['shard2_job_id']), '-R', REPO, '--log'],
                       capture_output=True, text=True)
    out = r.stdout or ''
    lines = out.split('\n')
    oauth = [l for l in lines if 'oauth_callback' in l]
    failed_oauth = [l for l in oauth if 'FAILED' in l]
    pacore = [l for l in lines if 'pa-core#lib' in l]
    with open(f"{OUT}/shard2_job_{c['shard2_job_id']}.log", 'w') as fh:
        fh.write(out)
    return {**c, 'log_saved': bool(out), 'oauth_line_count': len(oauth),
            'oauth_failed': len(failed_oauth), 'oauth_failed_lines': failed_oauth[:4],
            'pacore_lib_lines': [l.split('\t')[-1] for l in pacore if (' RUN ' in l or ' PASS ' in l or ' FAIL ' in l)][:3],
            'collision_msgs': [l for l in lines if '53700-53709' in l][:3],
            'oauth_ok_lines': len([l for l in oauth if ' ... ok' in l])}

log_details = []
with ThreadPoolExecutor(max_workers=8) as ex:
    futs = {ex.submit(fetch_log, c): c for c in need_log}
    done = 0
    for fut in as_completed(futs):
        log_details.append(fut.result())
        done += 1
        if done % 25 == 0:
            print(f'logs {done}/{len(need_log)}', flush=True)
            json.dump(log_details, open(f'{OUT}/shard2_log_details.json', 'w'), indent=1)
json.dump(log_details, open(f'{OUT}/shard2_log_details.json', 'w'), indent=1)
print('CI CENSUS V2 DONE', flush=True)
print(f'inferred-green {len(census)} | non-success {len(ns_census)} | logs {len(log_details)}', flush=True)
