
set -o pipefail
export HOME=/root
export PATH="/root/.cargo/bin:/root/.local/bin:$PATH"
cd /workspace/prime-agent
famrun() {
  MODE=$1; N=$2; THREADS=$3; LOG=$4
  : > $LOG
  COLL=0; RED=0; GREEN=0
  for i in $(seq 1 $N); do
    if [ "$THREADS" = "default" ]; then
      cargo +1.98.1 test $MODE --locked -p pa-core --lib mcp::oauth_callback > /tmp/fam_$i.log 2>&1
    else
      cargo +1.98.1 test $MODE --locked -p pa-core --lib mcp::oauth_callback -- --test-threads=$THREADS > /tmp/fam_$i.log 2>&1
    fi
    RC=$?
    COLLMSG=$(grep -c 'ports 53700-53709 are all in use' /tmp/fam_$i.log)
    FAILED=$(grep -cE '^test mcp::oauth_callback::tests::\w+ \.\.\. FAILED' /tmp/fam_$i.log)
    SKIPCAND=$(grep -c 'all_candidates_bound_fails_clearly \.\.\. ok' /tmp/fam_$i.log)
    if [ $RC -ne 0 ]; then RED=$((RED+1)); else GREEN=$((GREEN+1)); fi
    if [ "$COLLMSG" != "0" ]; then COLL=$((COLL+1)); fi
    VICTIMS=$(grep -E '^test mcp::oauth_callback::tests::\w+ \.\.\. FAILED' /tmp/fam_$i.log | sed 's/test mcp::oauth_callback::tests:://; s/ \.\.\. FAILED//' | tr '\n' '+')
    echo "run=$i rc=$RC collision_msgs=$COLLMSG failed=$FAILED victims=${VICTIMS:-none}" >> $LOG
    cp /tmp/fam_$i.log /tmp/fam_last.log
  done
  echo "MODE=$MODE threads=$THREADS N=$N red=$RED green=$GREEN collision_runs=$COLL" >> $LOG
  echo "MODE=$MODE threads=$THREADS N=$N red=$RED green=$GREEN collision_runs=$COLL"
}
{
  echo "T4_START $(date -u +%FT%TZ)"
  nproc
  echo "=== FAMILY-FILTER CHARACTERIZATION (6 module tests, default harness threads) ==="
  famrun "" 20 default /workspace/logs/t4_family_debug_default.log
  echo "=== RELEASE ==="
  famrun "--release" 10 default /workspace/logs/t4_family_release_default.log
  echo "=== SINGLE-THREAD (mechanism proof: sequential = no co-scheduling) ==="
  famrun "" 5 1 /workspace/logs/t4_family_debug_threads1.log
  echo "=== per-run detail (debug default) ==="
  cat /workspace/logs/t4_family_debug_default.log
  echo "=== per-run detail (release default) ==="
  cat /workspace/logs/t4_family_release_default.log
  echo "=== per-run detail (debug threads=1) ==="
  cat /workspace/logs/t4_family_debug_threads1.log
  echo "=== last run raw tail (sample) ==="
  tail -20 /tmp/fam_last.log
  echo "T4_DONE $(date -u +%FT%TZ)"
} > /workspace/logs/t4_family.log 2>&1
RC=$?
tail -80 /workspace/logs/t4_family.log
exit $RC
