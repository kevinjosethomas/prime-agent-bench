#!/bin/bash
# Decompose legs with the probe binary (RPC_TRACE=1 inside the driver env).
set -x
cd /root/floor-lane
mkdir -p /root/floor-results
probe_v09() {
  python3 /root/floor-lane/probe_v09.py /root/probe-v09 "$1" | tail -2
}
# io preflight before each block (advisory v1.0)
probe_v09 pre-burst-1
RPC_TRACE=1 python3 rpc_floor_probe.py burst 2 /root/bins/prime-agent-probe /root/floor-results/decompose-burst.json
probe_v09 post-burst-1
probe_v09 pre-isolate-1
RPC_TRACE=1 python3 rpc_floor_probe.py isolate 2 /root/bins/prime-agent-probe /root/floor-results/decompose-isolate.json
probe_v09 post-isolate-1
probe_v09 pre-stream-1
RPC_TRACE=1 python3 rpc_floor_probe.py stream 2 /root/bins/prime-agent-probe /root/floor-results/decompose-stream.json
probe_v09 post-stream-1
echo LEGS_DONE
