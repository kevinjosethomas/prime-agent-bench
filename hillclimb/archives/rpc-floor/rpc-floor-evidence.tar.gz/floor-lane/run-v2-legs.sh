#!/bin/bash
# v2 arrival-accurate blocks: battery on tip (no trace) x4, battery on probe (trace) x2, stream x2, io-probes around each block
set -x
cd /root/floor-lane
mkdir -p /root/floor-results
python3 /root/floor-lane/probe_v09.py /root/probe-v09 pre-v2-tip-battery | tail -2
RPC_TRACE=0 python3 rpc_floor_v2.py battery 4 /root/bins/prime-agent-tip /root/floor-results/v2-battery-tip.json
python3 /root/floor-lane/probe_v09.py /root/probe-v09 post-v2-tip-battery | tail -2
python3 /root/floor-lane/probe_v09.py /root/probe-v09 pre-v2-probe-battery | tail -2
RPC_TRACE=1 python3 rpc_floor_v2.py battery 2 /root/bins/prime-agent-probe /root/floor-results/v2-battery-probe.json
python3 /root/floor-lane/probe_v09.py /root/probe-v09 post-v2-probe-battery | tail -2
python3 /root/floor-lane/probe_v09.py /root/probe-v09 pre-v2-stream | tail -2
RPC_TRACE=0 python3 rpc_floor_v2.py stream 2 /root/bins/prime-agent-tip /root/floor-results/v2-stream-tip.json
python3 /root/floor-lane/probe_v09.py /root/probe-v09 post-v2-stream | tail -2
echo V2_LEGS_DONE
