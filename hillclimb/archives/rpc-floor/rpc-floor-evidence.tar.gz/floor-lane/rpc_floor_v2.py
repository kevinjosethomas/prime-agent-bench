#!/usr/bin/env python3
"""rpc-floor lane: ARRIVAL-ACCURATE per-command battery (driver v2).

The decompose proved the baseline/sister probe drivers parked one full
select timeout (0.05s there / 0.01s here) AFTER consuming a response
frame, before scanning for it: the reported per-command wall carried
~+50ms (or +10ms) of pure driver park. This driver checks for the
response immediately after every consume; select only waits while NO
data has arrived. Per-command walls are now send->arrival accurate.

Modes:
  battery <trials> <bin> <out.json>   -- full per-command battery (fresh session)
  stream  <trials> <bin> <out.json>   -- 8 pipelined get_state (falsification leg)
"""
import hashlib, json, os, pathlib, shutil, statistics, subprocess, sys, time, threading, select

MOCK_BASE = os.environ.get("MOCK_BASE", "http://127.0.0.1:8890/v1")
TRIALS_ROOT = os.environ.get("FLOOR_TRIALS_ROOT", "/root/floor-trials-v2")
TRACE_ENV = os.environ.get("RPC_TRACE", "0") == "1"

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def write_models_json(agent_dir):
    agent_dir = pathlib.Path(agent_dir)
    agent_dir.mkdir(parents=True, exist_ok=True)
    models = {"providers": {"prime-inference": {
        "api": "openai-completions", "baseUrl": MOCK_BASE, "apiKey": "sk-bench",
        "models": [{"id": "mock-1", "name": "Mock 1", "api": "openai-completions",
                    "baseUrl": MOCK_BASE, "contextWindow": 128000, "maxTokens": 4096}]}}}
    (agent_dir / "models.json").write_text(json.dumps(models, indent=1))

def scrub_env(base):
    env = {}
    for k, v in base.items():
        if k.startswith(("PI_", "PRIME_", "UV_", "XDG_")):
            continue
        env[k] = v
    return env

def loadavg():
    with open("/proc/loadavg") as f:
        return float(f.read().split()[0])

def zombie_sweep():
    out = subprocess.run(["ps", "-eo", "pid,comm,args"], capture_output=True, text=True).stdout
    me = os.getpid()
    pids = []
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid, comm, args = parts
        pid = int(pid)
        if pid == me:
            continue
        is_product = (comm.startswith("prime-agent")
                      or (comm in ("python", "python3") and "rlm.repl" in args))
        if is_product:
            pids.append(pid)
    for pid in pids:
        try:
            os.kill(pid, 15)
        except ProcessLookupError:
            pass
    if pids:
        time.sleep(1.0)
    return pids

class Conn:
    def __init__(self, proc):
        self.proc = proc
        self.frames = []       # (wall_s, mono_s, rlen, obj)
        self._raw_buf = b""
        self.raw_keep = {}
        self.trace_lines = []
        self.stderr_tail = []
        self._stderr_thread = threading.Thread(target=self._drain_stderr, daemon=True)
        self._stderr_thread.start()
    def _drain_stderr(self):
        for raw in iter(self.proc.stderr.readline, b""):
            line = raw.decode(errors="replace").rstrip("\n")
            wall = time.time()
            if line.startswith("[RPCTRACE"):
                self.trace_lines.append((wall, line))
            self.stderr_tail.append((wall, line))
            if len(self.stderr_tail) > 20000:
                self.stderr_tail.pop(0)
    def _consume(self, keep_raw=False):
        fd = self.proc.stdout.fileno()
        os.set_blocking(fd, False)
        try:
            chunk = os.read(fd, 1 << 20)
        except (BlockingIOError, OSError):
            chunk = b""
        if chunk:
            self._raw_buf += chunk
        while b"\n" in self._raw_buf:
            raw, self._raw_buf = self._raw_buf.split(b"\n", 1)
            if not raw.strip():
                continue
            try:
                obj = json.loads(raw)
            except ValueError:
                continue
            self.frames.append((time.time(), time.monotonic(), len(raw), obj))
            if keep_raw and obj.get("type") == "response" and obj.get("id"):
                self.raw_keep[obj["id"]] = raw
    def read_until_response(self, rid, timeout=60.0, keep_raw=False):
        # ARRIVAL-ACCURATE: select only waits while nothing arrived; the
        # scan happens immediately after every consume, before any re-select.
        fd = self.proc.stdout.fileno()
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            ready, _, _ = select.select([fd], [], [], 0.05)
            if ready:
                self._consume(keep_raw=keep_raw)
                for _, _, rlen, obj in self.frames:
                    if obj.get("type") == "response" and obj.get("id") == rid:
                        idx = [o for _,_,_,o in self.frames].index(obj)
                        return obj, rlen, self.frames[idx][0]
            if self.proc.poll() is not None and not self._raw_buf and not self.frames:
                raise RuntimeError(f"rpc exited rc={self.proc.returncode}; "
                                   f"stderr_tail={''.join(x[1] for x in self.stderr_tail)[-1500:]}")
        raise TimeoutError(f"no response for {rid} in {timeout}s")
    def send(self, obj):
        self.proc.stdin.write((json.dumps(obj) + "\n").encode())
        self.proc.stdin.flush()
    def drain_events(self, idle_s=0.35, max_s=8.0):
        fd = self.proc.stdout.fileno()
        t0 = time.monotonic()
        last = t0
        while time.monotonic() - t0 < max_s:
            ready, _, _ = select.select([fd], [], [], 0.05)
            if ready:
                self._consume()
                last = time.monotonic()
            elif time.monotonic() - last > idle_s:
                break
        return last

def trace_between(conn, lo_wall, hi_wall):
    return [l for (w, l) in conn.trace_lines if lo_wall <= w <= hi_wall]

def parse_marks(lines):
    out = []
    for l in lines:
        parts = {}
        for tok in l.strip("[]").split():
            if "=" in tok:
                k, v = tok.split("=", 1)
                parts[k] = v
        out.append(parts)
    return out

def last_call_marks(marks):
    idx = 0
    for i, m in enumerate(marks):
        if m.get("tag") == "read":
            idx = i
    return marks[idx:]

def run_trial(mode, i, binpath, root, tag=None):
    label = tag if tag else f"{mode}-{i:02d}"
    trial = os.path.join(root, label)
    if os.path.isdir(trial):
        shutil.rmtree(trial)
    os.makedirs(trial, exist_ok=True)
    agent = os.path.join(trial, "agent")
    write_models_json(agent)
    for name in ("auth.json", "settings.json"):
        src = os.path.join("/root/.prime/agent", name)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(agent, name))
    proj = os.path.join(trial, "proj")
    home = os.path.join(trial, "home")
    tmp = os.path.join(trial, "tmp")
    for d in (proj, home, tmp):
        os.makedirs(d, exist_ok=True)
    args = [binpath, "--mode", "rpc",
            "--provider", "prime-inference", "--model", "mock-1",
            "--daemon-socket", os.path.join(trial, "d.sock")]
    env = scrub_env(os.environ)
    env.update({"HOME": home, "TMPDIR": tmp,
                "PRIME_AGENT_CODING_AGENT_DIR": agent,
                "PRIME_API_KEY": "sk-bench",
                "RUST_LOG": "error",
                "PATH": "/root/.cargo/bin:/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"})
    if TRACE_ENV:
        env["PRIME_AGENT_RPC_TRACE"] = "1"
    venv_env_path = os.path.join(TRIALS_ROOT, "venv-env.json")
    if os.path.exists(venv_env_path):
        env.update(json.load(open(venv_env_path)))
    else:
        env.update({"UV_CACHE_DIR": "/root/floor-uv-cache",
                    "UV_PYTHON_INSTALL_DIR": "/root/floor-uv-python"})
    receipt = {"trial": trial, "mode": mode, "argv_tail": args[1:]}
    zombie_sweep()
    while loadavg() > 1.0:
        time.sleep(2.0)
    t_spawn_wall, t_spawn_mono = time.time(), time.monotonic()
    proc = subprocess.Popen(args, cwd=proj, env=env,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    conn = Conn(proc)
    receipt["commands"] = []
    def do(cid, obj, settle=0.35):
        t0w, t0m = time.time(), time.monotonic()
        conn.send({"id": cid, **obj})
        r, rlen, tw = conn.read_until_response(cid, keep_raw=True)
        t1m = time.monotonic()
        marks = last_call_marks(parse_marks(trace_between(conn, t0w - 0.05, tw + 0.2))) if TRACE_ENV else []
        raw = conn.raw_keep.get(cid)
        rec = {"id": cid, "cmd": obj.get("type"), "ok": r.get("success"),
               "ms": (t1m - t0m) * 1000.0, "send_wall": t0w, "resp_wall": tw,
               "resp_bytes": rlen, "marks": marks,
               "raw_sha256": (hashlib.sha256(raw).hexdigest() if raw is not None else None),
               "err": r.get("error")}
        receipt["commands"].append(rec)
        if settle:
            conn.drain_events(idle_s=settle, max_s=settle + 3.0)
        return r
    try:
        conn.send({"type": "get_state", "id": "rdy"})
        r, _, tw = conn.read_until_response("rdy")
        t_ready = time.monotonic()
        receipt["launch_to_ready_ms"] = (t_ready - t_spawn_mono) * 1000.0
        conn.drain_events(idle_s=8.0, max_s=8.0)
        if mode == "battery":
            for j in range(16):
                do(f"st{j+1}", {"type": "get_state"}, settle=0.05)
            for j in range(16):
                do(f"gm{j+1}", {"type": "get_messages"}, settle=0.05)
            for j in range(8):
                do(f"sts{j+1}", {"type": "get_session_stats"}, settle=0.05)
            for j in range(8):
                do(f"stl{j+1}", {"type": "set_thinking_level", "level": "low"}, settle=0.05)
            for j in range(4):
                do(f"sac{j+1}", {"type": "set_auto_compaction", "enabled": True}, settle=0.35)
            for j in range(4):
                do(f"sfm{j+1}", {"type": "set_follow_up_mode", "mode": "all"}, settle=0.35)
            for j in range(2):
                do(f"ssn{j+1}", {"type": "set_session_name", "name": "floor-bench"}, settle=0.35)
            for j in range(2):
                do(f"gam{j+1}", {"type": "get_available_models"}, settle=0.35)
            do("cam", {"type": "cycle_model"}, settle=0.35)
        elif mode == "stream":
            cids = [f"ps{j+1}" for j in range(8)]
            t0w = time.time()
            t0m = time.monotonic()
            for cid in cids:
                conn.send({"id": cid, "type": "get_state"})
            t_send_done = time.monotonic()
            deadline = time.monotonic() + 30.0
            arrivals = {}
            while len(arrivals) < len(cids) and time.monotonic() < deadline:
                ready, _, _ = select.select([conn.proc.stdout.fileno()], [], [], 0.05)
                if ready:
                    conn._consume()
                for tw2, tm2, rlen, obj in conn.frames:
                    if obj.get("type") == "response" and obj.get("id") in cids and obj["id"] not in arrivals:
                        arrivals[obj["id"]] = (tw2, tm2, rlen, obj)
            t_last = time.monotonic()
            receipt["pipeline"] = {"send_loop_ms": (t_send_done - t0m) * 1000.0,
                                  "send_to_last_response_ms": (t_last - t_send_done) * 1000.0}
            for cid in cids:
                if cid in arrivals:
                    tw2, tm2, rlen, obj = arrivals[cid]
                    receipt["commands"].append({
                        "id": cid, "cmd": "get_state", "ok": obj.get("success"),
                        "ms": (tw2 - t0w) * 1000.0, "send_wall": t0w, "resp_wall": tw2,
                        "resp_bytes": rlen, "marks": [], "pipelined": True})
        receipt["frames_n"] = len(conn.frames)
        t0m3 = time.monotonic()
        proc.stdin.close()
        rc = proc.wait(timeout=120)
        receipt["stdin_close_to_exit_ms"] = (time.monotonic() - t0m3) * 1000.0
        receipt["exit_code"] = rc
    finally:
        if proc.poll() is None:
            proc.kill()
    receipt["stderr_tail_last40"] = [x[1] for x in conn.stderr_tail[-40:]]
    receipt["trace_lines_total"] = len(conn.trace_lines)
    raw_dir = os.path.join(trial, "raw")
    os.makedirs(raw_dir, exist_ok=True)
    for rid, rawb in sorted(conn.raw_keep.items()):
        with open(os.path.join(raw_dir, f"resp-{rid}.json"), "wb") as f:
            f.write(rawb)
    return receipt

def main():
    mode = sys.argv[1]
    trials = int(sys.argv[2])
    binpath = sys.argv[3]
    out_json = sys.argv[4]
    root = TRIALS_ROOT
    os.makedirs(root, exist_ok=True)
    # copy the venv env from the primary trials root
    src_venv = "/root/floor-trials/venv-env.json"
    if os.path.exists(src_venv) and not os.path.exists(os.path.join(root, "venv-env.json")):
        shutil.copy(src_venv, os.path.join(root, "venv-env.json"))
    results = {"mode": mode, "bin": binpath, "bin_sha": sha256_file(binpath),
               "trials": [], "trace_env": TRACE_ENV, "driver": "v2-arrival-accurate"}
    for i in range(trials):
        r = run_trial(mode, i, binpath, root)
        results["trials"].append(r)
        print(f"[{mode}] trial {i} done launch={r.get('launch_to_ready_ms')}", flush=True)
    def collect(pred):
        vals = []
        for t in results["trials"]:
            for c in t["commands"]:
                if pred(c):
                    vals.append(c["ms"])
        return vals
    sums = {}
    for name, pred in [
        ("get_state", lambda c: c["cmd"] == "get_state" and not c.get("pipelined")),
        ("get_messages", lambda c: c["cmd"] == "get_messages"),
        ("get_session_stats", lambda c: c["cmd"] == "get_session_stats"),
        ("set_thinking_level", lambda c: c["cmd"] == "set_thinking_level"),
        ("set_auto_compaction", lambda c: c["cmd"] == "set_auto_compaction"),
        ("set_follow_up_mode", lambda c: c["cmd"] == "set_follow_up_mode"),
        ("set_session_name", lambda c: c["cmd"] == "set_session_name"),
        ("get_available_models", lambda c: c["cmd"] == "get_available_models"),
        ("cycle_model", lambda c: c["cmd"] == "cycle_model"),
        ("get_state_pipelined", lambda c: c.get("pipelined")),
    ]:
        vals = sorted(collect(pred))
        if vals:
            sums[name] = {"n": len(vals), "min": round(vals[0], 3),
                         "p50": round(statistics.median(vals), 3), "max": round(vals[-1], 3),
                         "values": [round(x, 3) for x in vals]}
    results["summary"] = sums
    with open(out_json, "w") as f:
        json.dump(results, f, indent=1)
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != 'values'} for k, v in sums.items()}, indent=1))

if __name__ == "__main__":
    main()
