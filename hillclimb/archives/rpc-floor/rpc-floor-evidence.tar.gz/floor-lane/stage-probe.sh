#!/bin/bash
# Stage tip bin, build probe bin, run decompose legs (VM side)
set -x
cd /root/prime-agent-rust
mkdir -p /root/bins
cp target/release/prime-agent /root/bins/prime-agent-tip
sha256sum /root/bins/prime-agent-tip > /root/bins/prime-agent-tip.sha
cat /root/bins/prime-agent-tip.sha

# apply the probe patch (uncommitted)
git checkout -- . 2>/dev/null
git apply --check /root/floor-lane/floor-probe.patch && git apply /root/floor-lane/floor-probe.patch
echo PATCH_RC $?
git status --short
cargo build --release --locked --bin prime-agent > /root/probe-build.log 2>&1
rc=$?
echo PROBE_BUILD_RC $rc
if [ $rc -eq 0 ]; then
  cp target/release/prime-agent /root/bins/prime-agent-probe
  sha256sum /root/bins/prime-agent-probe > /root/bins/prime-agent-probe.sha
  cat /root/bins/prime-agent-probe.sha
fi
# restore clean tree (probe is binary-only evidence)
git checkout -- .
git status --short
echo STAGE_DONE
