#!/bin/bash
# Decompose runner: mock on 8890 + probe_v09 preflights + probe legs
set -x
cd /root/floor-lane
mkdir -p /root/floor-results
# mock provider (bench package import)
if [ ! -f /root/floor-lane/bench/__init__.py ]; then mkdir -p bench/drivers; touch bench/__init__.py; fi
if [ ! -f bench/drivers/__init__.py ]; then touch bench/drivers/__init__.py; fi
cp mock_provider.py mock_state.py bench/drivers/
pkill -f mock_provider.py 2>/dev/null
sleep 0.5
nohup python3 -m bench.drivers.mock_provider /root/floor-lane/rpc-script.json 8890 > /root/floor-lane/mock.log 2>&1 &
sleep 1.0
curl -s http://127.0.0.1:8890/v1/models | head -c 120; echo
echo MOCK_UP
