#!/bin/bash
# rpc-floor decompose runner (VM side)
set -x
mkdir -p /root/floor-lane/bench/drivers /root/floor-trials
cp /root/floor-lane/mock_provider.py /root/floor-lane/mock_state.py /root/floor-lane/__init__.py /root/floor-lane/bench/drivers/ 2>/dev/null
touch /root/floor-lane/bench/__init__.py
# mock script
cat > /root/floor-lane/rpc-script.json <<'EOF'
{"responses":[{"text":"ok"}]}
EOF
# venv env json for the driver
cat > /root/floor-trials/venv-env.json <<'EOF'
{
 "PRIME_AGENT_KERNEL_VENV": "/root/bench/global/rust/kernel-venv",
 "UV_CACHE_DIR": "/root/bench/global/rust/uv-cache",
 "UV_PYTHON_INSTALL_DIR": "/root/.local/share/uv/python",
 "XDG_CACHE_HOME": "/root/bench/global/rust/xdg-cache"
}
EOF
echo RUNNER_PREP_DONE
