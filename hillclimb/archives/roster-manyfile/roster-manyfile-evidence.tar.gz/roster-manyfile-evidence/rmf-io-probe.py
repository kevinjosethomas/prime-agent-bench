#!/usr/bin/env python3
"""Fleet I/O advisory v1.0 probe pair (roster-manyfile lane):
  fresh: >=40 ISOLATED fresh-file write+fsync(sync_all)+rename+stat ops,
         spaced 0.5s apart (never back-to-back streams)
  fsync: >=20 repeat-fsync samples on one open 4KB file
Verdicts are HOST-RELATIVE (stall-rate/max vs the campaign's own pre-gate
band); every leg is labeled, no absolute ceiling is assumed (NO-CEILING).
Usage: rmf-io-probe.py fresh <n> <base_path>
       rmf-io-probe.py fsync <n> <path>
"""
import os, statistics, sys, time

def fresh(n, base):
    stable = base + ".stable"
    data = os.urandom(4096)
    lat = []
    for i in range(n):
        tmp = base + ".tmp"
        t0 = time.perf_counter()
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.rename(tmp, stable)
        os.stat(stable)
        lat.append((time.perf_counter() - t0) * 1000.0)
        if i + 1 < n:
            time.sleep(0.5)  # the v1.0 isolated spacing
    try:
        os.unlink(stable)
    except OSError:
        pass
    lat.sort()
    stall20 = sum(1 for x in lat if x > 20.0)
    big = sum(1 for x in lat if x > 50.0)
    rate20 = 100.0 * stall20 / len(lat)
    print("RMF_IO_FRESH n=%d min=%.2f p50=%.2f p90=%.2f max=%.2f stall20=%d gt50=%d rate20=%.1f%%" % (
        len(lat), lat[0], statistics.median(lat), lat[int(len(lat)*0.9)-1], lat[-1],
        stall20, big, rate20))

def fsync_probe(n, path):
    lat = []
    data = os.urandom(4096)
    with open(path, "wb+") as f:
        for _ in range(n):
            f.seek(0)
            f.write(data)
            t0 = time.perf_counter()
            os.fsync(f.fileno())
            lat.append((time.perf_counter() - t0) * 1000.0)
    os.unlink(path)
    lat.sort()
    stall20 = sum(1 for x in lat if x > 20.0)
    big = sum(1 for x in lat if x > 50.0)
    rate20 = 100.0 * stall20 / len(lat)
    print("RMF_IO_FSYNC n=%d min=%.2f p50=%.2f p90=%.2f max=%.2f stall20=%d gt50=%d rate20=%.1f%%" % (
        len(lat), lat[0], statistics.median(lat), lat[int(len(lat)*0.9)-1], lat[-1],
        stall20, big, rate20))

if __name__ == "__main__":
    mode = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv) > 2 else (40 if mode == "fresh" else 20)
    if mode == "fresh":
        base = sys.argv[3] if len(sys.argv) > 3 else "/root/rmf-io-fresh"
        fresh(n, base)
    else:
        path = sys.argv[3] if len(sys.argv) > 3 else "/root/rmf-io-fsync.bin"
        fsync_probe(n, path)
