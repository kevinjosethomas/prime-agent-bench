#!/usr/bin/env python3
"""roster-manyfile characterization driver (VM): the cold-scan scaling curve.

Per tier in TIERS: SCAN_SLOTS fresh probe processes (pass 0 = cold) + the
meta/folds decomposition slots; noop CPU calibration + loadavg at every
slot boundary; the fleet I/O advisory v1.0 probe pair at the pre/mid/post
leg boundaries (fresh 40 @0.5s + repeat-fsync 20); a page-cache-cold
confirm leg (drop_caches) on the tier-10 fixture, labeled separately.

Everything appends to results.jsonl. No arms: one binary, one fixture
family, the N-slope is the deliverable.
"""
import json, os, statistics, subprocess, sys, time

PROBE = "/root/prime-agent-rust/target/release/examples/roster_manyfile_probe"
FX = "/root/rmf/fixtures"
RESULTS = "/root/rmf/results.jsonl"
TIERS = [1, 10, 50, 100, 250]
SCAN_SLOTS = 5
SCAN_PASSES = 7
DECOMP_SLOTS = 2
DECOMP_PASSES = 3
IO_FRESH_N = 40
IO_FSYNC_N = 20

def emit(obj):
    obj["t"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    with open(RESULTS, "a") as f:
        f.write(json.dumps(obj) + "\n")
    print("EMIT", json.dumps(obj)[:220], flush=True)

def calibrate():
    t0 = time.perf_counter()
    x = 0
    for i in range(2_500_000):
        x += i % 7
    loop_s = time.perf_counter() - t0
    loadavg = open("/proc/loadavg").read().strip()
    return {"noop_loop_s": round(loop_s, 4), "loadavg": loadavg, "calib_x": x}

def io_gate(label):
    out = subprocess.run([sys.executable, "/root/rmf/io-probe.py", "fresh",
                          str(IO_FRESH_N), "/root/rmf/io-fresh"],
                         capture_output=True, text=True, timeout=600)
    fresh = out.stdout.strip()
    emit({"kind": "io_fresh", "label": label, "out": fresh,
          "rc": out.returncode, "stderr": out.stderr[:200]})
    out = subprocess.run([sys.executable, "/root/rmf/io-probe.py", "fsync",
                          str(IO_FSYNC_N), "/root/rmf/io-fsync.bin"],
                         capture_output=True, text=True, timeout=600)
    fsync = out.stdout.strip()
    emit({"kind": "io_fsync", "label": label, "out": fsync,
          "rc": out.returncode, "stderr": out.stderr[:200]})
    return fresh, fsync

def run_probe(mode, tier, passes, slot, extra=None):
    d = os.path.join(FX, f"tier-{tier}")
    started = time.perf_counter()
    p = subprocess.run([PROBE, mode, d, str(passes)], capture_output=True, text=True)
    wall = time.perf_counter() - started
    lines = [l for l in p.stdout.splitlines() if l.startswith("PROBE_")]
    rec = {"kind": f"probe_{mode}", "tier": tier, "slot": slot, "rc": p.returncode,
           "wall_s": round(wall, 3), "lines": lines}
    if extra:
        rec.update(extra)
    emit(rec)
    return rec

def drop_caches():
    os.system("sync")
    with open("/proc/sys/vm/drop_caches", "w") as f:
        f.write("3\n")

def main():
    only = sys.argv[1] if len(sys.argv) > 1 else "all"
    emit({"kind": "campaign_start", "tiers": TIERS, "scan_slots": SCAN_SLOTS,
          "scan_passes": SCAN_PASSES, "decomp_slots": DECOMP_SLOTS,
          "probe": PROBE})
    if only in ("all", "campaign"):
        io_gate("pre")
        for tier in TIERS:
            for slot in range(1, SCAN_SLOTS + 1):
                cal = calibrate()
                run_probe("scan", tier, SCAN_PASSES, slot, {"calib": cal})
            for slot in range(1, DECOMP_SLOTS + 1):
                cal = calibrate()
                run_probe("meta", tier, DECOMP_PASSES, slot, {"calib": cal})
                run_probe("folds", tier, DECOMP_PASSES, slot)
            io_gate(f"mid_after_tier_{tier}")
        io_gate("post")
    if only in ("all", "coldcache"):
        # page-cache-cold confirm leg (tier 10): drop_caches per trial,
        # labeled separately from the fold-cost curve (a different regime).
        for trial in range(1, 3):
            drop_caches()
            cal = calibrate()
            run_probe("scan", 10, 1, trial, {"calib": cal, "drop_caches": True})
        io_gate("post_coldcache")
    emit({"kind": "campaign_end"})

if __name__ == "__main__":
    main()
