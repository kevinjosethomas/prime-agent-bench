from prime_sandboxes import SandboxClient, APIClient, CreateSandboxRequest, StartCommand
import json
c = SandboxClient(APIClient())
s = c.create(CreateSandboxRequest(
    name="hillclimb-roster-manyfile", docker_image="ubuntu:22.04",
    cpu_cores=16.0, memory_gb=32.0, disk_size_gb=120.0,
    timeout_minutes=1440,
    start_command=StartCommand(executable="tail", args=["-f", "/dev/null"])))
print(json.dumps({"id": s.id, "name": s.name}), flush=True)
c.wait_for_creation(s.id)
print("READY", s.id, "vm:", c.is_vm(s.id), flush=True)
