//! The many-file roster scan probe (VM-only, untracked, never shipped):
//! cold/warm pass timings of the saved-session roster scan over a fixture
//! dir, with a sha256 row oracle over the scan's own row order.
//!
//! Arms:
//!   scan  <dir> [passes]  list_sessions per pass (pass 0 = the cold pass:
//!                         empty scan-state cache, warm page cache), rows
//!                         hashed in scan order
//!   meta  <dir> [passes]  the scan's metadata pass alone (readdir + per-file
//!                         stat + the newest-first sort)
//!   folds <dir> [passes]  per-file read_session_info in metadata order (the
//!                         fold alone, no gate/sort/collect)

use std::{
    env,
    path::{Path, PathBuf},
    time::{Instant, SystemTime},
};

use pa_daemon::session_store::{list_sessions, read_session_info, SessionInfo};
use sha2::{Digest, Sha256};

fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

fn usage_json(usage: &Option<pa_daemon::session_usage::SessionUsageSummary>) -> String {
    match usage {
        Some(value) => serde_json::to_string(value).unwrap_or_else(|_| "ERR".into()),
        None => "-".into(),
    }
}

/// The canonical row serialization the oracle hashes: every SessionInfo
/// field, in scan order.
fn canonical_row(info: &SessionInfo) -> String {
    let model = match &info.model {
        Some((provider, model)) => format!("{provider}/{model}"),
        None => "-".to_string(),
    };
    format!(
        "{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
        info.path.display(),
        info.id,
        info.cwd,
        info.name.as_deref().unwrap_or("-"),
        info.state.as_deref().unwrap_or("-"),
        model,
        info.thinking_level.as_deref().unwrap_or("-"),
        info.parent_session_path.as_deref().unwrap_or("-"),
        info.rlm_depth,
        info.created,
        info.modified,
        info.message_count,
        info.first_message,
        info.all_messages_text.chars().count(),
        info.all_messages_text,
        usage_json(&info.usage),
    )
}

fn rows_oracle(rows: &[SessionInfo]) -> String {
    let mut hasher = Sha256::new();
    for row in rows {
        hasher.update(canonical_row(row).as_bytes());
    }
    hex(&hasher.finalize())
}

/// The scan's own metadata pass (session_scan::list_sessions_with's shape):
/// readdir, the .jsonl filter, the per-file mtime stat, newest-first sort.
fn metadata_order(dir: &Path) -> Vec<PathBuf> {
    let Ok(read) = std::fs::read_dir(dir) else {
        return Vec::new();
    };
    let mut files: Vec<(PathBuf, SystemTime)> = read
        .flatten()
        .map(|entry| entry.path())
        .filter(|path| path.extension().and_then(|e| e.to_str()) == Some("jsonl"))
        .filter_map(|path| {
            let modified = std::fs::metadata(&path).and_then(|m| m.modified()).ok()?;
            Some((path, modified))
        })
        .collect();
    files.sort_by_key(|(_, modified)| std::cmp::Reverse(*modified));
    files.into_iter().map(|(path, _)| path).collect()
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let mode = args.get(1).cloned().unwrap_or_else(|| "scan".into());
    let dir = PathBuf::from(args.get(2).cloned().expect("fixture dir"));
    let passes: usize = args
        .get(3)
        .cloned()
        .and_then(|p| p.parse().ok())
        .unwrap_or(7);
    match mode.as_str() {
        "scan" => {
            for pass in 0..passes {
                let started = Instant::now();
                let rows = list_sessions(&dir);
                let scan_ms = started.elapsed().as_secs_f64() * 1000.0;
                let oracle = rows_oracle(&rows);
                println!(
                    "PROBE_SCAN pass={pass} rows={} scan_ms={scan_ms:.3} oracle={oracle}",
                    rows.len()
                );
            }
        }
        "meta" => {
            for pass in 0..passes {
                let started = Instant::now();
                let files = metadata_order(&dir);
                let meta_ms = started.elapsed().as_secs_f64() * 1000.0;
                println!(
                    "PROBE_META pass={pass} files={} meta_ms={meta_ms:.3}",
                    files.len()
                );
            }
        }
        "folds" => {
            for pass in 0..passes {
                let files = metadata_order(&dir);
                let mut rows: Vec<SessionInfo> = Vec::new();
                let mut per_file_ms: Vec<f64> = Vec::new();
                let started = Instant::now();
                for path in &files {
                    let file_started = Instant::now();
                    if let Some(info) = read_session_info(path) {
                        rows.push(info);
                    }
                    per_file_ms.push(file_started.elapsed().as_secs_f64() * 1000.0);
                }
                let folds_ms = started.elapsed().as_secs_f64() * 1000.0;
                per_file_ms.sort_by(|a, b| a.partial_cmp(b).unwrap());
                let len = per_file_ms.len();
                let (min, p50, max) = if len == 0 {
                    (0.0, 0.0, 0.0)
                } else {
                    (
                        per_file_ms[0],
                        per_file_ms[len / 2],
                        per_file_ms[len - 1],
                    )
                };
                let oracle = rows_oracle(&rows);
                println!(
                    "PROBE_FOLDS pass={pass} rows={} folds_ms={folds_ms:.3} per_file_ms_min={min:.3} per_file_ms_p50={p50:.3} per_file_ms_max={max:.3} oracle={oracle}",
                    rows.len()
                );
            }
        }
        _ => {
            eprintln!("unknown mode {mode:?} (scan|meta|folds)");
            std::process::exit(2);
        }
    }
}
