#!/bin/bash
# roster-manyfile lane VM setup: packages + rustup 1.98.1 + clone pinned
# fda40b56a + release build of the (untracked) probe example
set -x
export DEBIAN_FRONTEND=noninteractive
export HOME=/root
export PATH=/root/.cargo/bin:$PATH
TIP=fda40b56a14cd6b3353693261f51a6104c860987
log(){ echo "$(date -u +%H:%M:%S) $*"; }
log "apt start"
apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq git curl ca-certificates build-essential pkg-config libssl-dev python3-pip rsync jq tmux strace >/dev/null 2>&1
log "apt done rc=$?"
if ! command -v rustc >/dev/null 2>&1; then
  curl -fsSL https://sh.rustup.rs | sh -s -- -y --default-toolchain 1.98.1 >/root/rustup.log 2>&1
fi
log "rustc $(rustc --version)"
rm -rf /root/prime-agent-rust
git clone --quiet https://github.com/PrimeIntellect-ai/prime-agent.git /root/prime-agent-rust >/root/clone.log 2>&1
cd /root/prime-agent-rust
git fetch origin rust --quiet >>/root/clone.log 2>&1
ACT=$(git rev-parse origin/rust)
log "ORIGIN_RUST_TIP $ACT"
if [ "$ACT" != "$TIP" ]; then log "TIP_MOVED $ACT"; fi
git checkout --detach $TIP >>/root/clone.log 2>&1
log "repo at $(git rev-parse HEAD)"
mkdir -p crates/pa-daemon/examples
cp /root/rmf-probe.rs crates/pa-daemon/examples/roster_manyfile_probe.rs
log "probe present: $(ls -la crates/pa-daemon/examples/ | tail -2)"
log "BUILD_START"
cargo build --release --example roster_manyfile_probe -p pa-daemon >/root/build.log 2>&1
rc=$?
log "BUILD_RC $rc"
if [ $rc -ne 0 ]; then tail -40 /root/build.log; exit 1; fi
BIN=/root/prime-agent-rust/target/release/examples/roster_manyfile_probe
sha256sum $BIN
stat -c%s $BIN
mkdir -p /root/rmf
log "SETUP_ALL_DONE"
