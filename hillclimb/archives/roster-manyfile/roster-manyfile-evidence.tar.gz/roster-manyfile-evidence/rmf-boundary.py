#!/usr/bin/env python3
"""Boundary mechanism leg: tier 223 (predicted NO thrash: 223x1792=399,616 <=
400,000) vs tier 224 (predicted FULL thrash: 401,408 > 400,000)."""
import json, subprocess, sys, time
sys.path.insert(0, "/root")
PROBE = "/root/prime-agent-rust/target/release/examples/roster_manyfile_probe"
RESULTS = "/root/rmf/results-boundary.jsonl"
def emit(obj):
    obj["t"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    with open(RESULTS, "a") as f:
        f.write(json.dumps(obj) + "\n")
    print("EMIT", json.dumps(obj)[:200], flush=True)
def io_gate(label):
    for kind, path, n in (("fresh", "/root/rmf/io-fresh", 40), ("fsync", "/root/rmf/io-fsync.bin", 20)):
        out = subprocess.run([sys.executable, "/root/rmf/io-probe.py", kind, str(n), path],
                             capture_output=True, text=True, timeout=600)
        emit({"kind": "io_" + kind, "label": label, "out": out.stdout.strip(), "rc": out.returncode})
def slot(tier, slot):
    p = subprocess.run([PROBE, "scan", f"/root/rmf/fixtures/tier-{tier}", "7"],
                       capture_output=True, text=True)
    emit({"kind": "probe_scan", "tier": tier, "slot": slot, "rc": p.returncode,
          "lines": [l for l in p.stdout.splitlines() if l.startswith("PROBE_")]})
def main():
    emit({"kind": "boundary_start"})
    io_gate("pre_boundary")
    for tier in (223, 224):
        for s in range(1, 4):
            slot(tier, s)
        io_gate(f"mid_after_tier_{tier}")
    io_gate("post_boundary")
    emit({"kind": "boundary_end"})
main()
