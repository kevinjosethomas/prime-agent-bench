#!/usr/bin/env python3
"""Build the many-file roster-scan fixture: N copies of the real session,
each with a unique session id (same 36-char shape, byte-identical except
the header id) and a distinct mtime (deterministic newest-first order).

Usage: rmf-build.py <src.jsonl> <dst_dir> <n> [mtime_base]
Writes <dst_dir>/<id>.jsonl per copy plus <dst_dir>/manifest.json.
Deterministic: the id derives from sha256("roster-manyfile-<n>-<i>").
"""
import hashlib, json, os, sys, time

def gen_id(n, i):
    h = hashlib.sha256(f"roster-manyfile-{n:05d}-{i:05d}".encode()).hexdigest()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"

def main():
    src, dst, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
    mtime_base = int(sys.argv[4]) if len(sys.argv) > 4 else 1_750_000_000
    os.makedirs(dst, exist_ok=True)
    with open(src, "rb") as f:
        first = f.readline()
        rest = f.read()
    header = json.loads(first)
    assert header.get("type") == "session", header
    old_id = header["id"]
    assert len(old_id) == 36, old_id
    # byte-identical rewrite of only the id substring in line 1
    prefix, tail = first.split(b'"id":"' , 1)
    id_bytes, after = tail.split(b'"', 1)
    assert len(id_bytes) == 36, id_bytes
    manifest = {"source": os.path.basename(src), "source_sha256": hashlib.sha256(
        open(src, "rb").read()).hexdigest(), "n": n, "files": []}
    for i in range(n):
        sid = gen_id(n, i)
        line1 = prefix + b'"id":"' + sid.encode() + b'"' + after
        assert len(line1) == len(first), (len(line1), len(first))
        path = os.path.join(dst, f"{sid}.jsonl")
        with open(path, "wb") as f:
            f.write(line1)
            f.write(rest)
        os.utime(path, (mtime_base + i * 60, mtime_base + i * 60))
        h = hashlib.sha256()
        with open(path, "rb") as f:
            h.update(f.readline())
            while True:
                chunk = f.read(1 << 20)
                if not chunk:
                    break
                h.update(chunk)
        with open(path, "rb") as f:
            got = json.loads(f.readline())["id"]
        assert got == sid, (got, sid)
        manifest["files"].append({
            "i": i, "file": os.path.basename(path), "id": sid,
            "bytes": os.path.getsize(path), "sha256": h.hexdigest(),
            "mtime": mtime_base + i * 60})
    with open(os.path.join(dst, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=1)
    total = sum(x["bytes"] for x in manifest["files"])
    print(f"RMF_BUILT n={n} dir={dst} total_bytes={total} "
          f"unit_bytes={len(first)+len(rest)} src_sha256={manifest['source_sha256'][:16]}")

if __name__ == "__main__":
    main()
