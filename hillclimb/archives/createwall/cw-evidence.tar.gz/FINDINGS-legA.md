
# createwall lane — leg A (the re-measure at the tip) findings (VM gn6tb3a8488w, ubuntu:22.04 16c/32GB)

## Binaries
- pre  f134e9e55  sha ace10a6d33b2f7acb23c4c5b664b438067591a2a50f167b72bd185604141ff73 (the imageheavy record's base)
- tip  846b3901c  sha 79634670e90a216f1c4d24fe32f337b94f29fbf1135aff9a0f6b1d0417d72f73
- probe tip+instrument-v2 sha 1794ed832022908c53db73b8f5a0d7f03e82528c7a561cc5b1105e5eae3d24e7

## The needle (key_to_needle, ms; 3 trials/arm/cell, interleaved)
- open/fx-real: pre 642/653/655 (p50 653.2) | tip 593/683/692 (p50 683.3) | probe 633/645/707 (p50 645.2) — bands overlap; NO pre->tip needle delta.
  => #3098 did NOT move the fx-real open needle (the retained window carries zero images — the record's honest-negative premise holds at the tip).
- open/fx-mid: pre 450/461/509 (p50 461.3) | tip 461/507/513 (p50 506.7) | probe 454/486/502 (p50 486.4) — bands overlap.
- agents/fx-real (ENTER->chat): pre 613/663/717 (p50 662.8) | tip 613/624/662 (p50 624.3) | probe 611/632/683 (p50 631.8); the roster row paints at 14.2-16.1ms (the record: 15.8-17.4).
- open-cold/fx-real (drop_caches): pre 608/653/677 | tip 614/663/667 — cold adds nothing (matches the record).

## The #3098 phase delta (probe arm vs the record's f134e9e55 probe ledger)
- fx-mid wire (438 msgs): record 19.6ms (with ~9.8ms in-window image share) -> tip 10.8-13.9ms = the record's strip-arm baseline (9.8): THE ELISION REMOVED THE IN-WINDOW IMAGE WIRE SHARE.
- fx-mid frame: 15.0-17.0 (record 17.2 p50 / 21.5 p90; the strip 16.7): p50 unchanged (the render skip targets the visible-image tail, not the open frame).
- fx-real wire: 24.1-31.8 (record 34.1 at f134e9e55, image-free window — cross-VM delta, no image effect).

## The create-tail decomposition at the tip (probe arm p50s, fx-real, the hc2 class)
boot->create_in 67-133 (bimodal) | open#1 57.5 (scan 42.2-44.6, 351 ranges, retained 2762) | THE RESTORE CLASS 75.5 (open#2 36.3 sidecar re-read + foldA ~39.5) 
| pre-persist 30.0 (configure + prefix + foldB) | persist 95 (fdatasync REGIME) | post-persist->corelock 34 | rlm identity 9.6 | sched 0.2 
| record_recovery 64.3 (journal fsync REGIME + a CONCURRENT third sidecar open by the background prewarm — off the response path)
| create_wall measured 589-651 | wire 24-32 | fold 1-3 | frame 6.4-7.4
- foldA + foldB = TWO branch_file_entries serde round-trip clones (2762 entries: ~28-40ms each) — one inside saved_session_context (store#2), one in create.rs (store#1).
- The I/O regime: this VM sits in the ~65ms fresh-write-rename host trap class at ALL 6 boundaries (FRESH_ISOLATED p50 64.4-66.4, stall 100%); the fsync reference class p50 in-band 0.16-0.18 with 1-2 gt50 outliers labeled per boundary. Interleaved arms balance it.

## The cut (target 1, implemented at 07e8ffacb)
The create folds the context ONCE and hands the restore its share: open#2 (sidecar re-read) + foldA are gone; restore_session_model(path, Some(saved)); the create-config adoption reuses the same fold (requested_thinking.or(saved.thinking)).
Expected: -savedctx span (~75ms p50 on fx-real at this VM; -17ms at fx-mid scale).
