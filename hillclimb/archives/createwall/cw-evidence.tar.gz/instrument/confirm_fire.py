#!/usr/bin/env python3
"""Confirm-then-fire the ABBA wall pair (advisory v1.0: fire only a
confirmed HEALTHY window; refuse lulls)."""
import json, re, statistics, subprocess, sys, time

def probe():
    out = {}
    r = subprocess.run(["bash","-c","python3 /root/io_lane/probe-fresh-v3.py /root/cf-fresh 40"],capture_output=True,text=True)
    m = re.search(r"p50=([\d.]+).*gt50=(\d+).*rate20=([\d.]+)", r.stdout)
    if m: out["fresh_p50"], out["fresh_gt50"], out["fresh_rate20"] = float(m.group(1)), int(m.group(2)), float(m.group(3))
    r2 = subprocess.run(["bash","-c","python3 /root/io_lane/probe-fsync-v2.py /root/cf-fsync.bin 50"],capture_output=True,text=True)
    m2 = re.search(r"p50=([\d.]+).*stall20=(\d+).*gt50=(\d+)", r2.stdout)
    if m2: out["fsync_p50"], out["fsync_stall20"], out["fsync_gt50"] = float(m2.group(1)), int(m2.group(2)), int(m2.group(3))
    return out

healthy = lambda p: p.get("fresh_p50", 1e9) < 2.0 and p.get("fresh_gt50", 99) == 0 and p.get("fsync_p50", 1e9) < 1.0 and p.get("fsync_gt50", 99) == 0

attempts = 0
while attempts < 45:
    attempts += 1
    p = probe()
    print(f"CF attempt {attempts}: {json.dumps(p)}", flush=True)
    if healthy(p):
        print("CF_WINDOW_CONFIRMED firing wall pair 8+8", flush=True)
        subprocess.run(["python3","/root/io_lane/io_runner_v3.py","/root/io_lane/cf_matrix.json"],timeout=1200)
        print("CF_WALL_DONE", flush=True)
        break
    time.sleep(25)
else:
    print("CF_NO_HEALTHY_WINDOW", flush=True)
