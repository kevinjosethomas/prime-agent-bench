
from prime_sandboxes import SandboxClient, APIClient, CreateSandboxRequest, StartCommand
import json, sys
c = SandboxClient(APIClient())
s = c.create(CreateSandboxRequest(
    name="hillclimb-createwall", docker_image="ubuntu:22.04",
    cpu_cores=16.0, memory_gb=32.0, disk_size_gb=120.0,
    timeout_minutes=4320,
    start_command=StartCommand(executable="tail", args=["-f", "/dev/null"])))
print(json.dumps({"id": s.id, "name": s.name}), flush=True)
c.wait_for_creation(s.id)
print("READY", s.id, "vm:", c.is_vm(s.id), flush=True)
with open("/home/ubuntu/lane-createwall/vm_id.txt","w") as fh:
    fh.write(s.id + "\n")
