#!/usr/bin/env python3
"""createwall re-measure runner: legs x fixtures x {pre,tip,probe} arms,
advisory v1.0 probes (both classes) at every block boundary, every trial its
own process tree, arms interleaved round-robin per trial index."""
import json, os, subprocess, sys, time, pathlib

BINS = {"pre": "/root/bins/pre/prime-agent",
        "tip": "/root/bins/tip/prime-agent",
        "probe": "/root/bins/probe/prime-agent"}
OUT = pathlib.Path("/root/results-io")
TRIALS = pathlib.Path("/root/trials-io")

def probe(label):
    res = {"label": label, "t": time.time()}
    for name, args in (("fsync", "/root/io_lane/probe-fsync-v2.py /root/probe-fsync.bin 50"),
                       ("fresh", "/root/io_lane/probe-fresh-v3.py /root/probe-fresh 40")):
        r = subprocess.run(["bash", "-c", f"python3 {args}"], capture_output=True, text=True)
        res[name] = r.stdout.strip() or r.stderr.strip()[-200:]
    with open(OUT / "probes.jsonl", "a") as fh:
        fh.write(json.dumps(res) + "\n")
    print("PROBE", label, json.dumps(res), flush=True)
    return res

def run_trial(leg, fx_label, fx_path, arm, idx, drop=False):
    tdir = TRIALS / f"{leg}-{fx_label}-{arm}-{idx:02d}"
    if tdir.exists():
        import shutil; shutil.rmtree(tdir)
    binary = BINS[arm]
    cmd = ["python3", "/root/io_lane/io_open_bench.py",
           "--trial-dir", str(tdir), "--binary", binary,
           "--fixture", fx_path, "--fixture-label", fx_label,
           "--leg", ("open" if leg == "open-cold" else leg),
           "--label", f"{leg}-{fx_label}-{arm}-{idx}"]
    if fx_label.startswith("fx-mid"):
        cmd += ["--needle-chat", "add curated session blacklist"]
    if leg == "open-cold":
        cmd += ["--drop-caches"]
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    print(f"TRIAL {leg} {fx_label} {arm} {idx} rc={r.returncode} dur={time.time()-t0:.1f}s", flush=True)
    print((r.stdout or "")[-400:], flush=True)
    if r.returncode != 0:
        print("STDERR", (r.stderr or "")[-1500:], flush=True)
    return r.returncode

def main():
    matrix = json.loads(open(sys.argv[1]).read())
    OUT.mkdir(parents=True, exist_ok=True)
    TRIALS.mkdir(parents=True, exist_ok=True)
    probe("pre")
    for block in matrix:
        leg, fx_label, fx_path, arms, n = block
        for i in range(n):
            for arm in arms:
                rc = run_trial(leg, fx_label, fx_path, arm, i)
                if rc != 0:
                    print(f"BLOCK-FAIL {leg} {fx_label} {arm} {i}", flush=True)
        probe(f"after-{leg}-{fx_label}")
    probe("post")
    print("MATRIX_DONE", flush=True)

main()
