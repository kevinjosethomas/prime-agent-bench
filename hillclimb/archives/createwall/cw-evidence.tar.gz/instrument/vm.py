
#!/usr/bin/env python3
"""createwall lane VM ops: run / up / down (prime_sandboxes)."""
from prime_sandboxes import SandboxClient, APIClient
import sys, json
SID = "gn6tb3a8488wjl12nuno5l2f"
c = SandboxClient(APIClient())
def main():
    mode = sys.argv[1]
    if mode == "run":
        cmd = open(sys.argv[2]).read()
        r = c.execute_command(SID, cmd)
        d = r.model_dump() if hasattr(r, "model_dump") else {}
        print(json.dumps(d, default=str)[:24000])
    elif mode == "up":
        r = c.upload_file(SID, sys.argv[3], sys.argv[2])
        print("uploaded", sys.argv[2], "->", sys.argv[3])
    elif mode == "down":
        c.download_file(SID, sys.argv[2], sys.argv[3])
        print("downloaded", sys.argv[2], "->", sys.argv[3])
main()
