#!/usr/bin/env python3
"""Phase-ledger analysis v2 for one io_open_bench trial directory:
the ordered per-role mark timeline (consecutive deltas), the open#1/open#2
store-open spans, the restore decomposition (savedctx/registry/ready), and
the create-tail spans (the unmarked ~140-240ms class decomposition)."""
import json, sys, pathlib

trial = pathlib.Path(sys.argv[1])
trace = json.load(open(trial / "trace.json"))
meta = trace["meta"]

recs = []
tp = trial / "trace.jsonl"
if tp.exists():
    for line in open(tp):
        try:
            recs.append(json.loads(line))
        except Exception:
            pass

procs = {}
for r in recs:
    if r.get("anchor"):
        procs[r["pid"]] = r["argv"]
pid_role = {}
for pid, argv in procs.items():
    if "--mode daemon" in argv and "worker" not in argv:
        pid_role[pid] = "supervisor"
    elif "--mode worker" in argv or "worker" in argv:
        pid_role[pid] = "worker"
    else:
        pid_role[pid] = "tui"

seq = []
for r in recs:
    if r.get("anchor"):
        continue
    seq.append({"wall": r["wall_ms"], "t": r["t_ms"], "v": r.get("v"),
                "s": r.get("s"), "pid": r["pid"], "phase": r["phase"]})
seq.sort(key=lambda r: r["wall"])

def timeline(role):
    out = []
    prev = None
    for r in seq:
        if pid_role.get(r["pid"]) != role:
            continue
        d = round(r["wall"] - prev, 1) if prev is not None else 0.0
        out.append({"phase": r["phase"], "v": r.get("v"), "wall": round(r["wall"], 1), "d": d})
        prev = r["wall"]
    return out

def marks(role, phase):
    return [r for r in seq if pid_role.get(r["pid"]) == role and r["phase"] == phase]

def first(role, phase):
    m = marks(role, phase)
    return m[0] if m else None

def span(role, a, b, occurrence=0):
    ma, mb = marks(role, a), marks(role, b)
    if len(ma) <= occurrence or not mb:
        return None
    ra = ma[occurrence]
    rb = min((m for m in mb if m["wall"] >= ra["wall"]), key=lambda m: m["wall"], default=None)
    return round(rb["wall"] - ra["wall"], 1) if rb else None

def val(role, phase):
    r = first(role, phase)
    return r.get("v") if r else None

out = {
    "trial": str(trial), "label": meta.get("label"), "leg": meta["leg"],
    "fixture_label": meta.get("fixture_label"),
    "ttff_ms": trace.get("ttff_ms"),
    "summary": trace.get("summary"),
    "completed": trace.get("completed"),
    "worker_socket_ms": None,
    "phases": {
        # TUI side
        "tui_connected": span("tui","open_start","connected"),
        "tui_create_wall": span("tui","create_sent","create_done"),
        "tui_attach_wire": span("tui","attach_sent","attach_done"),
        "wire_msgs": val("tui","attach_wire_msgs"),
        "tui_fold": span("tui","attach_done","reconstructed"),
        "tui_roster": span("tui","reconstructed","roster_done"),
        "tui_hb": span("tui","roster_done","hb_done"),
        "tui_bash": span("tui","hb_done","bash_done"),
        "tui_stats": span("tui","bash_done","stats"),
        "tui_rebuild": span("tui","stats","rebuilt"),
        "tui_first_frame": span("tui","rebuilt","frame_done"),
        "compose_rows": val("tui","compose_done"),
        "layout_entries": val("tui","layout_start"),
        # worker create path
        "w_create_in_to_resume_open": span("worker","create_in","resume_open_start"),
        "w_resume_open": span("worker","resume_open_start","resume_open_done"),
        "w_lease_store_open": span("worker","resume_open_start","store_open_done"),
        "w_open1": span("worker","store_open_start","store_open_done", occurrence=0),
        "w_open2": span("worker","store_open_start","store_open_done", occurrence=1),
        "w_open3": span("worker","store_open_start","store_open_done", occurrence=2),
        "w_open_count": len(marks("worker","store_open_start")),
        "w_open_done_to_restore": span("worker","resume_open_done","restore_start"),
        "w_restore": span("worker","restore_start","restore_done"),
        "w_savedctx": span("worker","savedctx_start","savedctx_done"),
        "w_registry": span("worker","registry_start","registry_done"),
        "w_ready_wait": span("worker","ready_wait_start","ready_wait_done"),
        "w_restore_to_persist": span("worker","restore_done","create_persist_start"),
        "w_persist": span("worker","create_persist_start","create_persist_done"),
        "w_persist_to_corelocked": span("worker","create_persist_done","core_locked_summary_done"),
        "w_tail_settings": span("worker","tail_settings_start","tail_settings_done"),
        "w_corelocked_to_rlm": span("worker","core_locked_summary_done","rlm_identity_done"),
        "w_rlm_to_sched": span("worker","rlm_identity_done","sched_jobs_done"),
        "w_sched": span("worker","rlm_identity_done","sched_jobs_done"),
        "w_sched_to_recovery": span("worker","sched_jobs_done","recovery_done"),
        "w_recovery": span("worker","sched_jobs_done","recovery_done"),
        "w_recovery_to_serialized": span("worker","recovery_done","summary_serialized"),
        "w_serialized_to_trimmed": span("worker","summary_serialized","trimmed"),
        "w_scan": span("worker","store_open_start","store_window_open", occurrence=0),
        "w_rows": val("worker","store_rows"),
        "w_retained": val("worker","sf_retained_rows"),
        "w_scan_bytes": val("worker","sf_scan_done"),
        "w_scan_ranges": val("worker","sf_scan_ranges"),
        "w_ctx_msgs": val("worker","ctx_msgs"),
        "w_ctx_span": span("worker","ctx_build_start","ctx_msgs"),
        "w_attach_build": span("worker","attach_in","attach_built"),
        "w_attach_msgs": val("worker","attach_msgs_n"),
        "prefix_settings_read": bool(marks("worker","prefix_settings_read")),
    },
    "worker_timeline": timeline("worker"),
    "tui_timeline": timeline("tui"),
    "sockets": trace.get("worker_sockets"),
    "seed_sha_post": trace.get("seed_sha_post"),
}
print(json.dumps(out, indent=1))
