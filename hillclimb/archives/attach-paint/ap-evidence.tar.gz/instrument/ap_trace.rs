// PROBE-ONLY instrument (attach-paint lane); never ships on any branch.
use std::io::Write;
use std::sync::{Mutex, OnceLock};
use std::time::Instant;

static START: OnceLock<Instant> = OnceLock::new();
static SINK: OnceLock<Option<Mutex<std::fs::File>>> = OnceLock::new();

fn sink() -> Option<&'static Mutex<std::fs::File>> {
    SINK.get_or_init(|| {
        std::env::var("PRIME_AGENT_AP_TRACE").ok().and_then(|path| {
            std::fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(path)
                .ok()
                .map(Mutex::new)
        })
    })
    .as_ref()
}

pub fn mark_n(phase: &str, value: f64) {
    let Some(sink) = sink() else { return };
    let start = START.get_or_init(Instant::now);
    let t_ms = start.elapsed().as_secs_f64() * 1000.0;
    if let Ok(mut file) = sink.lock() {
        let _ = writeln!(file, "{{\"phase\":\"{phase}\",\"t_ms\":{t_ms:.3},\"value\":{value}}}");
        let _ = file.flush();
    }
}

pub fn mark(phase: &str) {
    let Some(sink) = sink() else { return };
    let start = START.get_or_init(Instant::now);
    let t_ms = start.elapsed().as_secs_f64() * 1000.0;
    if let Ok(mut file) = sink.lock() {
        let _ = writeln!(file, "{{\"phase\":\"{phase}\",\"t_ms\":{t_ms:.3}}}");
        let _ = file.flush();
    }
}
