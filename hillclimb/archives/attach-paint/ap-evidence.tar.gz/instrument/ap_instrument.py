#!/usr/bin/env python3
"""attach-paint phase instrument: patch a PROBE COPY of the repo with an
env-gated JSONL phase trace (PRIME_AGENT_AP_TRACE=<path>), then the caller
builds bin-probe. Measurement-only; the probe tree never ships."""
import sys, pathlib

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/root/probe-rust")
TUI = ROOT / "crates/pa-tui"
TRACE_SRC = pathlib.Path("/root/ap_trace.rs")

def patch(path, anchor, insert, count=1, before=False):
    p = pathlib.Path(path)
    src = p.read_text()
    n = src.count(anchor)
    assert n == count, f"{p.name}: anchor count {n} != {count} for {anchor[:60]!r}"
    out = src.replace(anchor, insert + anchor if before else anchor + insert, 1)
    p.write_text(out)
    print(f"patched {p.name}: +{insert.strip()[:46]!r}")

def patch_replace(path, anchor, replacement, count=1):
    p = pathlib.Path(path)
    src = p.read_text()
    n = src.count(anchor)
    assert n == count, f"{p.name}: anchor count {n} != {count} for {anchor[:60]!r}"
    p.write_text(src.replace(anchor, replacement, 1))
    print(f"patched {p.name}: replace {anchor[:40]!r}")


(TUI / "src/ap_trace.rs").write_text(TRACE_SRC.read_text())
patch(TUI / "src/lib.rs", "pub mod ansi;\n", "pub mod ap_trace;\n")

run = TUI / "src/interactive/run.rs"
patch(run, '    let (client, events) = DaemonClient::connect_with_retry(&options.socket_path)\n        .await\n        .with_context(|| "the interactive UI could not attach to the daemon")?;\n', '    crate::ap_trace::mark("connected");\n')
patch(run, '        if let Some(renderer) = renderer.is_terminal_mut() {\n            crate::app::draw(renderer, &mut view)?;\n', '            crate::ap_trace::mark("chrome");\n')
patch_replace(run, '    session.refresh_stats().await;\n    // The startup catalog fetch', '    session.refresh_stats().await;\n    crate::ap_trace::mark("stats");\n    // The startup catalog fetch')
patch(run, '    session.rebuild_view(&mut view, crate::session_ui::RebuildKind::Rebind);\n', '    crate::ap_trace::mark("rebuilt");\n')
patch(run, '                if interval_elapsed {\n                    crate::app::draw(renderer, &mut view)?;\n                    session.dirty = false;\n', '                    crate::ap_trace::mark("frame");\n')
patch(run, '                        view.chrome.tray_override = session.tray_override(&view);\n                        crate::app::draw(renderer, &mut view)?;\n', '                        crate::ap_trace::mark("frame_inline");\n')

su = TUI / "src/session_ui.rs"
patch(su, '        let active_session_id = match &options.session {\n', '        crate::ap_trace::mark("open_start");\n', before=True)
patch(su, '        let direct_attached = self\n            .client\n            .upgrade_direct(active_session_id)\n            .await\n            .unwrap_or(false);\n', '        crate::ap_trace::mark("attach_sent");\n')
patch(su, '        let attach = attach_data_from_response(data)?;\n', '        crate::ap_trace::mark("attach_done");\n')
patch(su, '        let reconstructed = reconstruct(&attach);\n', '        crate::ap_trace::mark("reconstructed");\n')
patch(su, '        self.subscribe_roster().await;\n', '        crate::ap_trace::mark("roster_done");\n')
patch(su, '            DockFold::FirstFrame => self.fetch_heartbeat_catalog().await,\n            DockFold::Fresh | DockFold::Held => self.spawn_heartbeat_refresh(),\n        }\n', '        crate::ap_trace::mark("hb_done");\n')
patch(su, '            DockFold::FirstFrame => self.fetch_bash_activities().await,\n            DockFold::Fresh | DockFold::Held => self.spawn_bash_activity_refresh(),\n        }\n', '        crate::ap_trace::mark("bash_done");\n')

patch(su, '        let reconstructed = reconstruct(&attach);\n', '        crate::ap_trace::mark_n(\n            "attach_msgs",\n            attach.snapshot.get("messages").and_then(serde_json::Value::as_array).map(|a| a.len()).unwrap_or(0) as f64,\n        );\n', before=True)

sf = TUI / "src/session_ui/sessions_fork.rs"
patch(sf, '    let data = match client\n        .request_ok(DaemonCommand::Create {\n', '    crate::ap_trace::mark("create_sent");\n', before=True)
patch(sf, '    data.get("activeSessionId")\n', '    crate::ap_trace::mark("create_done");\n', before=True)
su_src = (TUI / "src/session_ui.rs").read_text()
run_src = (TUI / "src/interactive/run.rs").read_text()
snap_src = (TUI / "src/snapshot.rs").read_text()
for phase, count in (("open_start", 1), ("attach_sent", 1), ("attach_done", 2), ("reconstructed", 2), ("roster_done", 1), ("hb_done", 1), ("bash_done", 1), ("attach_msgs", 1)):
    got = su_src.count(f'ap_trace::mark_n("{phase}"') + su_src.count(f'ap_trace::mark("{phase}"')
    assert got == count, f"{phase}: {got} != {count} in session_ui.rs"
for phase, count in (("connected", 1), ("chrome", 1), ("stats", 1), ("rebuilt", 1), ("frame", 1), ("frame_inline", 1)):
    got = run_src.count(f'ap_trace::mark("{phase}"')
    assert got == count, f"{phase}: {got} != {count} in run.rs"
print("PATCH_DONE")
