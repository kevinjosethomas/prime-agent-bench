
#!/usr/bin/env python3
"""Attach-paint ABBA analysis: per-leg per-cell arm p50s + phase ledger deltas."""
import json, statistics, sys, collections
path = sys.argv[1]
rows = [json.loads(l) for l in open(path)]
valid = [r for r in rows if r.get("valid")]
print(f"rows={len(rows)} valid={len(valid)}")
cells = collections.defaultdict(list)
for r in valid:
    cells[(r["arm"], r["leg"], r["offset_ms"])].append(r)
for leg_off in sorted({(k[1], k[2]) for k in cells}):
    leg, off = leg_off
    line = [f"{leg} +{off}ms:"]
    for arm in ("base", "cand"):
        rs = cells.get((arm, leg, off), [])
        if not rs:
            line.append(f"{arm}: n=0")
            continue
        vis = sorted(x.get("key_vis_after_spawn_ms") for x in rs if x.get("key_vis_after_spawn_ms") is not None)
        ttff = sorted(x.get("ttff_ms") for x in rs if x.get("ttff_ms") is not None)
        model = sorted(x.get("model_first_ms") for x in rs if x.get("model_first_ms") is not None)
        ctrl = sorted(x.get("control_vis_ms") for x in rs if x.get("control_vis_ms") is not None)
        p = lambda v: round(statistics.median(v), 1) if v else None
        line.append(f"{arm} n={len(rs)} keyvis p50={p(vis)} ttff={p(ttff)} model={p(model)} ctrl={p(ctrl)}")
    print(" | ".join(line))
# phase ledger per arm for legs with traces
def phase_span(r, a, b):
    t = r.get("trace") or {}
    return (t.get(b, [None])[0] - t.get(a, [None])[0]) if t.get(a) and t.get(b) else None
spans = collections.defaultdict(list)
for r in valid:
    t = r.get("trace")
    if not t:
        continue
    spans[(r["arm"], r["leg"])].append(r)
print("\n=== phase ledger (p50 ms) ===")
edges = [("open_start","create_sent"),("create_sent","create_done"),("attach_sent","attach_done"),
         ("attach_done","reconstructed"),("reconstructed","roster_done"),("roster_done","hb_done"),
         ("hb_done","bash_done"),("bash_done","stats"),("stats","rebuilt"),("rebuilt","frame")]
for (arm, leg), rs in sorted(spans.items()):
    vals = {}
    for a, b in edges:
        s = [phase_span(r, a, b) for r in rs if phase_span(r, a, b) is not None]
        vals[f"{a}->{b}"] = round(statistics.median(s), 2) if s else None
    print(f"{arm} {leg} n={len(rs)}: " + " ".join(f"{k}={v}" for k, v in vals.items() if v is not None))
