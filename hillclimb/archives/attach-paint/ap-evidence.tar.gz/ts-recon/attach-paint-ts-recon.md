# TS-Prime-Agent attach-paint recon (read-only)

Repo: /home/ubuntu/prime-agent-ts @ cd1f215 ("Fix Option+S in the model selector…"), worktree clean (git status empty).
Scope: what the ORIGINAL TypeScript Prime Agent renders when a TUI attaches/resumes — the parity reference for the Rust port's "ONE full transcript repaint at attach".

Files examined:
- packages/coding-agent/src/modes/interactive/interactive-mode.ts (the interactive TUI mode)
- packages/coding-agent/src/modes/agent-connection/daemon-agent-connection.ts (client attach/snapshot protocol)
- packages/coding-agent/src/modes/daemon/daemon-mode.ts, daemon-protocol.ts, snapshot-transcript-cache.ts (daemon attach wire shape)
- packages/coding-agent/src/modes/agent-connection/snapshot.ts (in-process snapshot shape)
- packages/tui/src/tui.ts + components/markdown.ts (the pi-tui renderer: differential, not ink)
- packages/coding-agent/src/main.ts (startup/attach order)

## Q1 — Render order at attach: eager FULL pass, but over a pre-truncated tail

Startup order (main.ts → InteractiveMode):
- main.ts:1060-1063 — attach helper builds the connection before the mode exists:
  `const attach = async (summary: SessionSummary) => { const connection = await DaemonAgentConnection.attach(client, getDaemonSummaryActiveSessionId(summary), {` … `deferSessionEvents: options.config.executionMode === "interactive"`
- main.ts:1534/1561 — `new InteractiveMode({...})`, then `await interactiveMode.run()`; run() awaits `init()`.
- interactive-mode.ts:1858 — `this.ui.start();` — FIRST frame is painted here (header + empty chat slot + editor + footer; chatContainer is an always-present child, interactive-mode.ts:1536 `this.mainViewContainer.addChild(this.chatContainer);`).
- interactive-mode.ts:1869 — `await this.renderInitialMessages();` — runs after `rebindCurrentSession()`.

The attach-snapshot landing (interactive-mode.ts:7347 `renderInitialMessages()`):
- :7354 `const snapshot = await this.agentConnection.getInitialSnapshot();`
- :7358-7362 — `await this.renderSessionContext(context, { clearChat: true, updateFooter: true, populateHistory: true, limitTranscript: true });`
- :7386 — `void this.agentConnection.flushBufferedSessionEvents?.();` — live events deferred until after the initial render (main.ts:1063 `deferSessionEvents`).

`renderSessionContext` (interactive-mode.ts:7186; docblock :7161 "Render session context to chat. Used for initial load and rebuild after compaction."):
- :7197 — `const messagesToRender = options.limitTranscript ? initialRenderMessages(transcriptMessages) : transcriptMessages;`
- :7217 — `await this.preloadToolDefinitions(toolNames);` (one daemon fetch BEFORE building components; failure tolerated, :7218-7223)
- :7224-7226 — `if (options.clearChat) { this.chatContainer.clear(); }`
- :7259-7336 — ONE synchronous `for (const message of messagesToRender)` loop that mounts every message's component (assistant → `addMessageToChat` + a `ToolExecutionComponent` per toolCall, :7267-7287; toolResult → `component.updateResult(message)`, :7312-7317).
- :7344 — `this.ui.requestRender();` — a single repaint request after the whole loop.

So the answer: EAGER, one render pass, no incremental/lazy row filling — every transcript entry in `messagesToRender` is mounted before the single repaint. How many entries: ALL of them up to the 400-message cap below (plus, when capped, a dim notice :7247-7253 `Showing latest ${messagesToRender.length} of ${sessionContext.messages.length} messages for faster open.`).

## Q2 — Windowing: YES — a 400-message tail cap bounds the initial paint (not viewport-height virtualization)

interactive-mode.ts:741 — `const INITIAL_TRANSCRIPT_RENDER_MESSAGE_LIMIT = 400;`
interactive-mode.ts:776-778 — `function initialRenderMessages(messages: AgentMessage[]): AgentMessage[] { if (messages.length <= INITIAL_TRANSCRIPT_RENDER_MESSAGE_LIMIT) { return messages; }`
interactive-mode.ts:792-794 — `const initialStartIndex = messages.length - INITIAL_TRANSCRIPT_RENDER_MESSAGE_LIMIT;` … `const visibleMessages = messages.slice(startIndex);` — walks forward until the window + required orphan-toolcall ancestor messages fit the 400 cap, then returns the stitched tail.
interactive-mode.ts:837/861 — `return omitOrphanToolResults([...requiredToolCallMessages, ...visibleMessages]);` — orphan toolResults (whose toolCall fell out of the window) are dropped entirely.

So the initial paint is bounded by a FIXED MESSAGE COUNT (400), not by viewport rows or a virtual list. The in-memory tree still renders every mounted component to lines each frame (see Q5); there is no visible-rows virtualization in the default (scrollback) mode. Fullscreen mode (opt-in via settings, interactive-mode.ts:1860-1866) does window the terminal writes to the viewport (tui.ts:1545 `const viewportTop = Math.max(0, lines.length - height);`, tui.ts:1709 `const windowStart = Math.max(0, newLines.length - height);`), but it is not the default attach path.

Per-entry cost is also bounded: tool cards render COLLAPSED by default — tool-execution.ts:88 `private expanded = false;`, and interactive-mode.ts:7284 `component.setExpanded(this.toolOutputExpanded);` where :8115 `this.toolOutputExpanded = detail === "all";` (default chatDetail is "details", settings-manager.ts:258 `chatDetail?: ChatDetail; // Default: "details"`). Collapsed previews are line-capped: tool-execution.ts:575-580 `private formatFallbackPreview(text) { if (this.expanded) return text; … return lines.slice(0, 3).join("\n") …` ; bash tool previews cap at 5 visual lines (core/tools/bash.ts:519 `const BASH_PREVIEW_LINES = 5;`, :593 `truncateToVisualLines(styledOutput, BASH_PREVIEW_LINES, width)`), the bash panel at 20 (bash-execution.ts:14 `const PREVIEW_LINES = 20;`).

## Q3 — Async/deferred work at mount

- The ONLY pre-paint deferral is `await this.preloadToolDefinitions(toolNames)` (interactive-mode.ts:7217) — a daemon fetch before component construction; on failure rendering proceeds with cached/missing definitions (:7218-7223 "Tool definitions only enrich rendering… must not abort the render").
- No setTimeout/rAF-style deferral inside the transcript pass: markdown is rendered synchronously in `Markdown.render(width)` with a whole-result + per-block cache (tui/src/components/markdown.ts:235-237 `render(width) { if (this.cachedLines && this.cachedText === this.text && this.cachedWidth === width) { return this.cachedLines; }`; :218-219 "a streaming append re-renders just the blocks that actually changed"). Assistant messages build `Markdown` children synchronously (assistant-message.ts:270-286).
- Fold/collapse of tool cards is the main "lazy" mechanism — collapsed-by-default panels with 3/5/20-line previews (Q2), expandable on click (`/tools` cycles `chatDetail`).
- Frame scheduling, not content, is the only async part: `requestRender()` coalesces via `process.nextTick` + a 16ms throttle (tui.ts:664-690, :351 `private static readonly MIN_RENDER_INTERVAL_MS = 16;`), so all follow-up state paints (footer, warnings, compaction status) fold into the same or next frame rather than N repaints.
- Live session events are held back until the initial render completes: daemon-agent-connection.ts:217-222 ("Defer session events between attach and the first flushBufferedSessionEvents() call… its initial render can use the attach snapshot as-is"), released at interactive-mode.ts:7386.

## Q4 — Attach wire shape: FULL history, but chunked (512KiB) and deduped — not windowed

The snapshot object itself carries the whole history (in-process path, agent-connection/snapshot.ts:75-77: `messages: [...session.messages]`; daemon path, daemon-mode.ts:5608: `messages: session.messages`).

The daemon attach response is SLIM (deduped): daemon-mode.ts:5562-5566 — `const slim = capabilities.has("slim_attach");` … `...(slim ? {} : { state: snapshot.summary, messages: snapshot.messages })` — "Slim clients read summary/messages from the snapshot; duplicating them at the top level would serialize the full history twice more per attach."

With the `chunked_snapshot` capability (advertised by the TUI at daemon-agent-connection.ts:493-495: `"attach_snapshot", "event_sequence", … "slim_attach", "chunked_snapshot"`), the attach response ships with EMPTY message arrays and the transcript is STREAMED as chunk frames: daemon-mode.ts:4419-4426 — `messages: result.messages ? [] : undefined, snapshot: { ...result.snapshot, messages: [] }, snapshotStream: { id, messageCount: result.snapshot.messages.length, targetChunkBytes: SNAPSHOT_TARGET_CHUNK_BYTES }`, then `setImmediate(() => { void this.streamWorkerSnapshot(client, streamedResult, transcript, "attach", …) })`.

Chunking: daemon/snapshot-transcript-cache.ts:10-11 — `export const SNAPSHOT_TARGET_CHUNK_BYTES = 512 * 1024;` (and :58-61 the chunk frame prefix `{"type":"session_snapshot_chunk",…,"messages":[`). Wire types: daemon-protocol.ts:1166/1175/1182 `session_snapshot_begin` / `session_snapshot_chunk` / `session_snapshot_end`. The client reassembles and VALIDATES completeness before the attach resolves: daemon-agent-connection.ts:2093-2094 (`session_snapshot_chunk` → `assembly.chunks.set(message.index, message.messages)`), :2747-2791 `completeSnapshotAssembly` (rejects on missing chunk / wrong `messageCount`, then `messages.push(...chunk)`), :551 `await this.waitForSnapshot(result.snapshotStream.id);`. A 30s transfer bound exists (:160 `DAEMON_SNAPSHOT_TIMEOUT_MS = 30_000`).

So: the daemon sends ALL rows (no protocol-level window/slim-by-tail), delivered as N×512KiB chunk frames; windowing to 400 happens purely at RENDER time (Q2).

## Q5 — First paint vs post-attach paint

Before the snapshot lands: `ui.start()` (interactive-mode.ts:1858) paints the header/editor skeleton in one frame — BrandSplashHeader (or an empty Text under quiet startup, :1808-1813), empty chatContainer (:1536), prompt-context/recap slots, editor, footer; `TUI.start()` ends with `this.requestRender()` (tui.ts:603-611), so the first frame is header+editor with an EMPTY transcript.

When the snapshot lands: `renderSessionContext` builds the whole (≤400-message) transcript into chatContainer and issues ONE `this.ui.requestRender()` (:7344). `doRender()` re-renders the entire component tree in memory (tui.ts:1685 `let newLines = this.render(width);`) and then writes only the DIFF to the terminal: tui.ts:1863-1880 finds `firstChanged`/`lastChanged` line ranges; the attach case changes lines from the top of the (previously empty) chat area down, so the frame writes the whole transcript block + shifted editor/footer in ONE synchronized-output buffer (tui.ts:1965+ "Render from first changed line to end"; `[?2026h` begin-sync at :1699). I.e., structurally: ONE full transcript repaint of the whole tree, emitted as a single diff write — matching the Rust port's rebuild_view → one full repaint.

Follow-up frames after attach are small and event-driven (streaming-message restore :7373-7381, loaded-resources notice, compaction status :7377-7381, warnings, footer updates), coalesced by the 16ms throttle (tui.ts:883-895); for a growing transcript taller than the screen, later repaints repaint only the visible window instead of replaying from the top (tui.ts:1928-1936: "When the transcript is taller than the viewport — e.g. attaching to a long or still-streaming session … Repaint only the visible window in place instead").

## Verdict

TS paints the attach snapshot EAGERLY in ONE full render pass — header+editor frame first, then a single repaint that mounts and writes the whole transcript block at once — so the Rust port's "rebuild_view → one full transcript repaint at attach" is structurally TS-parity, not lazier. The parity caveat is the INPUT, not the pass: TS pre-truncates the transcript to the last 400 messages (INITIAL_TRANSCRIPT_RENDER_MESSAGE_LIMIT) plus orphan-toolcall stitching and prints a "Showing latest N of M messages for faster open" notice, and ships the wire payload as 512KiB chunks with a slim top-level response. Per-entry paint cost is bounded by collapsed-by-default tool cards (3/5/20-line previews) and cached synchronous markdown, but there is no viewport virtualization in the default mode and no progressive row filling. If the Rust port's full repaint covers >400 messages (or renders expanded tool cards / unbounded per-entry output), it is doing MORE first-paint work than TS; matching TS means cap-at-400-tail, collapsed previews, and one diff write.

Key line refs: interactive-mode.ts:741,776-794,837,1858,1869,7197,7217,7246-7253,7259-7336,7344,7347-7386,8115; daemon-mode.ts:5562-5566,5608,4419-4430; snapshot-transcript-cache.ts:10-11; daemon-agent-connection.ts:217-222,493-495,551,2093-2098,2747-2791; snapshot.ts:75-77; tui.ts:351,603-611,664-695,1545,1685,1699,1863-1880,1928-1936,1965+; tool-execution.ts:88,575-580; bash.ts:519,593; markdown.ts:218-219,235-237; main.ts:1060-1063,1534,1561; settings-manager.ts:258.
