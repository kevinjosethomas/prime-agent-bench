#!/usr/bin/env python3
"""attach-paint decomposition driver: launch-to-ready phase ledger on silent
ptys, cold + warm, at the tip.

Legs:
  new                    fresh session (SessionSelection::New), silent pty
  warm                   TUI#1 New -> ready -> kill; TUI#2 --resume <active-id>
  resume:<fixture>       --resume <fixture copy> (cold worker per trial)

Per trial: fresh trial dir, per-trial resident daemon, PTYSession launch
(per-chunk timestamp ledger + pyte screen + reader-thread echo watch),
worker-socket appearance watcher (2ms grid on $TMPDIR/prime-agent-<uid>),
worker process sighting grid (2ms), env-gated AP phase trace
(PRIME_AGENT_AP_TRACE) when the probe binary is staged, keys at known offsets
after spawn, control key post-settle. TTFF / first-key-visible /
launch-to-ready separated; the content frame anchored by the trace's first
loop frame (and externally by the model string's first chunk).
"""
import hashlib, json, os, shutil, socket, statistics, subprocess, sys, threading, time, uuid
from pathlib import Path

sys.path.insert(0, "/root/bench-harness")
from bench.core.config import load_config
from bench.core.registry import discover
from bench.adapters.terminals.pty import PTYSession

BIN = "/root/bench/repos/prime-agent-rust/target/release/prime-agent"
STAGE = "/root/bins"
RESULTS = Path("/root/results-ap")
TRIALS = Path("/root/bench-root/trials-ap")
FIXDIR = Path("/root/fixtures")
QUERY = b"\x1b[?u\x1b[c"

def sha256f(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def swap(arm):
    src = f"{STAGE}/bin-{arm}"
    got = sha256f(src)
    if os.path.exists(BIN):
        os.unlink(BIN)
    shutil.copy2(src, BIN)
    assert sha256f(BIN) == got, f"swap sha mismatch {arm}"
    os.chmod(BIN, 0o755)
    return got

def wait_daemon_socket(socket_path, timeout=90.0):
    deadline = time.perf_counter() + timeout
    while time.perf_counter() < deadline:
        if socket_path.exists():
            try:
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                    s.settimeout(2)
                    s.connect(str(socket_path))
                return True
            except OSError:
                pass
        time.sleep(0.005)
    return False

def wait_for_bytes(app, needle, timeout=30.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        with app._lock:
            raw = bytes(app.raw)
            idx = raw.find(needle)
            if idx >= 0:
                for t, end in app.chunks:
                    if idx < end:
                        return t
        time.sleep(0.0005)
    return None

def busy_until(t_target):
    while time.monotonic() < t_target:
        pass

class SocketWatcher:
    """2ms grid listing of the worker socket dir; records first appearance."""
    def __init__(self, socket_dir, t0):
        self.socket_dir = Path(socket_dir)
        self.t0 = t0
        self.events = []
        self.seen = set()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        while not self.stop.is_set():
            try:
                for name in os.listdir(self.socket_dir):
                    if name.startswith("worker-") and name not in self.seen:
                        self.seen.add(name)
                        self.events.append((time.monotonic(), name))
            except OSError:
                pass
            time.sleep(0.002)

    def finish(self):
        self.stop.set()
        self.thread.join(timeout=1.0)
        return [{"t_ms": round((t - self.t0) * 1000.0, 1), "name": n} for t, n in self.events]

class ProcSighting:
    """2ms grid /proc scan for new processes whose cmdline names the trial."""
    def __init__(self, needle, t0):
        self.needle = needle
        self.t0 = t0
        self.events = []
        self.seen = set()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        while not self.stop.is_set():
            for pid in os.listdir("/proc"):
                if not pid.isdigit():
                    continue
                try:
                    with open(f"/proc/{pid}/cmdline", "rb") as f:
                        cmd = f.read()
                except OSError:
                    continue
                if self.needle in cmd:
                    if pid not in self.seen:
                        self.seen.add(pid)
                        self.events.append((time.monotonic(), pid, cmd[:120].decode(errors="replace")))
                    else:
                        self.events.append((time.monotonic(), pid, None))
            time.sleep(0.002)

    def finish(self):
        self.stop.set()
        self.thread.join(timeout=1.0)
        out, last = [], {}
        for t, pid, cmd in self.events:
            last[pid] = (t, cmd if cmd else last.get(pid, (None, None))[1])
        for pid, (t, cmd) in last.items():
            out.append({"pid": pid, "t_ms": round((t - self.t0) * 1000.0, 1), "cmd": cmd})
        out.sort(key=lambda r: r["t_ms"])
        return out

def parse_trace(path):
    phases = {}
    if not os.path.exists(path):
        return None
    with open(path) as f:
        for line in f:
            try:
                rec = json.loads(line)
                phases.setdefault(rec["phase"], []).append(rec["t_ms"])
            except Exception:
                pass
    return phases

def launch_tui(product, ctx, driver, resume_sel, trace_path):
    env = product.env(ctx)
    if trace_path:
        env["PRIME_AGENT_AP_TRACE"] = str(trace_path)
    return driver.start_session(product.argv(ctx, resume_sel), env=env,
                                cwd=str(ctx["work"]))

def run_trial(product, driver, leg, offset_ms, arm_sha, round_idx, trials_dir):
    td = trials_dir / f"ap-{uuid.uuid4().hex[:10]}"
    ctx = product.new_trial(td)
    dproc = subprocess.Popen(product.daemon_argv(ctx), env=product.env(ctx),
                             cwd=str(ctx["work"]), stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    daemon_ok = wait_daemon_socket(ctx["daemon_socket"], 90)
    rec = {"arm": arm_sha[:12], "leg": leg, "offset_ms": offset_ms,
           "round": round_idx, "trial": td.name, "daemon_ok": daemon_ok,
           "valid": False}
    if not daemon_ok:
        dproc.terminate()
        return rec
    t_daemon_ready = time.monotonic()
    trace_path = td / "trace.jsonl"
    fixture = None
    app = None
    warm_id = None
    wsock_dir = Path(str(ctx["tmp"])) / "prime-agent-0"
    try:
        if leg.startswith("resume:"):
            fixture = leg.split(":", 1)[1]
            src = FIXDIR / fixture
            fx = td / "fixture.jsonl"
            shutil.copy2(src, fx)
            rec["fixture_sha_pre"] = sha256f(fx)
            resume_sel = str(fx)
        else:
            resume_sel = None
        if leg == "warm":
            # TUI #1: fresh session, wait ready, then kill; the session stays
            # active on the daemon (the dropped-client shape). The ready
            # probe must start only AFTER the TUI's first real output (the
            # kitty probe query): probes sent into a still-cooked terminal
            # echo locally and satisfy the watch without any product
            # readiness.
            app1 = launch_tui(product, ctx, driver, None, None)
            t_q1 = wait_for_bytes(app1, QUERY, 30)
            if t_q1 is None:
                rec["fail"] = "warm1: no startup bytes from TUI#1"
                try: app1.kill_tree()
                except Exception: pass
                return rec
            try:
                probe1 = app1.probe_input_ready("Warm1", retry_every=0.5, timeout=60.0, start_ts=t_q1)
            except Exception as e:
                probe1 = {"error": str(e)[:200]}
            if probe1.get("echo_ts_offset_ms") is None:
                rec["fail"] = "warm1 never reached ready"
                rec["warm1_probe"] = probe1
                try: app1.kill_tree()
                except Exception: pass
                return rec
            app1.kill_tree()
            del app1
            # the active session id: the worker socket created during TUI#1
            try:
                names = [n for n in os.listdir(wsock_dir) if n.startswith("worker-")]
            except OSError as e:
                rec["fail"] = f"worker socket dir missing after TUI#1: {e}"
                return rec
            if not names:
                rec["fail"] = "no worker socket after TUI#1"
                return rec
            active_id = sorted(names)[0].rsplit("-", 1)[1].split(".")[0]
            resume_sel = active_id
        rec["resume_sel"] = resume_sel
        t0 = time.monotonic()
        watcher = SocketWatcher(wsock_dir, t0)
        sighting = ProcSighting(str(ctx["daemon_socket"]).encode(), t0)
        app = launch_tui(product, ctx, driver, resume_sel, trace_path)
        t_spawn = app.t_spawn
        watcher.t0 = t_spawn; sighting.t0 = t_spawn
        rec["query_after_spawn_ms"] = None
        t_query = wait_for_bytes(app, QUERY, 20)
        rec["query_seen"] = t_query is not None
        if t_query is not None:
            rec["query_after_spawn_ms"] = round((t_query - t_spawn) * 1000.0, 1)
        busy_until(t_spawn + offset_ms / 1000.0)
        app.start_echo_watch("Kq91")
        t_send = app.send("Kq91")
        try:
            t_vis = app.wait_echo(30)
            rec["key_vis_ms"] = round((t_vis - t_send) * 1000.0, 1)
            rec["key_vis_after_spawn_ms"] = round((t_vis - t_spawn) * 1000.0, 1)
        except TimeoutError:
            rec["fail"] = "key never rendered"
            return rec
        try:
            t_react = app.wait_output_after(t_send, 2)
            rec["key_react_ms"] = round((t_react - t_send) * 1000.0, 1)
        except TimeoutError:
            rec["key_react_ms"] = None
        # control key post-settle (render pipeline control): after the
        # content frame has landed (slow legs may open past 1.4s).
        busy_until(max(t_spawn + 1.4, t_vis + 0.5))
        app.start_echo_watch("Zw72")
        t_send2 = app.send("Zw72")
        try:
            t_vis2 = app.wait_echo(6)
            rec["control_vis_ms"] = round((t_vis2 - t_send2) * 1000.0, 1)
        except TimeoutError:
            rec["control_vis_ms"] = None
        rec["ttff_ms"] = round((app.t_first_paint - app.t_spawn) * 1000.0, 1) if app.t_first_paint else None
        rec["first_byte_ms"] = round((app.t_first_byte - app.t_spawn) * 1000.0, 1) if app.t_first_byte else None
        t_model = wait_for_bytes(app, b"mock-1", 20)
        rec["model_first_ms"] = round((t_model - t_spawn) * 1000.0, 1) if t_model else None
        rec["bytes_out"] = app.bytes_out()
        with app._lock:
            prev = 0; ledger = []
            for t, end in app.chunks:
                ledger.append([round((t - app.t_spawn) * 1000.0, 1), end - prev]); prev = end
            rec["chunks"] = ledger[:60]
        rec["screen_tail"] = "\n".join(app.screen_text().splitlines()[-6:])
        rec["worker_sockets"] = watcher.finish()
        rec["sightings"] = sighting.finish()
        rec["trace"] = parse_trace(trace_path)
        rec["t_daemon_ready_before_spawn_ms"] = round((t_spawn - t_daemon_ready) * 1000.0, 1)
        if fixture:
            rec["fixture_sha_post"] = sha256f(td / "fixture.jsonl")
        rec["valid"] = True
        return rec
    finally:
        if app is not None:
            try: app.kill_tree()
            except Exception: pass
        dproc.terminate()
        try: dproc.wait(timeout=10)
        except Exception: dproc.kill()
        try: product.reap(ctx)
        except Exception: pass

def calibration(label):
    out = {"label": label}
    r = subprocess.run([sys.executable, "-c",
        "import sys; sys.path.insert(0,'/root/bench-harness');"
        "from bench.core.registry import discover;"
        "from bench.core.config import load_config;"
        "reg=discover(load_config('/root/bench-harness/configs/sandbox.yaml'));"
        "import json; print(json.dumps(reg.driver().noop_control(30)))"],
        capture_output=True, text=True)
    out["noop"] = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-300:]
    for name, path in (("fsync", "/root/ap-probe-fsync.py"), ("fresh", "/root/ap-probe-fresh.py")):
        r = subprocess.run([sys.executable, path], capture_output=True, text=True)
        out[name] = r.stdout.strip() or r.stderr[-300:]
    return out

def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    TRIALS.mkdir(parents=True, exist_ok=True)
    arms = sys.argv[1].split(",") if len(sys.argv) > 1 else ["probe"]
    legs = sys.argv[2].split(";") if len(sys.argv) > 2 else ["new", "warm", "resume:small.jsonl"]
    rounds = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    cfg = load_config("/root/bench-harness/configs/sandbox.yaml")
    reg = discover(cfg)
    product = reg.product("rust")
    driver = reg.driver()
    plan = []
    for leg in legs:
        if "@" in leg:
            leg_base, offs = leg.split("@", 1)
            offsets = [int(x) for x in offs.split(",")]
        else:
            leg_base, offsets = leg, (10, 50, 120, 200)
        for off in offsets:
            for r in range(rounds):
                plan.append((leg_base, off, r))
    rows_path = RESULTS / ("trials-" + "-".join(arms) + ".jsonl")
    cal_path = RESULTS / "calibration.jsonl"
    cal = calibration("pre")
    with open(cal_path, "a") as f: f.write(json.dumps(cal) + "\n")
    print("AP-CAL pre", json.dumps(cal), flush=True)
    for block, arm in enumerate(arms):
        arm_sha = swap(arm)
        print(f"AP-BLOCK {block} arm={arm} sha={arm_sha[:12]} plan={len(plan)}", flush=True)
        for i, (leg, off, r) in enumerate(plan):
            rec = run_trial(product, driver, leg, off, arm_sha, r, TRIALS)
            rec["block"] = block
            with open(rows_path, "a") as f: f.write(json.dumps(rec) + "\n")
            vis = rec.get("key_vis_ms"); ttff = rec.get("ttff_ms"); mod = rec.get("model_first_ms")
            print(f"AP-ROW {i} {leg} +{off} vis={vis} ttff={ttff} model={mod} valid={rec['valid']}", flush=True)
        if block == 0 and len(arms) > 1:
            cal = calibration("mid")
            with open(cal_path, "a") as f: f.write(json.dumps(cal) + "\n")
            print("AP-CAL mid", json.dumps(cal), flush=True)
    cal = calibration("post")
    with open(cal_path, "a") as f: f.write(json.dumps(cal) + "\n")
    print("AP-CAL post", json.dumps(cal), flush=True)
    print("AP-DONE", flush=True)

if __name__ == "__main__":
    main()
