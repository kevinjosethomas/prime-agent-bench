#!/usr/bin/env python3
"""Advisory v0.9 regime preflight probe (both classes, isolated ops).

Class A: >=40 ISOLATED fresh+sync_all+rename+stat ops at 0.5s spacing
(the isolated-durability-write regime; bursts amortize ~3.5ms/op and
must never be used to judge the regime).
Class B: >=20 repeat-fsync ops (4KB, same fd).
Classification (host-relative): HEALTHY = stall-rate(>15ms) <= 2% AND
max <= 50ms AND p50 <= 2x baseline_p50_ms (arg3, default 20);
MARGINAL = stall-rate 2-5% OR max 50-100ms OR p50 > 2x baseline;
DEGRADED = stall-rate > 5% OR max > 100ms.
Usage: probe_v09.py <base_path> <tag> [baseline_p50_ms]
Emits one line: PROBEV09 <tag> A_STALL_RATE=.. A_MAX=.. A_P50=.. B_... CLASS=..
"""
import os, statistics, sys, time

base = sys.argv[1] if len(sys.argv) > 1 else "/root/probe-v09"
tag = sys.argv[2] if len(sys.argv) > 2 else "x"
baseline_p50 = float(sys.argv[3]) if len(sys.argv) > 3 else 20.0
stable = base + ".stable"
data = os.urandom(4096)

def classify(rate, mx, p50):
    if rate > 5.0 or mx > 100.0:
        return "D"
    if rate > 2.0 or mx > 50.0 or p50 > 2.0 * baseline_p50:
        return "M"
    return "H"

# Class A: 40 isolated fresh+sync_all+rename ops, 0.5s spacing
a = []
for i in range(40):
    tmp = f"{base}.tmp{i}"
    t0 = time.perf_counter()
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.rename(tmp, stable)
    os.stat(stable)
    a.append((time.perf_counter() - t0) * 1000.0)
    time.sleep(0.5)
os.unlink(stable)

# Class B: 20 repeat-fsync ops (burst-amortized check on the same fd)
b = []
with open(base + "-fs.bin", "wb+") as f:
    f.write(data)
    for _ in range(20):
        f.seek(0)
        f.write(data)
        t0 = time.perf_counter()
        os.fsync(f.fileno())
        b.append((time.perf_counter() - t0) * 1000.0)
os.unlink(base + "-fs.bin")

def stats(v):
    v2 = sorted(v)
    stall = 100.0 * sum(1 for x in v2 if x > 15.0) / len(v2)
    return stall, v2[-1], statistics.median(v2)

a_rate, a_max, a_p50 = stats(a)
b_rate, b_max, b_p50 = stats(b)
cls = classify(a_rate, a_max, a_p50)
print(f"PROBEV09 {tag} A_N={len(a)} A_STALL_RATE={a_rate:.1f} A_MAX={a_max:.1f} A_P50={a_p50:.2f} "
      f"B_N={len(b)} B_STALL_RATE={b_rate:.1f} B_MAX={b_max:.1f} B_P50={b_p50:.2f} "
      f"BASELINE_P50={baseline_p50} CLASS={cls}", flush=True)
print(f"PROBEV09_VALUES {tag} A={[round(x,1) for x in sorted(a)]} B={[round(x,1) for x in sorted(b)]}", flush=True)
