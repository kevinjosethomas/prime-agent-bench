//! VM-only decompose probe for the get_available_models handler cost.
//! Never committed to the lane branch. Modes:
//!   plain   - the registry construction pieces (no network)
//!   refresh - the FULL awaited refresh_available_models chain (network on)
use std::time::Instant;

fn main() {
    let agent_dir = std::env::args()
        .nth(1)
        .expect("usage: gam_probe <agent-dir> [rounds] [plain|refresh]");
    let rounds: usize = std::env::args()
        .nth(2)
        .and_then(|s| s.parse().ok())
        .unwrap_or(16);
    let refresh = std::env::args().nth(3).map(|s| s == "refresh").unwrap_or(false);
    let agent_dir = std::path::PathBuf::from(agent_dir);
    let rt = tokio::runtime::Builder::new_multi_thread().enable_all().build().unwrap();
    rt.block_on(async move {
        for i in 0..rounds {
            let t0 = Instant::now();
            let auth = pa_core::auth::AuthStorage::create(&agent_dir);
            let t_auth = t0.elapsed();
            let t1 = Instant::now();
            let mut registry = pa_core::models::ModelRegistry::create(
                auth,
                agent_dir.join("models.json"),
            );
            let t_reg = t1.elapsed();
            let t2 = Instant::now();
            registry.load_private_authorization_from_cache();
            let t_priv = t2.elapsed();
            let (t_refresh, n_avail) = if refresh {
                let tr = Instant::now();
                let models = registry.refresh_available_models().await;
                (tr.elapsed(), models.len())
            } else {
                (Instant::now().elapsed(), registry.get_available().len())
            };
            let t3 = Instant::now();
            let available = registry.get_available();
            let n_avail2 = available.len();
            let models: Vec<serde_json::Value> = available
                .into_iter()
                .filter_map(|m| serde_json::to_value(m).ok())
                .collect();
            let t_ser = t3.elapsed();
            let t5 = Instant::now();
            let payload = serde_json::to_string(&serde_json::json!({ "models": models })).unwrap();
            let t_payload = t5.elapsed();
            let total = t_auth + t_reg + t_priv + t_refresh + t_ser + t_payload;
            println!(
                "round {i} auth_us={} reg_us={} priv_us={} refresh_us={} getserde_us={} payload_us={} total_us={} n_avail={} n_avail_post={} payload_bytes={}",
                t_auth.as_micros(), t_reg.as_micros(), t_priv.as_micros(),
                t_refresh.as_micros(), t_ser.as_micros(), t_payload.as_micros(),
                total.as_micros(), n_avail, n_avail2, payload.len()
            );
            std::hint::black_box(&payload);
        }
    });
}
