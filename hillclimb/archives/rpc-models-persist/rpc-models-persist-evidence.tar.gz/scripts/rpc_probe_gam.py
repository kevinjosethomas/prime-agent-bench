#!/usr/bin/env python3
"""Wave-5 rpc-models-persist lane: get_available_models decompose probe.

Modes:
  gam-burst   <trials> <bin> <out.json>  -- battery with gam1..gam16 back-to-back
  gam-isolate <trials> <bin> <out.json>  -- 1 gam per trial after settle gap

Per-gam audit: mtime_ns+size+sha of the 4 models-cache-class files + the
agent-dir file census, captured before/after EVERY gam call. Response raw
byte length captured per command. Census (strace) when RPC_CENSUS_DIR set:
-ff -f -tt -T -yy with write-class + file syscalls (per-tid files).
"""
import hashlib, json, os, pathlib, shutil, statistics, subprocess, sys, time

MOCK_BASE = os.environ.get("MOCK_BASE", "http://127.0.0.1:8890/v1")
TRIALS_ROOT = "/root/gam-trials"
AUDIT_FILES = [
    "models.json",
    "prime-inference-private-models.json",
    "models/provider-model-catalog.v1.json",
    "models/prime-inference-models-cache.json",
]
N_GAM = int(os.environ.get("GAM_N", "16"))

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def write_models_json(agent_dir):
    agent_dir = pathlib.Path(agent_dir)
    agent_dir.mkdir(parents=True, exist_ok=True)
    models = {"providers": {"prime-inference": {
        "api": "openai-completions", "baseUrl": MOCK_BASE, "apiKey": "sk-bench",
        "models": [{"id": "mock-1", "name": "Mock 1", "api": "openai-completions",
                    "baseUrl": MOCK_BASE, "contextWindow": 128000, "maxTokens": 4096}]}}}
    (agent_dir / "models.json").write_text(json.dumps(models, indent=1))

def scrub_env(base):
    env = {}
    for k, v in base.items():
        if k.startswith(("PI_", "PRIME_", "UV_", "XDG_")):
            continue
        env[k] = v
    return env

def loadavg():
    with open("/proc/loadavg") as f:
        return float(f.read().split()[0])

def zombie_sweep():
    out = subprocess.run(["ps", "-eo", "pid,comm,args"], capture_output=True, text=True).stdout
    me = os.getpid()
    pids = []
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid, comm, args = parts
        pid = int(pid)
        if pid == me:
            continue
        is_product = (comm.startswith("prime-agent")
                      or (comm in ("python", "python3") and "rlm.repl" in args))
        if is_product:
            pids.append(pid)
    for pid in pids:
        try:
            os.kill(pid, 15)
        except ProcessLookupError:
            pass
    if pids:
        time.sleep(1.0)
    return pids

import threading

class Conn:
    def __init__(self, proc):
        self.proc = proc
        self.frames = []      # (wall_s, mono_s, raw_len, obj)
        self._raw_buf = b""
        self.stderr_tail = []
        self._stderr_thread = threading.Thread(target=self._drain_stderr, daemon=True)
        self._stderr_thread.start()
    def _drain_stderr(self):
        for raw in iter(self.proc.stderr.readline, b""):
            self.stderr_tail.append((time.time(), raw.decode(errors="replace")))
            if len(self.stderr_tail) > 4000:
                self.stderr_tail.pop(0)
    def _read_frames(self, timeout_s, idle_s=None, max_s=30.0, keep_raw=False):
        import select
        fd = self.proc.stdout.fileno()
        os.set_blocking(fd, False)
        t0 = time.monotonic()
        last = t0
        n = 0
        while True:
            now = time.monotonic()
            if now - t0 > min(timeout_s, max_s):
                break
            if idle_s is not None and now - last > idle_s:
                break
            ready, _, _ = select.select([fd], [], [], 0.05)
            if ready:
                try:
                    chunk = os.read(fd, 1 << 20)
                except (BlockingIOError, OSError):
                    chunk = b""
                if chunk:
                    self._raw_buf += chunk
                    last = time.monotonic()
                while b"\n" in self._raw_buf:
                    raw, self._raw_buf = self._raw_buf.split(b"\n", 1)
                    if not raw.strip():
                        continue
                    try:
                        obj = json.loads(raw)
                    except ValueError:
                        continue
                    self.frames.append((time.time(), time.monotonic(), len(raw), obj))
                    if keep_raw and obj.get("id"):
                        if not hasattr(self, "raw_keep"):
                            self.raw_keep = {}
                        self.raw_keep[obj["id"]] = raw
                    n += 1
        return n, last
    def send(self, obj):
        self.proc.stdin.write((json.dumps(obj) + "\n").encode())
        self.proc.stdin.flush()
    def read_until_response(self, rid, timeout=60.0, keep_raw=False):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            before = len(self.frames)
            self._read_frames(timeout_s=0.01, max_s=0.01, keep_raw=keep_raw)
            for _, _, rlen, obj in self.frames[before:]:
                if obj.get("type") == "response" and obj.get("id") == rid:
                    return obj, rlen
            if self.proc.poll() is not None and not self._raw_buf:
                raise RuntimeError(f"rpc exited rc={self.proc.returncode}; "
                                   f"stderr_tail={''.join(x[1] for x in self.stderr_tail)[-1500:]}")
        raise TimeoutError(f"no response for {rid} in {timeout}s")
    def drain_events(self, idle_s=0.35, max_s=30.0):
        _, last = self._read_frames(timeout_s=max_s, idle_s=idle_s, max_s=max_s)
        return last

def audit_agent_dir(agent):
    """Snapshot the models-cache-class files + the full file census."""
    snap = {"files": {}}
    for rel in AUDIT_FILES:
        p = os.path.join(agent, rel)
        try:
            st = os.stat(p)
            snap["files"][rel] = {"size": st.st_size, "mtime_ns": st.st_mtime_ns,
                                  "sha": sha256_file(p)}
        except FileNotFoundError:
            snap["files"][rel] = None
    census = []
    for root, dirs, files in os.walk(agent):
        dirs[:] = [d for d in dirs if d not in ("sessions",)]
        for name in sorted(files):
            fp = os.path.join(root, name)
            rel = os.path.relpath(fp, agent)
            try:
                st = os.stat(fp)
                census.append((rel, st.st_size, st.st_mtime_ns))
            except OSError:
                pass
    snap["census"] = census
    return snap

def diff_audit(a, b):
    fa, fb = a["files"], b["files"]
    changed = {}
    for k in fa:
        if fa[k] != fb[k]:
            changed[k] = {"before": fa[k], "after": fb[k]}
    ca = {c[0]: c[1:] for c in a["census"]}
    cb = {c[0]: c[1:] for c in b["census"]}
    added = sorted(set(cb) - set(ca))
    removed = sorted(set(ca) - set(cb))
    grown = {k: {"before": ca[k], "after": cb[k]} for k in set(ca) & set(cb) if ca[k] != cb[k]}
    return {"models_class_changed": changed, "added": added, "removed": removed, "grown": grown}

def run_trial(mode, i, binpath, root, tag=None):
    label = f"{tag}" if tag else f"{mode}-{i:02d}"
    trial = os.path.join(root, label)
    if os.path.isdir(trial):
        shutil.rmtree(trial)
    os.makedirs(trial, exist_ok=True)
    agent = os.path.join(trial, "agent")
    write_models_json(agent)
    for name in ("auth.json", "settings.json"):
        src = os.path.join("/root/.prime/agent", name)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(agent, name))
    proj = os.path.join(trial, "proj")
    os.makedirs(proj, exist_ok=True)
    home = os.path.join(trial, "home")
    tmp = os.path.join(trial, "tmp")
    os.makedirs(home, exist_ok=True)
    os.makedirs(tmp, exist_ok=True)
    args = [binpath, "--mode", "rpc",
            "--provider", "prime-inference", "--model", "mock-1",
            "--daemon-socket", os.path.join(trial, "d.sock")]
    env = scrub_env(os.environ)
    env.update({"HOME": home, "TMPDIR": tmp,
                "PRIME_AGENT_CODING_AGENT_DIR": agent,
                "PRIME_API_KEY": "sk-bench",
                "RUST_LOG": "error",
                "PATH": "/root/.cargo/bin:/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"})
    venv_env_path = os.path.join(TRIALS_ROOT, "venv-env.json")
    if os.path.exists(venv_env_path):
        env.update(json.load(open(venv_env_path)))
    else:
        env.update({"UV_CACHE_DIR": "/root/gam-uv-cache",
                    "UV_PYTHON_INSTALL_DIR": "/root/gam-uv-python"})
    receipt = {"trial": trial, "mode": mode, "argv_tail": args[1:]}
    zombie_sweep()
    while loadavg() > 1.0:
        time.sleep(2.0)
    t_spawn_wall, t_spawn_mono = time.time(), time.monotonic()
    spawn_args = args
    census_dir = os.environ.get("RPC_CENSUS_DIR")
    if census_dir:
        os.makedirs(census_dir, exist_ok=True)
        tag = os.environ.get("RPC_CENSUS_TAG", f"{mode}-{i:02d}")
        spawn_args = (["strace", "-ff", "-f", "-tt", "-T", "-yy",
                       "-e", "trace=openat,open,close,close_range,write,writev,fsync,fdatasync,sync_file_range,rename,renameat,renameat2,unlink,unlinkat,mkdir,mkdirat,rmdir,stat,statx,newfstatat,flock,fcntl",
                       "-o", os.path.join(census_dir, tag)]
                      + args)
        receipt["census"] = tag
    proc = subprocess.Popen(spawn_args, cwd=proj, env=env,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    conn = Conn(proc)
    receipt["audits"] = {}
    try:
        rid = "rdy"
        conn.send({"type": "get_state", "id": rid})
        resp, _ = conn.read_until_response(rid)
        t_ready = time.monotonic()
        receipt["launch_to_ready_ms"] = (t_ready - t_spawn_mono) * 1000.0
        receipt["ready_wall_s"] = time.time()
        state = resp.get("data") or {}
        receipt["ready_state"] = {"sessionId": state.get("sessionId"),
                                  "sessionFile": state.get("sessionFile"),
                                  "model": (state.get("model") or {}).get("id"),
                                  "success": resp.get("success")}
        cmds = []
        def do(cid, obj, settle=0.35, audit_key=None):
            before = audit_agent_dir(agent) if audit_key else None
            t0w, t0m = time.time(), time.monotonic()
            conn.send({"id": cid, **obj})
            keep = cid.startswith("gam")
            r, rlen = conn.read_until_response(cid, keep_raw=keep)
            t1m = time.monotonic()
            if settle:
                conn.drain_events(idle_s=settle, max_s=6.0)
            rec = {"id": cid, "ok": r.get("success"),
                   "ms": (t1m - t0m) * 1000.0, "resp_bytes": rlen, "t0_wall": t0w,
                   "err": r.get("error")}
            if audit_key:
                after = audit_agent_dir(agent)
                rec["audit_diff"] = diff_audit(before, after)
                receipt["audits"][audit_key] = {"after": {k: (v and {"size": v["size"], "mtime_ns": v["mtime_ns"]}) for k, v in after["files"].items()}}
            cmds.append(rec)
            return r
        do("st2", {"type": "get_state"})
        do("ssn", {"type": "set_session_name", "name": "gam-bench"})
        # settle: let create-time spawned background refresh land BEFORE gam
        # (its fetch/write can land anywhere; we want per-gam attribution clean)
        conn.drain_events(idle_s=8.0, max_s=8.0)
        receipt["audit_pre_gam"] = audit_agent_dir(agent)
        if mode == "gam-burst":
            for j in range(N_GAM):
                do(f"gam{j+1}", {"type": "get_available_models"}, audit_key=f"gam{j+1}")
        elif mode == "gam-isolate":
            for j in range(N_GAM):
                time.sleep(3.0)
                do(f"gam{j+1}", {"type": "get_available_models"}, audit_key=f"gam{j+1}")
        do("cam", {"type": "cycle_model"})
        do("stl", {"type": "set_thinking_level", "level": "low"})
        receipt["commands"] = cmds
        receipt["frames_n"] = len(conn.frames)
        t0m3 = time.monotonic()
        proc.stdin.close()
        rc = proc.wait(timeout=120)
        receipt["stdin_close_to_exit_ms"] = (time.monotonic() - t0m3) * 1000.0
        receipt["exit_code"] = rc
    finally:
        if proc.poll() is None:
            proc.kill()
        try:
            proc.wait(timeout=10)
        except Exception:
            pass
        receipt["stderr_tail"] = "".join(x[1] for x in conn.stderr_tail)[-4000:]
    receipt["audit_post_trial"] = audit_agent_dir(agent)
    rawdir = os.path.join(trial, "raw")
    os.makedirs(rawdir, exist_ok=True)
    keep = getattr(conn, "raw_keep", {}) or {}
    raws = {}
    for k, v in keep.items():
        with open(os.path.join(rawdir, f"resp-{k}.json"), "wb") as f:
            f.write(v)
        raws[k] = {"bytes": len(v), "sha": hashlib.sha256(v).hexdigest()}
    receipt["raw_responses"] = raws
    receipt["frames"] = [(w, round(m, 3), rl, o.get("type"),
                          o.get("command") or (o.get("data") or {}).get("type"))
                         for w, m, rl, o in conn.frames]
    with open(os.path.join(trial, "receipt.json"), "w") as f:
        json.dump(receipt, f, indent=1)
    return receipt

def main():
    mode = sys.argv[1]
    trials = int(sys.argv[2])
    binpath = os.path.abspath(sys.argv[3])
    out = sys.argv[-1]
    assert os.path.exists(binpath), binpath
    bin_sha = sha256_file(binpath)
    root = TRIALS_ROOT
    tag = os.environ.get("GAM_TAG")
    os.makedirs(root, exist_ok=True)
    receipts = []
    print("GAM_PROBE_START", mode, "trials", trials, "bin_sha", bin_sha[:16], flush=True)
    for i in range(trials):
        print("TRIAL_START", mode, i, flush=True)
        t0 = time.monotonic()
        r = run_trial(mode, i, binpath, root, tag=(f"{tag}" if tag else None))
        r["trial_wall_s"] = round(time.monotonic() - t0, 2)
        receipts.append(r)
        gams = [c["ms"] for c in r.get("commands", []) if c["id"].startswith("gam")]
        print(f"TRIAL {mode} {i} ready_ms={r.get('launch_to_ready_ms', -1):.1f} "
              f"gam_ms={[round(g,1) for g in gams]}", flush=True)
        time.sleep(2.0)
    summary = {"mode": mode, "trials": trials, "binary_sha256": bin_sha,
               "loadavg_last": loadavg(), "receipts": receipts}
    with open(out, "w") as f:
        json.dump(summary, f, indent=1)
    gams = [c["ms"] for c in sum((r.get("commands", []) for r in receipts), []) if str(c.get("id","")).startswith("gam")]
    if gams:
        gams_sorted = sorted(gams)
        print(f"SUMMARY {mode} gam n={len(gams)} p50={statistics.median(gams):.1f} "
              f"min={gams_sorted[0]:.1f} max={gams_sorted[-1]:.1f}", flush=True)
    print(f"OUT {out}", flush=True)

if __name__ == "__main__":
    main()
