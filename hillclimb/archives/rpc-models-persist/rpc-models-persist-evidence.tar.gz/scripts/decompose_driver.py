#!/usr/bin/env python3
"""Wave-5 decompose driver (VM top-level). Phases (checkpointed in /root/gam-legs/state.json):
   io-pre      probe_v09 preflight
   burst       rpc_probe_gam gam-burst 3 (timing; no census)
   census      1 trial under strace census + analyze
   isolate     rpc_probe_gam gam-isolate 2 (timing)
   probe       build + run the gam_probe component bin (VM-only probe)
Usage: decompose_driver.py <phase>
"""
import fcntl, hashlib, json, os, subprocess, sys, time

_fh = open("/root/gam-decompose.lock", "a")
try:
    fcntl.flock(_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    print("another decompose driver holds the lock; exiting", flush=True)
    sys.exit(0)

BENCH = "/root/bench-harness"
BIN = "/root/prime-agent-rust/target/release/prime-agent"
OUT = "/root/gam-legs"
STATE = os.path.join(OUT, "state.json")
MOCK_PORT = 8890

def load_state():
    if os.path.exists(STATE):
        return json.load(open(STATE))
    os.makedirs(OUT, exist_ok=True)
    return {"blocks": [], "probes": []}

def save_state(st):
    json.dump(st, open(STATE, "w"), indent=1)

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

def loadavg():
    return float(open("/proc/loadavg").read().split()[0])

def quiet_gate(max_wait=300):
    t0 = time.monotonic()
    while loadavg() > 1.0 and time.monotonic() - t0 < max_wait:
        time.sleep(2.0)
    return loadavg()

def sweep():
    out = subprocess.run(["ps", "-eo", "pid=,comm=,args="], capture_output=True, text=True).stdout
    killed = []
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid, comm, args = parts
        if comm.startswith("prime-agent") and "decompose_driver" not in args:
            killed.append(int(pid))
    for p in killed:
        try:
            os.kill(p, 9)
        except ProcessLookupError:
            pass
    if killed:
        time.sleep(1.0)
    return killed

def probe(tag):
    r = subprocess.run(["python3", "/root/probe_v09.py", "/root/gam-legs/io-probe", tag, "20.0"],
                       capture_output=True, text=True, timeout=300)
    return {"tag": tag, "rc": r.returncode, "out": r.stdout.strip(),
            "err": r.stderr.strip()[-500:], "t": time.time()}

def net_check():
    """Can the VM reach the catalog hosts? Determines the background refresh class."""
    res = {}
    for name, url in [("provider_catalog", "https://raw.githubusercontent.com/PrimeIntellect-ai/prime-agent-catalog/main/models/catalog.v1.json"),
                      ("pi_models", "https://api.pinference.ai/api/v1/models")]:
        t0 = time.monotonic()
        try:
            r = subprocess.run(["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
                                "--max-time", "6", url],
                               capture_output=True, text=True, timeout=10)
            res[name] = {"http": r.stdout.strip(), "sec": round(time.monotonic() - t0, 2), "rc": r.returncode}
        except Exception as e:
            res[name] = {"error": str(e), "sec": round(time.monotonic() - t0, 2)}
    return res

def mock_start():
    global MOCK_PROC
    out = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True, text=True).stdout
    for ln in out.splitlines():
        if "mock_provider" in ln and "decompose_driver" not in ln:
            try:
                os.kill(int(ln.split()[0]), 9)
            except (ProcessLookupError, ValueError):
                pass
            time.sleep(0.5)
    env = dict(os.environ)
    env["PYTHONPATH"] = BENCH
    MOCK_PROC = subprocess.Popen(["python3", "-m", "bench.drivers.mock_provider",
                                   "/root/rpc-mock/rpc-script.json", str(MOCK_PORT)],
                                  cwd=BENCH, env=env,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    line = MOCK_PROC.stdout.readline().decode().strip()
    if not line.isdigit():
        raise SystemExit(f"mock provider failed to start: {line!r}")
    print("MOCK_SERVER", line, flush=True)

MOCK_PROC = None
def mock_stop():
    global MOCK_PROC
    if MOCK_PROC is not None:
        MOCK_PROC.kill(); MOCK_PROC.wait(); MOCK_PROC = None

def gam_block(mode, trials, block_id, census=False):
    os.makedirs(os.path.join(OUT, "gam"), exist_ok=True)
    out = os.path.join(OUT, "gam", block_id + ".json")
    env = dict(os.environ)
    env["MOCK_BASE"] = f"http://127.0.0.1:{MOCK_PORT}/v1"
    if census:
        env["RPC_CENSUS_DIR"] = os.path.join(OUT, "census")
        env["RPC_CENSUS_TAG"] = block_id
    args = ["python3", "/root/rpc_probe_gam.py", mode, str(trials), BIN, out]
    t0 = time.time()
    r = subprocess.run(args, capture_output=True, text=True, env=env, timeout=3600)
    return {"block": block_id, "mode": mode, "trials": trials, "rc": r.returncode,
            "wall_s": round(time.time() - t0, 1),
            "out_tail": r.stdout[-3000:], "err_tail": r.stderr[-2000:], "out": out,
            "bin_sha": sha256(BIN)}

def main():
    phase = sys.argv[1]
    st = load_state()
    done = {b["block"] for b in st["blocks"]}
    if phase == "io-pre":
        p = probe("io-pre")
        st["probes"].append(p); save_state(st)
        print(p["out"] or p["err"])
        return
    if phase == "netcheck":
        print(json.dumps(net_check()))
        return
    if phase in ("burst", "census", "isolate"):
        mock_start()
    try:
        if phase == "burst":
            for i in range(3):
                bid = f"burst-{i+1}"
                if bid in done:
                    continue
                p = probe(f"{bid}-pre"); st["probes"].append(p); save_state(st)
                quiet_gate(); sweep()
                rec = gam_block("gam-burst", 1, bid)
                rec["probe"] = p["out"]
                st["blocks"].append(rec); save_state(st)
                print(json.dumps({k: rec[k] for k in ("block", "rc", "wall_s")}), flush=True)
        elif phase == "isolate":
            for i in range(2):
                bid = f"isolate-{i+1}"
                if bid in done:
                    continue
                p = probe(f"{bid}-pre"); st["probes"].append(p); save_state(st)
                quiet_gate(); sweep()
                rec = gam_block("gam-isolate", 1, bid)
                rec["probe"] = p["out"]
                st["blocks"].append(rec); save_state(st)
                print(json.dumps({k: rec[k] for k in ("block", "rc", "wall_s")}), flush=True)
        elif phase == "census":
            bid = "census-1"
            if bid not in done:
                quiet_gate(); sweep()
                rec = gam_block("gam-burst", 1, bid, census=True)
                st["blocks"].append(rec); save_state(st)
                # analyze
                outp = os.path.join(OUT, "census-analyze-1.json")
                r = subprocess.run(["python3", "/root/census_analyze.py",
                                    os.path.join(OUT, "census", bid),
                                    rec["out"], outp],
                                   capture_output=True, text=True)
                print("ANALYZE", r.returncode, r.stdout.strip(), r.stderr.strip()[-400:])
        elif phase == "probe":
            # build + run the component probe (VM-only bin; never committed)
            os.makedirs("/root/gam-legs/probe", exist_ok=True)
            src = "/root/gam_probe.rs"
            dst = "/root/prime-agent-rust/crates/pa-core/src/bin/gam_probe.rs"
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil_copy = subprocess.run(["cp", src, dst])
            b = subprocess.run(["bash", "-lc",
                                "source /root/.cargo/env && cd /root/prime-agent-rust && "
                                "cargo build --release -p pa-core --bin gam_probe 2>&1 | tail -3"],
                               capture_output=True, text=True, timeout=1800)
            sha_after_build = sha256(BIN)
            # run against a trial agent dir (from the burst legs)
            agent_dirs = []
            for root in ("/root/gam-trials",):
                for d in sorted(os.listdir(root)) if os.path.isdir(root) else []:
                    if d.startswith("gam-burst") and os.path.isdir(os.path.join(root, d, "agent")):
                        agent_dirs.append(os.path.join(root, d, "agent"))
            results = []
            for ad in agent_dirs[:2]:
                r = subprocess.run(["/root/prime-agent-rust/target/release/gam_probe", ad, "16"],
                                   capture_output=True, text=True, timeout=120)
                results.append({"agent": ad, "rc": r.returncode, "out": r.stdout, "err": r.stderr[-500:]})
            print(json.dumps({"build_rc": b.returncode, "build_tail": b.stdout[-300:],
                              "prime_agent_sha_after": sha_after_build,
                              "runs": results}, indent=1))
            # save raw
            json.dump({"build_rc": b.returncode, "prime_agent_sha_after": sha_after_build,
                       "runs": results}, open("/root/gam-legs/probe/component-probe.json", "w"), indent=1)
        else:
            raise SystemExit(f"unknown phase {phase}")
    finally:
        mock_stop()

if __name__ == "__main__":
    main()
