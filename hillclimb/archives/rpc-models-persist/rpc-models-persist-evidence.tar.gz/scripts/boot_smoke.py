#!/usr/bin/env python3
"""Mechanism smoke: bin-A vs bin-B boot cache-warm behavior (no commands)."""
import json, os, pathlib, shutil, subprocess, sys, time

MOCK = None
def start_mock():
    env = dict(os.environ)
    env["PYTHONPATH"] = "/root/bench-harness"
    p = subprocess.Popen(["python3", "-m", "bench.drivers.mock_provider",
                           "/root/rpc-mock/rpc-script.json", "8890"],
                          cwd="/root/bench-harness", env=env,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    line = p.stdout.readline().decode().strip()
    assert line.isdigit(), line
    return p

def write_models(agent):
    agent = pathlib.Path(agent)
    agent.mkdir(parents=True, exist_ok=True)
    models = {"providers": {"prime-inference": {
        "api": "openai-completions", "baseUrl": "http://127.0.0.1:8890/v1",
        "apiKey": "sk-bench",
        "models": [{"id": "mock-1", "name": "Mock 1", "api": "openai-completions",
                    "baseUrl": "http://127.0.0.1:8890/v1", "contextWindow": 128000,
                    "maxTokens": 4096}]}}}
    (agent / "models.json").write_text(json.dumps(models, indent=1))

def arm_run(arm, binpath, hold_s=6.0):
    root = pathlib.Path(f"/root/smoke-{arm}")
    if root.is_dir():
        shutil.rmtree(root)
    (root / "agent").mkdir(parents=True)
    (root / "proj").mkdir()
    (root / "home").mkdir()
    for name in ("auth.json", "settings.json"):
        src = pathlib.Path("/root/.prime/agent") / name
        if src.exists():
            shutil.copy(src, root / "agent" / name)
    write_models(root / "agent")
    env = {"HOME": str(root / "home"), "TMPDIR": str(root),
           "PATH": "/root/.cargo/bin:/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
           "PRIME_AGENT_CODING_AGENT_DIR": str(root / "agent"),
           "PRIME_API_KEY": "sk-bench", "RUST_LOG": "error",
           "PRIME_AGENT_KERNEL_VENV": "/root/bench/global/rust/kernel-venv",
           "UV_CACHE_DIR": "/root/bench/global/rust/uv-cache",
           "UV_PYTHON_INSTALL_DIR": "/root/.local/share/uv/python",
           "XDG_CACHE_HOME": "/root/bench/global/rust/xdg-cache"}
    proc = subprocess.Popen([binpath, "--mode", "rpc", "--provider", "prime-inference",
                            "--model", "mock-1", "--daemon-socket", str(root / "d.sock")],
                            cwd=str(root / "proj"), env=env,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    time.sleep(hold_s)
    caches = {}
    for rel in ("models/provider-model-catalog.v1.json",
                "models/prime-inference-models-cache.json",
                "prime-inference-private-models.json"):
        p = root / "agent" / rel
        caches[rel] = p.stat().st_size if p.exists() else None
    proc.stdin.close()
    try:
        proc.wait(timeout=20)
    except subprocess.TimeoutExpired:
        proc.kill()
    return {"arm": arm, "bin": binpath, "caches_after_boot": caches,
            "exit": proc.returncode}

mock = start_mock()
try:
    for arm, binpath in [("A", "/root/bins/bin-A"), ("B", "/root/bins/bin-B")]:
        print(json.dumps(arm_run(arm, binpath)))
finally:
    mock.kill()
print("SMOKE_DONE")
