#!/usr/bin/env python3
"""Per-command-window syscall census from strace -ff -f -tt -T -yy logs.

Usage: census_analyze.py <census_prefix> <receipts.json> <out.json>
Windows come from the driver receipts (t0_wall + ms). With -yy, write()
lines carry the decoded fd path, so every write is attributed to a real
file path (no content-guess classes).
"""
import glob, json, re, statistics, sys

LINE = re.compile(r"^(?:(\d+)\s+)?(\d\d:\d\d:\d\d\.\d+)\s+(.*)$")
def sec(x):
    h, m, s = x.split(":")
    return int(h) * 3600 + int(m) * 60 + float(s)

def load(prefix):
    files = sorted(glob.glob(prefix + "*"))
    events = []
    for path in files:
        file_tid = 0
        ms = re.search(r"\.(\d+)$", path)
        if ms:
            file_tid = int(ms.group(1))
        with open(path, errors="replace") as f:
            for ln in f:
                m = LINE.match(ln)
                if not m:
                    continue
                tid = int(m.group(1)) if m.group(1) else file_tid
                events.append((tid, sec(m.group(2)), m.group(3), path))
    events.sort(key=lambda e: e[1])
    return events, set(e[0] for e in events)

WRITE_PATH = re.compile(r'write\(\d+<([^>]*)>')
WRITEV_PATH = re.compile(r'writev\(\d+<([^>]*)>')
OPEN_RE = re.compile(r'openat\([^,]+, "([^"]*)", (.*?\))\s*=\s*(-?\d+)')
RENAME_RE = re.compile(r'rename\("([^"]*)", "([^"]*)"\)')
RENAMEAT_RE = re.compile(r'renameat2?\([^,]+, "([^"]*)", [^,]+, "([^"]*)"')

def main():
    prefix, receipts_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    events, tids = load(prefix)
    receipts = json.load(open(receipts_path))
    r0 = receipts["receipts"][0]
    spawn_epoch = r0["ready_wall_s"] - r0["launch_to_ready_ms"] / 1000.0
    offset = spawn_epoch - events[0][1] if events else 0.0
    events = [(tid, ts + offset, rest, path) for tid, ts, rest, path in events]
    spans = []
    for r in receipts.get("receipts", []):
        for c in r.get("commands", []):
            t0 = c.get("t0_wall")
            if t0 is None:
                continue
            spans.append((f"{r['trial']}/{c['id']}", t0,
                          t0 + max(c.get("ms", 1), 1) / 1000.0 + 0.02))
    out = {}
    for name, t0, t1 in spans:
        agg = {"writes": [], "opens_w": [], "renames": [], "fsyncs": 0,
               "fdatasyncs": 0, "n_events": 0, "reads_models_json": 0}
        for tid, ts, rest, _ in events:
            if not (t0 <= ts <= t1):
                continue
            agg["n_events"] += 1
            if rest.startswith("write("):
                m = WRITE_PATH.search(rest)
                agg["writes"].append({"path": m.group(1) if m else "<fd?>", "tid": tid,
                                      "rest": rest[:220]})
            elif rest.startswith("writev("):
                m = WRITEV_PATH.search(rest)
                agg["writes"].append({"path": m.group(1) if m else "<fd?>", "tid": tid,
                                      "rest": rest[:220]})
            elif rest.startswith("fsync(") and " = 0" in rest:
                agg["fsyncs"] += 1
            elif rest.startswith("fdatasync(") and " = 0" in rest:
                agg["fdatasyncs"] += 1
            elif rest.startswith("rename(") or rest.startswith("renameat"):
                m = RENAME_RE.search(rest) or RENAMEAT_RE.search(rest)
                if m:
                    agg["renames"].append({"from": m.group(1), "to": m.group(2), "tid": tid})
            elif rest.startswith("openat("):
                m = OPEN_RE.search(rest)
                if m and int(m.group(3)) >= 0:
                    flags = m.group(2)
                    if any(f in flags for f in ("O_WRONLY", "O_RDWR", "O_CREAT")):
                        agg["opens_w"].append({"path": m.group(1), "flags": flags, "tid": tid})
                    if m.group(1).endswith("/models.json") or m.group(1).endswith("models.json"):
                        agg["reads_models_json"] += 1
        out[name] = agg
    json.dump({"n_events": len(events), "n_tids": len(tids),
               "per_command": out}, open(out_path, "w"), indent=1)
    print("WROTE", out_path, "events", len(events), "tids", len(tids))

if __name__ == "__main__":
    main()
