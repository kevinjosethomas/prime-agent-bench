#!/usr/bin/env python3
"""Wave-5 ABBA driver: A=tip (bin-A), B=candidate (bin-B).
Rounds of A-B-B-A blocks; each block = 1 burst trial (fresh agent dir),
binary staged via unlink-then-copy with sha asserts pre/post; io-probe
(probe_v09) before every block; byte-oracle raws + cache shas per trial.
Usage: abba_driver.py <rounds>
State: /root/gam-legs/abba-state.json
"""
import fcntl, hashlib, json, os, subprocess, sys, time

_fh = open("/root/gam-abba.lock", "a")
try:
    fcntl.flock(_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    print("another abba driver holds the lock; exiting", flush=True)
    sys.exit(0)

BENCH = "/root/bench-harness"
BIN_A = "/root/bins/bin-A"
BIN_B = "/root/bins/bin-B"
STAGED = "/root/bins/current"
OUT = "/root/gam-legs"
STATE = os.path.join(OUT, "abba-state.json")
MOCK_PORT = 8890

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

def load_state():
    if os.path.exists(STATE):
        return json.load(open(STATE))
    os.makedirs(OUT, exist_ok=True)
    return {"blocks": [], "probes": []}

def save_state(st):
    json.dump(st, open(STATE, "w"), indent=1)

def loadavg():
    return float(open("/proc/loadavg").read().split()[0])

def quiet_gate(max_wait=300):
    t0 = time.monotonic()
    while loadavg() > 1.0 and time.monotonic() - t0 < max_wait:
        time.sleep(2.0)
    return loadavg()

def sweep():
    out = subprocess.run(["ps", "-eo", "pid=,comm=,args="], capture_output=True, text=True).stdout
    killed = []
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid, comm, args = parts
        if comm.startswith("prime-agent") and "abba_driver" not in args:
            killed.append(int(pid))
    for p in killed:
        try:
            os.kill(p, 9)
        except ProcessLookupError:
            pass
    if killed:
        time.sleep(1.0)
    return killed

def probe(tag):
    r = subprocess.run(["python3", "/root/probe_v09.py", "/root/gam-legs/io-probe-abba", tag, "20.0"],
                       capture_output=True, text=True, timeout=300)
    return {"tag": tag, "rc": r.returncode, "out": r.stdout.strip(),
            "err": r.stderr.strip()[-400:], "t": time.time()}

def stage(arm):
    src = BIN_A if arm == "A" else BIN_B
    if os.path.exists(STAGED):
        os.unlink(STAGED)
    subprocess.run(["cp", src, STAGED], check=True)
    return sha256(STAGED), sha256(src)

MOCK_PROC = None
def mock_start():
    global MOCK_PROC
    out = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True, text=True).stdout
    for ln in out.splitlines():
        if "mock_provider" in ln and "abba_driver" not in ln:
            try:
                os.kill(int(ln.split()[0]), 9)
            except (ProcessLookupError, ValueError):
                pass
            time.sleep(0.5)
    env = dict(os.environ)
    env["PYTHONPATH"] = BENCH
    MOCK_PROC = subprocess.Popen(["python3", "-m", "bench.drivers.mock_provider",
                                   "/root/rpc-mock/rpc-script.json", str(MOCK_PORT)],
                                  cwd=BENCH, env=env,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    line = MOCK_PROC.stdout.readline().decode().strip()
    if not line.isdigit():
        raise SystemExit(f"mock provider failed to start: {line!r}")
    print("MOCK_SERVER", line, flush=True)

def mock_stop():
    global MOCK_PROC
    if MOCK_PROC is not None:
        MOCK_PROC.kill(); MOCK_PROC.wait(); MOCK_PROC = None

def block(round_i, seq_i, arm):
    bid = f"abba-r{round_i}-{seq_i}-{arm}"
    os.makedirs(os.path.join(OUT, "abba"), exist_ok=True)
    out = os.path.join(OUT, "abba", bid + ".json")
    p = probe(f"{bid}-pre")
    st = load_state()
    st["probes"].append(p); save_state(st)
    quiet_gate(); sweep()
    staged_sha, src_sha = stage(arm)
    env = dict(os.environ)
    env["MOCK_BASE"] = f"http://127.0.0.1:{MOCK_PORT}/v1"
    env["GAM_TAG"] = bid
    args = ["python3", "/root/rpc_probe_gam.py", "gam-burst", "1", STAGED, out]
    t0 = time.time()
    r = subprocess.run(args, capture_output=True, text=True, env=env, timeout=1800)
    post_sha = sha256(STAGED)
    rec = {"block": bid, "arm": arm, "round": round_i, "seq": seq_i, "rc": r.returncode,
           "wall_s": round(time.time() - t0, 1),
           "staged_sha_pre": staged_sha, "src_sha": src_sha, "staged_sha_post": post_sha,
           "probe": p["out"],
           "out_tail": r.stdout[-2000:], "err_tail": r.stderr[-1500:], "out": out}
    st = load_state()
    st["blocks"].append(rec); save_state(st)
    print(json.dumps({k: rec[k] for k in ("block", "arm", "rc", "wall_s")}), flush=True)
    return rec

def main():
    rounds = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    # sanity: arms must differ and exist
    sha_a, sha_b = sha256(BIN_A), sha256(BIN_B)
    print("ARM_SHAS", sha_a[:16], sha_b[:16], "differ:", sha_a != sha_b, flush=True)
    assert sha_a != sha_b
    mock_start()
    try:
        for rd in range(1, rounds + 1):
            for seq, arm in [(1, "A"), (2, "B"), (3, "B"), (4, "A")]:
                block(rd, seq, arm)
                time.sleep(2.0)
    finally:
        mock_stop()
    p = probe("abba-post")
    st = load_state()
    st["probes"].append(p); save_state(st)
    print(p["out"], flush=True)
    print("ABBA_DONE", flush=True)

if __name__ == "__main__":
    main()
