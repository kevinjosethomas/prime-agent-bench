
#!/usr/bin/env python3
"""Apply the dead_sidecar registration entry to BOTH known_reds.json copies
(live module copy + fleet-tools VC repo), then verify the auto-citation."""
import json, subprocess, sys, hashlib, shutil

LIVE = '/home/ubuntu/.prime/agent/fleet-tools/known_reds.json'
VC   = '/home/ubuntu/lane-worktrees/fleet-tools/known_reds.json'
ENTRY = json.load(open('/home/ubuntu/worktrees/perf-deadsidecar-renewal/_lane/entry_final.json'))

def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()

assert sha(LIVE) == sha(VC), 'pre-apply copies DIVERGED - stop'
pre_sha = sha(LIVE)
print('pre-apply sha (both copies):', pre_sha)

live = json.load(open(LIVE))
assert not any(e['id'] == ENTRY['id'] for e in live['reds']), 'entry already present'
# sanity: no existing pattern may match this failname FIRST (order matters)
for e in live['reds']:
    assert e['pattern'] not in 'dead_sidecar_degrades_to_errors_not_panics', \
        f"EXISTING pattern {e['pattern']!r} would shadow the new entry"
live['reds'].append(ENTRY)
live['updated'] = '2026-09-27'
for p in (LIVE, VC):
    with open(p, 'w') as f:
        json.dump(live, f, indent=2)
        f.write('\n')
assert sha(LIVE) == sha(VC), 'post-apply copies diverged'
print('post-apply sha (both copies):', sha(LIVE))

# auto-citation verification through the REAL classifier
sys.path.insert(0, '/home/ubuntu/.prime/agent/fleet-tools')
import fleet_pipeline
failures, unknown = fleet_pipeline._classify(['dead_sidecar_degrades_to_errors_not_panics'])
print('CLASSIFY RESULT:', json.dumps(failures, indent=1))
print('UNKNOWN LIST:', unknown)
assert failures and failures[0]['known_red'] and not failures[0].get('expired'), \
    'auto-citation FAILED'
assert failures[0]['entry'] == ENTRY['id'], 'wrong entry attached'
print('AUTO-CITATION OK:', failures[0]['classification'][:120], '...')

# shadow-check: the new pattern must not match any OTHER registered failname shape
others = ['abort_compaction_mid_threshold_run_records_the_cancelled_outcome',
          'wedged_worker_abort_acks_immediately_and_declares_terminal',
          'worker_begin_login_persists_creds_and_unlocks_gating',
          'callback_flow_settles_code_and_state', 'multi_item_queue_delivers_every_item_in_lane_order',
          'concurrent_spawns', 'ranked_hits_sort_by_relevance_then_recency',
          'supervisor_restart_loop', 'tool_result_entries_persisted_and_streamed',
          'tui_side_question_pane_flow', 'worker::turn_stream_tests::abort_and_send_queued_acks']
for o in others:
    assert ENTRY['pattern'] not in o, f'new pattern shadows {o}'
print('no-shadow check OK')
print('APPLY_DONE')
