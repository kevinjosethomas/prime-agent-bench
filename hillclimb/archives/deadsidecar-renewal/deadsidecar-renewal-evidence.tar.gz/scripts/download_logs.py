
import sys, os, json
sys.path.insert(0, '/home/ubuntu/.venvs/psb/lib/python3.11/site-packages')
from prime_sandboxes import APIClient, SandboxClient
client = SandboxClient(api_client=APIClient())
LANE = '/home/ubuntu/worktrees/perf-deadsidecar-renewal/_lane'
OUT = LANE + '/vm-logs'
os.makedirs(OUT, exist_ok=True)
files = ['t2_bootstrap.log','t3_solo.log','t4_venv.log','t5_full.log','p3_full_run1.log','p3_full_run2.log']
for f in files:
    try:
        data = client.download_file('aji6t7jw9t67ncbb3evhljl7', '/workspace/logs/' + f)
        content = data if isinstance(data, (bytes, bytearray)) else (getattr(data, 'content', None) or data)
        if isinstance(content, str):
            content = content.encode()
        open(os.path.join(OUT, f), 'wb').write(content)
        print('downloaded', f, len(content), 'bytes')
    except Exception as e:
        print('FAILED', f, repr(e))
        try:
            script = f"cat /workspace/logs/{f}"
            resp = client.execute_command('aji6t7jw9t67ncbb3evhljl7', script, timeout=600)
            out = getattr(resp, 'stdout', '') or ''
            open(os.path.join(OUT, f), 'w').write(out)
            print('downloaded via exec', f, len(out), 'chars')
        except Exception as e2:
            print('FAILED-EXEC', f, repr(e2))
# VM-side shas for verification before deletion
try:
    resp = client.execute_command('aji6t7jw9t67ncbb3evhljl7',
        'cd /workspace/logs && sha256sum t2_bootstrap.log t3_solo.log t4_venv.log t5_full.log p3_full_run1.log p3_full_run2.log',
        timeout=300)
    open(LANE + '/vm-logs/vm_side_sha256.txt','w').write(getattr(resp,'stdout','') or '')
    print(getattr(resp,'stdout',''))
except Exception as e:
    print('SHA FAIL', repr(e))
