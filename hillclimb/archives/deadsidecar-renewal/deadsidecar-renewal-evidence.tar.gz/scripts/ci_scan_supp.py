
import subprocess, json, os, time
OUT = '/home/ubuntu/worktrees/perf-deadsidecar-renewal/_lane/ci-scan'
REPO = 'PrimeIntellect-ai/prime-agent'
WF = '272993499'
SHARD_NAME = 'test shard 1/4'
WINDOW = '2026-09-24T00:00:00Z..2026-09-25T19:42:00Z'

def gh_api(path, retries=5):
    for i in range(retries):
        r = subprocess.run(['gh', 'api', path], capture_output=True, text=True)
        if r.returncode == 0:
            return json.loads(r.stdout)
        time.sleep(3 * (i + 1))
    return None

all_runs, page = [], 1
while True:
    data = gh_api(f'repos/{REPO}/actions/workflows/{WF}/runs?per_page=100&page={page}&created={WINDOW}')
    if not data or not data.get('workflow_runs'):
        break
    all_runs.extend(data['workflow_runs'])
    if len(data['workflow_runs']) < 100:
        break
    page += 1
    if page > 20:
        break
uniq = {}
for r in all_runs:
    uniq[r['id']] = r
runs = sorted(uniq.values(), key=lambda r: r['created_at'])
print(f'supplement window {WINDOW}: {len(runs)} runs', flush=True)

census, logfetch, misses = [], [], 0
for i, run in enumerate(runs):
    rid = run['id']
    data = gh_api(f'repos/{REPO}/actions/runs/{rid}/jobs?per_page=100')
    if not data:
        misses += 1
        census.append({'run': rid, 'head': run['head_sha'], 'created': run['created_at'], 'shard1': 'MISSING'})
        continue
    s1 = next((j for j in data.get('jobs', []) if j['name'] == SHARD_NAME), None)
    entry = {'run': rid, 'head': run['head_sha'], 'created': run['created_at'],
             'shard1': (s1 or {}).get('conclusion'), 'shard1_job_id': (s1 or {}).get('id')}
    census.append(entry)
    if entry['shard1_job_id'] and entry['shard1'] != 'success':
        logfetch.append(entry)
    if (i + 1) % 100 == 0:
        print(f'supp census {i+1}/{len(runs)}', flush=True)
json.dump(census, open(f'{OUT}/shard1_census_supp.json', 'w'), indent=1)
ok = sum(1 for e in census if e['shard1'] == 'success')
print(f'supp census done: {len(census)}; shard1 success: {ok}; non-success to fetch: {len(logfetch)}; missing: {misses}', flush=True)

details = []
for j, entry in enumerate(logfetch):
    r = subprocess.run(['gh', 'run', 'view', '--job', str(entry['shard1_job_id']), '-R', REPO, '--log'],
                       capture_output=True, text=True)
    out = r.stdout or ''
    lines = out.split('\n')
    ds = [l for l in lines if 'dead_sidecar_degrades_to_errors_not_panics' in l]
    bp = [l for l in lines if 'Broken pipe' in l]
    dr = [l for l in lines if 'death reason missing' in l]
    d = {'run': entry['run'], 'head': entry['head'], 'created': entry['created'],
         'shard1': entry['shard1'], 'dead_sidecar_lines': ds[:8], 'broken_pipe': bp[:4], 'death_reason': dr[:4]}
    details.append(d)
    if (j + 1) % 50 == 0:
        print(f'supp logfetch {j+1}/{len(logfetch)}', flush=True)
        json.dump(details, open(f'{OUT}/shard1_logdetails_supp.json', 'w'), indent=1)
json.dump(details, open(f'{OUT}/shard1_logdetails_supp.json', 'w'), indent=1)
n_green = sum(1 for d in details if any('... ok' in l for l in d['dead_sidecar_lines']))
n_red = sum(1 for d in details if any('FAILED' in l for l in d['dead_sidecar_lines']))
n_absent = sum(1 for d in details if not d['dead_sidecar_lines'])
print(f'SUPP LOG SCAN: fetched {len(details)}; dead_sidecar ok-lines: {n_green}; FAILED: {n_red}; absent: {n_absent}', flush=True)
print('SUPP_DONE')
