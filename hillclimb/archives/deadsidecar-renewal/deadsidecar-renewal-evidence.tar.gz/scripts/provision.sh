#!/bin/bash
/home/ubuntu/.venvs/psb/bin/python - <<'EOF'
from prime_sandboxes import SandboxClient, APIClient, CreateSandboxRequest
from prime_sandboxes.models import StartCommand
import json
c = SandboxClient(APIClient())
try:
    sb = c.create(CreateSandboxRequest(
        name="hillclimb-deadsidecar-renewal",
        docker_image="rust:1-bookworm",
        cpu_cores=8.0, memory_gb=32.0, disk_size_gb=100.0,
        timeout_minutes=10080, vm=True, network_access=True,
        start_command=StartCommand(executable="sleep", args=["infinity"]),
    ))
except Exception as e:
    print("create rejected, retry 240m:", repr(e))
    sb = c.create(CreateSandboxRequest(
        name="hillclimb-deadsidecar-renewal",
        docker_image="rust:1-bookworm",
        cpu_cores=8.0, memory_gb=32.0, disk_size_gb=100.0,
        timeout_minutes=240, vm=True, network_access=True,
        start_command=StartCommand(executable="sleep", args=["infinity"]),
    ))
c.wait_for_creation(sandbox_id=sb.id)
print("VM_ID", sb.id)
json.dump({"sandbox_id": sb.id, "name": "hillclimb-deadsidecar-renewal",
           "image": "rust:1-bookworm", "cpu": 8, "mem_gb": 32, "disk_gb": 100,
           "purpose": "dead_sidecar broken-pipe known-red registration (wave-5 hygiene lane): solo x5 release/debug + co-scheduled full-suite x2 at tip 07f42eaa3",
           "created": "2026-09-27"},
          open('/home/ubuntu/hillclimb/vms/deadsidecar-renewal.json','w'), indent=1)
print("PROVISION_DONE")
EOF
