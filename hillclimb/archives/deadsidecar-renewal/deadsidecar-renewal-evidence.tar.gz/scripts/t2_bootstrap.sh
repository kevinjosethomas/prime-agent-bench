set -o pipefail
export HOME=/root
mkdir -p /root/triage /workspace/logs
{
  echo "T2_START $(date -u +%FT%TZ)"
  # /etc/hosts guard (fleet v1.4.6 recipe): the image build can ship a NUL-padded
  # file; probe, overwrite-if-broken (never append), probe-assert.
  if ! getent hosts localhost >/dev/null 2>&1; then
    echo "HOSTS_BROKEN (od): $(od -c /etc/hosts | head -2)"
    printf '127.0.0.1 localhost\n::1 localhost ip6-localhost ip6-loopback\n192.0.2.1 prime.internal\n' > /etc/hosts
    echo HOSTS_REPAIRED
  else
    echo HOSTS_OK
  fi
  getent hosts localhost >/dev/null 2>&1 || { echo HOSTS_GUARD_FAILED; exit 2; }
  dpkg --configure -a || true
  apt-get update -q
  DEBIAN_FRONTEND=noninteractive apt-get install -y -q iproute2 lsof nodejs npm curl git ca-certificates pkg-config build-essential > /dev/null 2>&1
  node --version
  NODE_MAJOR=$(node --version | sed 's/^v//' | cut -d. -f1)
  if [ "$NODE_MAJOR" -lt 18 ]; then echo "NODE_FLOOR_FAILED ($NODE_MAJOR < 18: the extension tests would SKIP)"; exit 3; fi
  echo "NODE_FLOOR_OK ($NODE_MAJOR)"
  export PATH="/root/.local/bin:$PATH"
  command -v uv >/dev/null 2>&1 || curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="/root/.cargo/bin:$PATH"
  rustup toolchain install 1.98.1 --profile minimal --component rustfmt --component clippy
  rustup default 1.98.1
  rustup component add rustfmt clippy || true
  rustc -V | grep -q "1.98.1" || { echo "TOOLCHAIN_PIN_FAILED"; exit 3; }
  echo "TOOLCHAIN_OK"
  mkdir -p /workspace/prime-agent
  cd /workspace/prime-agent
  if [ ! -d .git ]; then git clone --depth 100 -b rust https://github.com/PrimeIntellect-ai/prime-agent.git /workspace/prime-agent 2>&1 | tail -2; fi
  git fetch --depth 100 origin '+refs/heads/rust:refs/remotes/origin/rust' 2>&1 | tail -2
  git checkout --detach 07f42eaa3a6159f942c6c24beb0352ce120a192c 2>&1 | tail -1
  git rev-parse HEAD | grep -q 07f42eaa3a6159f942c6c24beb0352ce120a192c || { echo "HEAD_PIN_FAILED"; exit 4; }
  echo "HEAD=$(git rev-parse HEAD)"
  echo "SOLO_RELEASE_COMPILE_START $(date -u +%s)"
  cargo +1.98.1 test --release --locked -p pa-core --test extension_runner --no-run 2>&1 | tail -3
  echo "SOLO_RELEASE_COMPILE_RC=$?"
  echo "SOLO_DEBUG_COMPILE_START $(date -u +%s)"
  cargo +1.98.1 test --locked -p pa-core --test extension_runner --no-run 2>&1 | tail -3
  echo "SOLO_DEBUG_COMPILE_RC=$?"
  echo "WORKSPACE_DEBUG_COMPILE_START $(date -u +%s)"
  cargo +1.98.1 test --workspace --locked --no-run 2>&1 | tail -3
  echo "WORKSPACE_DEBUG_COMPILE_RC=$?"
  echo "T2_DONE $(date -u +%FT%TZ)"
} > /workspace/logs/t2_bootstrap.log 2>&1
RC=$?
tail -25 /workspace/logs/t2_bootstrap.log
exit $RC
