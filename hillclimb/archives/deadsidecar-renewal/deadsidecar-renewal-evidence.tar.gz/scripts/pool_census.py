
import sys, json
sys.path.insert(0, '/home/ubuntu/.venvs/psb/lib/python3.11/site-packages')
from prime_sandboxes import APIClient, SandboxClient
client = SandboxClient(api_client=APIClient())
script = r"""
for L in /workspace/logs/p3_test_*.log; do
  if grep -q 'Running tests/extension_runner.rs' "$L" 2>/dev/null; then
    DS=$(grep -E '^test dead_sidecar_degrades_to_errors_not_panics \.\.\. ' "$L" | head -1)
    RES=$(grep -A6 'Running tests/extension_runner.rs' "$L" | grep -E '^test result:' | head -1)
    BP=$(grep -c 'Broken pipe' "$L")
    WHEN=$(stat -c %y "$L" | cut -c1-19)
    echo "$(basename $L)|$WHEN|$DS|$RES|BP=$BP"
  fi
done
"""
for sid, slot in [('ykp6mbwtdtz17w58tayfa0yw','slot0'), ('bvwr5lk9t7jbsj3e5tc6x7im','slot1')]:
    try:
        resp = client.execute_command(sid, script, timeout=600)
        out = getattr(resp, 'stdout', '') or ''
        print(f'==== {slot} ({sid})')
        print(out)
    except Exception as e:
        print(f'{slot} FAILED:', repr(e))
