
import sys
sys.path.insert(0, '/home/ubuntu/.venvs/psb/lib/python3.11/site-packages')
from prime_sandboxes import APIClient, SandboxClient
client = SandboxClient(api_client=APIClient())
script = r"""
for F in p3_test_gate_1790300293_3623104.log p3_test_review_1790318334_3833108.log p3_test_gate_1790336955_3833128.log; do
  echo "=== $F"
  grep -n -m3 'Broken pipe' /workspace/logs/$F
done
"""
resp = client.execute_command('ykp6mbwtdtz17w58tayfa0yw', script, timeout=600)
print(getattr(resp,'stdout',''))
print(getattr(resp,'stderr',''))
