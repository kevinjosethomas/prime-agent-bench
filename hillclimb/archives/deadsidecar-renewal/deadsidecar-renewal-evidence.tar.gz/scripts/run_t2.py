import sys
sys.path.insert(0, '/home/ubuntu/.venvs/psb/lib/python3.11/site-packages')
from prime_sandboxes import APIClient, SandboxClient
client = SandboxClient(api_client=APIClient())
script = open('/home/ubuntu/worktrees/perf-deadsidecar-renewal/_lane' + '/t2_bootstrap.sh').read()
resp = client.execute_command('aji6t7jw9t67ncbb3evhljl7', script, timeout=10800)
rc = getattr(resp, 'exit_code', -1)
out = (getattr(resp, 'stdout', '') or '') + (getattr(resp, 'stderr', '') or '')
print('RC', rc)
print(out[-4000:])
