
set -o pipefail
export HOME=/root
export PATH="/root/.cargo/bin:/root/.local/bin:$PATH"
{
  echo "T3_START $(date -u +%FT%TZ)"
  echo "node $(node --version) nproc=$(nproc) load: $(cat /proc/loadavg)"
  cd /workspace/prime-agent
  echo "HEAD=$(git rev-parse HEAD)"
  for i in 1 2 3 4 5; do
    echo "=== SOLO RELEASE run $i $(date -u +%T)"
    s=$(date +%s)
    cargo +1.98.1 test --release --locked -p pa-core --test extension_runner dead_sidecar_degrades_to_errors_not_panics 2>&1
    echo "SOLO_RELEASE_RC_$i=${PIPESTATUS[0]} dur=$(( $(date +%s) - s ))s"
  done
  for i in 1 2 3 4 5; do
    echo "=== SOLO DEBUG run $i $(date -u +%T)"
    s=$(date +%s)
    cargo +1.98.1 test --locked -p pa-core --test extension_runner dead_sidecar_degrades_to_errors_not_panics 2>&1
    echo "SOLO_DEBUG_RC_$i=${PIPESTATUS[0]} dur=$(( $(date +%s) - s ))s"
  done
  echo "T3_DONE $(date -u +%FT%TZ)"
} > /workspace/logs/t3_solo.log 2>&1
RC=$?
tail -60 /workspace/logs/t3_solo.log
exit $RC
