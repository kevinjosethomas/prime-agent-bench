#!/usr/bin/env python3
"""Cold-cache block: drop page caches before every trial."""
import json, subprocess, sys, pathlib, shutil

BIN_PROBE = "/root/bins/probe/prime-agent"
TRIALS = pathlib.Path("/root/trials-io")

def run_trial(leg, fx_label, fx_path, idx):
    tdir = TRIALS / f"cold-{leg}-{fx_label}-{idx:02d}"
    if tdir.exists():
        shutil.rmtree(tdir)
    cmd = ["python3", "/root/io_lane/io_open_bench.py",
           "--trial-dir", str(tdir), "--binary", BIN_PROBE,
           "--fixture", fx_path, "--fixture-label", fx_label,
           "--leg", leg, "--label", f"cold-{leg}-{fx_label}-{idx}", "--drop-caches"]
    if fx_label.startswith("fx-mid"):
        cmd += ["--needle-chat", "add curated session blacklist"]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    print(f"COLD TRIAL {leg} {fx_label} {idx} rc={r.returncode} :: {(r.stdout or '')[-260:]}", flush=True)
    if r.returncode != 0:
        print("STDERR", (r.stderr or "")[-1200:], flush=True)

matrix = [
    ("open", "fx-real", "/root/io_lane/fx-real.jsonl", 3),
    ("open", "fx-real-strip", "/root/io_lane/fx-real-strip.jsonl", 3),
    ("agents", "fx-real", "/root/io_lane/fx-real.jsonl", 2),
    ("agents", "fx-real-strip", "/root/io_lane/fx-real-strip.jsonl", 2),
]
for leg, fx_label, fx_path, n in matrix:
    for i in range(n):
        run_trial(leg, fx_label, fx_path, i)
print("COLD_DONE", flush=True)
