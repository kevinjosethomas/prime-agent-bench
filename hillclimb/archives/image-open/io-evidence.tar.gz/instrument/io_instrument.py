#!/usr/bin/env python3
"""image-open phase instrument: patch a PROBE COPY of the repo with an
env-gated JSONL phase trace (PRIME_AGENT_IO_TRACE=<path>), then the caller
builds bin-probe. Measurement-only; the probe tree never ships."""
import sys, pathlib

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/root/probe-rust")
SRC = pathlib.Path("/root/io_lane/io_trace.rs")
T = pa_types = ROOT / "crates/pa-types"
CORE = ROOT / "crates/pa-core"
DAEMON = ROOT / "crates/pa-daemon"
TUI = ROOT / "crates/pa-tui"

def patch(path, anchor, insert, count=1, before=False):
    p = pathlib.Path(path)
    src = p.read_text()
    n = src.count(anchor)
    assert n == count, f"{p.name}: anchor count {n} != {count} for {anchor[:70]!r}"
    out = src.replace(anchor, insert + anchor if before else anchor + insert, 1)
    p.write_text(out)
    print(f"patched {p.name}: {'+' if before else 'append'} {insert.strip()[:60]!r}")

# --- pa-types: the trace module -------------------------------------------------
(pa_types / "src/io_trace.rs").write_text(SRC.read_text())
patch(pa_types / "src/lib.rs", "pub mod ai;\n", "pub mod io_trace;\n")

# --- pa-core: the windowed open (the backward scan) ------------------------------
W = CORE / "src/session/window.rs"
patch(W, "        let mut reads = WindowReadStats::default();\n",
      "        pa_types::io_trace::mark(\"sf_open_start\");\n")
patch(W, "        if let Some(snapshot) = window_cache::load(path, &file, &mut reads) {\n",
      "            pa_types::io_trace::mark_n(\"sf_sidecar_hit\", 1.0);\n")
patch(W, "        let Some(FileEntry::Header {",
      "        pa_types::io_trace::mark_n(\"sf_scan_done\", reader.reads.jsonl_bytes as f64);\n"
      "        pa_types::io_trace::mark_n(\"sf_scan_ranges\", reader.reads.jsonl_ranges.len() as f64);\n"
      "        pa_types::io_trace::mark_n(\"sf_retained_rows\", retained.len() as f64);\n", before=True)
patch(W, "        let mut context = build_session_context(&self.entries, Some(&self.leaf_id));\n",
      "        pa_types::io_trace::mark(\"ctx_build_start\");\n", before=True)
patch(W, "        if !self.full {\n            context\n                .thinking_level\n                .clone_from(&self.settings.thinking_level);\n",
      "        pa_types::io_trace::mark_n(\"ctx_msgs\", context.messages.len() as f64);\n", before=True)

# --- pa-daemon: the store open_windowed ------------------------------------------
R = DAEMON / "src/session_store/read.rs"
patch(R, "    pub fn open_windowed(path: &Path) -> Result<Self> {\n",
      "        pa_types::io_trace::mark(\"store_open_start\");\n")
patch(R, "        let header = window\n            .entries()\n            .iter()\n            .find_map(|entry| match entry {\n                pa_types::session::FileEntry::Header { header } => Some(header.clone()),\n                _ => None,\n            })\n            .ok_or_else(|| anyhow!(\"window has no session header\"))?;\n",
      "        pa_types::io_trace::mark(\"store_window_open\");\n")
patch(R, "        // that has not joined the index yet).\n        fold_child_usage_attributions(&mut file.entries);\n",
      "        pa_types::io_trace::mark_n(\"store_rows\", file.entries.len() as f64);\n", before=True)
patch(R, "        file.window = Some(SessionWindow {\n",
      "        pa_types::io_trace::mark(\"store_window_build\");\n", before=True)
patch(R, "        Ok(file)\n    }\n\n    #[cfg(test)]\n    pub(super) fn ensure_full_history",
      "        pa_types::io_trace::mark(\"store_open_done\");\n", before=True)

# --- pa-daemon: worker create (the resume load + the append persist) ---------------
C = DAEMON / "src/worker/create.rs"
patch(C, "                        let persisted = if opened.window.is_some() {\n",
      "                        pa_types::io_trace::mark(\"create_persist_start\");\n")
patch(C, "        let restored_tier = store\n",
      "        pa_types::io_trace::mark(\"create_persist_done\");\n", before=True)

# --- pa-daemon: worker handle_attach ----------------------------------------------
CO = DAEMON / "src/worker/connection.rs"
patch(CO, "        self.poke_context_tree_refresh();\n",
      "        pa_types::io_trace::mark(\"attach_in\");\n")
patch(CO, "        let summary = self.summary_locked(&core);\n",
      "        pa_types::io_trace::mark(\"attach_summary_done\");\n")
patch(CO, "        let messages: Vec<Value> = core\n            .store\n            .as_ref()\n            .map(crate::session_store::SessionFile::messages)\n            .unwrap_or_default();\n",
      "        pa_types::io_trace::mark_n(\"attach_msgs_n\", messages.len() as f64);\n")
patch(CO, "        response_success(None, \"attach\", Some(result))",
      "        pa_types::io_trace::mark(\"attach_built\");\n", before=True)

# --- pa-daemon: the saved-session roster scan -------------------------------------
S = DAEMON / "src/session_scan.rs"
S_src = pathlib.Path(S).read_text()
anchor = "fn roster_session_info(path: &Path) -> Option<SessionInfo> {"
assert S_src.count(anchor) == 1
S_src = S_src.replace(anchor,
    "fn roster_session_info(path: &Path) -> Option<SessionInfo> {\n"
    "    let __t = std::time::Instant::now();\n"
    "    let __sz = fs::metadata(path).map(|m| m.len()).unwrap_or(0);\n"
    "    let __name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();\n"
    "    pa_types::io_trace::mark_s(\"list_file\", &__name);\n"
    "    let __r = roster_session_info_inner(path);\n"
    "    pa_types::io_trace::mark_n(\"list_file_ms\", __t.elapsed().as_secs_f64() * 1000.0);\n"
    "    pa_types::io_trace::mark_n(\"list_file_bytes\", __sz as f64);\n"
    "    __r\n}\n\nfn roster_session_info_inner(path: &Path) -> Option<SessionInfo> {", 1)
pathlib.Path(S).write_text(S_src)
print("patched session_scan.rs: roster per-file timing")

SE = DAEMON / "src/supervisor/sessions.rs"
patch(SE, "        let scope_current = scope.as_str() == Some(\"current\");\n",
      "        pa_types::io_trace::mark(\"list_start\");\n", before=True)

# --- pa-tui: the open / attach / fold / rebuild / frame ledger ---------------------
SU = TUI / "src/session_ui.rs"
patch(SU, "        let active_session_id = match &options.session {\n",
      "        pa_types::io_trace::mark(\"open_start\");\n", before=True)
patch(SU, "        let direct_attached = self\n            .client\n            .upgrade_direct(active_session_id)\n            .await\n            .unwrap_or(false);\n",
      "        pa_types::io_trace::mark(\"attach_sent\");\n", before=True)
patch(SU, "        let attach = attach_data_from_response(data)?;\n",
      "        pa_types::io_trace::mark(\"attach_done\");\n")
patch(SU, "        let reconstructed = reconstruct(&attach);\n",
      "        pa_types::io_trace::mark_n(\"attach_wire_msgs\", attach.snapshot.get(\"messages\").and_then(serde_json::Value::as_array).map(|a| a.len()).unwrap_or(0) as f64);\n", before=True)
patch(SU, "        let reconstructed = reconstruct(&attach);\n",
      "        pa_types::io_trace::mark(\"reconstructed\");\n")
patch(SU, "        self.subscribe_roster().await;\n",
      "        pa_types::io_trace::mark(\"roster_done\");\n")
patch(SU, "            DockFold::FirstFrame => self.fetch_heartbeat_catalog().await,\n            DockFold::Fresh | DockFold::Held => self.spawn_heartbeat_refresh(),\n        }\n",
      "        pa_types::io_trace::mark(\"hb_done\");\n")
patch(SU, "            DockFold::FirstFrame => self.fetch_bash_activities().await,\n            DockFold::Fresh | DockFold::Held => self.spawn_bash_activity_refresh(),\n        }\n",
      "        pa_types::io_trace::mark(\"bash_done\");\n")

SF = TUI / "src/session_ui/sessions_fork.rs"
patch(SF, "    let data = match client\n        .request_ok(DaemonCommand::Create {\n",
      "    pa_types::io_trace::mark(\"create_sent\");\n", before=True)
patch(SF, "    data.get(\"activeSessionId\")\n",
      "    pa_types::io_trace::mark(\"create_done\");\n", before=True)

RUN = TUI / "src/interactive/run.rs"
patch(RUN, "    let (client, events) = DaemonClient::connect_with_retry(&options.socket_path)\n        .await\n        .with_context(|| \"the interactive UI could not attach to the daemon\")?;\n",
      "    pa_types::io_trace::mark(\"connected\");\n")
patch(RUN, "        session.osc_sink = crate::clipboard::OscSink::Buffer(Vec::new());\n    }\n    session.refresh_stats().await;\n",
      "    pa_types::io_trace::mark(\"stats\");\n")
patch(RUN, "    session.rebuild_view(&mut view, crate::session_ui::RebuildKind::Rebind);\n",
      "    pa_types::io_trace::mark(\"rebuilt\");\n")
run_src = pathlib.Path(RUN).read_text()
frame_anchor = "                if interval_elapsed {\n                    crate::app::draw(renderer, &mut view)?;\n                    session.dirty = false;\n"
assert run_src.count(frame_anchor) == 1, run_src.count(frame_anchor)
run_src = run_src.replace(frame_anchor,
    "                if interval_elapsed {\n"
    "                    pa_types::io_trace::mark(\"frame\");\n"
    "                    crate::app::draw(renderer, &mut view)?;\n"
    "                    session.dirty = false;\n"
    "                    pa_types::io_trace::mark(\"frame_done\");\n", 1)
inline_anchor = "                        view.chrome.tray_override = session.tray_override(&view);\n                        crate::app::draw(renderer, &mut view)?;\n"
assert run_src.count(inline_anchor) == 1, run_src.count(inline_anchor)
run_src = run_src.replace(inline_anchor,
    "                        view.chrome.tray_override = session.tray_override(&view);\n"
    "                        pa_types::io_trace::mark(\"frame_inline\");\n"
    "                        crate::app::draw(renderer, &mut view)?;\n", 1)
pathlib.Path(RUN).write_text(run_src)
print("patched run.rs: frame marks")

V = TUI / "src/view.rs"
patch(V, "    pub fn render_frame(&mut self, width: usize, height: usize) -> Vec<Line> {",
      "        pa_types::io_trace::mark(\"compose_start\");\n")
patch(V, "        self.frame_links = crate::hyperlinks::frame_link_ranges(&frame);\n        frame\n",
      "        pa_types::io_trace::mark_n(\"compose_done\", frame.len() as f64);\n", before=True)

L = TUI / "src/view/layout.rs"
patch(L, "    pub(crate) fn layout_pass(&mut self, width: usize) -> TranscriptLayout {",
      "        pa_types::io_trace::mark_n(\"layout_start\", self.chat.len() as f64);\n")
patch(L, "        let total = offsets.last().copied().unwrap_or(splash.len()) + tail.len();",
      "        pa_types::io_trace::mark_n(\"layout_done\", total as f64);\n")

AV = TUI / "src/agents_view.rs"
av_src = pathlib.Path(AV).read_text()
a1 = "        let saved = client\n            .request_supervisor_with_id("
assert av_src.count(a1) == 1
av_src = av_src.replace(a1, "        pa_types::io_trace::mark(\"saved_fetch_sent\");\n" + a1, 1)
a2 = "        let _ = ui_tx.send(input);"
assert av_src.count(a2) == 1
av_src = av_src.replace(a2, "        pa_types::io_trace::mark(\"saved_fetch_done\");\n" + a2, 1)
pathlib.Path(AV).write_text(av_src)
print("patched agents_view.rs: saved catalog fetch marks")
print("PATCH_DONE")
