#!/usr/bin/env python3
"""The io_open decompose runner: legs x fixtures x arms, probes at block
boundaries (I/O advisory v1.0), every trial its own process tree."""
import json, os, subprocess, sys, time, pathlib

BIN_TIP = "/root/bins/tip/prime-agent"
BIN_PROBE = "/root/bins/probe/prime-agent"
OUT = pathlib.Path("/root/results-io")
TRIALS = pathlib.Path("/root/trials-io")

def probe(label):
    res = {"label": label}
    for name, args in (("fsync", "/root/io_lane/probe-fsync.py /root/probe-fsync.bin 24"),
                       ("fresh", "/root/io_lane/probe-fresh.py /root/probe-fresh 40")):
        r = subprocess.run(["python3", *args.split()[0:1]] if False else ["bash","-c",f"python3 {args}"],
                           capture_output=True, text=True)
        res[name] = r.stdout.strip() or r.stderr.strip()[-200:]
    r = subprocess.run(["bash","-c","python3 -c 'import time; t=time.monotonic_ns(); x=0\nfor i in range(1000000): x=(x*31+17)&0xFFFFFFFF' 2>/dev/null || true"], capture_output=True, text=True)
    print("PROBE", label, json.dumps(res), flush=True)
    return res

def run_trial(leg, fx_label, fx_path, arm, idx):
    tdir = TRIALS / f"{leg}-{fx_label}-{arm}-{idx:02d}"
    if tdir.exists():
        import shutil; shutil.rmtree(tdir)
    binary = BIN_TIP if arm == "tip" else BIN_PROBE
    cmd = ["python3", "/root/io_lane/io_open_bench.py",
           "--trial-dir", str(tdir), "--binary", binary,
           "--fixture", fx_path, "--fixture-label", fx_label,
           "--leg", leg, "--label", f"{leg}-{fx_label}-{arm}-{idx}"]
    if fx_label.startswith("fx-mid"):
        cmd += ["--needle-chat", "add curated session blacklist"]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    print(f"TRIAL {leg} {fx_label} {arm} {idx} rc={r.returncode}", flush=True)
    print((r.stdout or "")[-800:], flush=True)
    if r.returncode != 0:
        print("STDERR", (r.stderr or "")[-1500:], flush=True)
    return r.returncode

def main():
    matrix = json.loads(sys.argv[1])
    OUT.mkdir(parents=True, exist_ok=True)
    TRIALS.mkdir(parents=True, exist_ok=True)
    probe_log = open(OUT / "probes.jsonl", "a")
    probe_log.write(json.dumps(probe("pre")) + "\n"); probe_log.flush()
    for block in matrix:
        leg, fx_label, fx_path, arms, n = block
        for i in range(n):
            for arm in arms:
                rc = run_trial(leg, fx_label, fx_path, arm, i)
                if rc != 0:
                    print(f"BLOCK-FAIL {leg} {fx_label} {arm} {i}", flush=True)
        probe_log.write(json.dumps(probe(f"after-{leg}-{fx_label}")) + "\n"); probe_log.flush()
    probe_log.write(json.dumps(probe("post")) + "\n"); probe_log.flush()
    print("MATRIX_DONE", flush=True)

main()
