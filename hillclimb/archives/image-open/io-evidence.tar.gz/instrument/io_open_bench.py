#!/usr/bin/env python3
"""image-open lane PTY benchmark driver: the session-open decompose.

Legs (one process tree per trial):
  open     --resume <fixture path>  -> the plain session open (create/resume
            -> worker load -> attach wire -> fold -> rebuild -> first frame)
  agents   --resume (bare) -> the agents view (the roster catalog scan) ->
            ENTER on the fixture row -> the attach path -> first frame

Captures: exact PTY bytes, sync-frame accounting, needle walls, worker-socket
appearance grid, /proc RSS samples, and the env-gated phase trace
(PRIME_AGENT_IO_TRACE) shared by the TUI + supervisor + worker processes.
"""
import argparse, fcntl, hashlib, json, os, select, shutil, signal, socket, struct, subprocess, sys, termios, threading, time

SYNC_BEGIN = b"\x1b[?2026h"
SYNC_END = b"\x1b[?2026l"


def sha256f(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def spin_calibration(iters=1_000_000):
    t0 = time.monotonic_ns()
    x = 0
    for i in range(iters):
        x = (x * 31 + 17) & 0xFFFFFFFF
    return {"iters": iters, "ns": time.monotonic_ns() - t0, "check": x}


def loadavg():
    with open("/proc/loadavg") as fh:
        return fh.read().strip()


def proc_snapshot():
    out = {}
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        pid = int(entry)
        try:
            with open(f"/proc/{pid}/comm") as fh:
                comm = fh.read().strip()
            if "prime-agent" not in comm:
                continue
            with open(f"/proc/{pid}/stat") as fh:
                stat = fh.read()
            rpar = stat.rindex(")")
            rest = stat[rpar + 2:].split()
            rss = None
            with open(f"/proc/{pid}/status") as fh:
                for line in fh:
                    if line.startswith("VmRSS:"):
                        rss = int(line.split()[1])
                        break
            out[pid] = {"pid": pid, "ppid": int(rest[1]), "state": rest[0], "comm": comm,
                        "utime_j": int(rest[11]), "stime_j": int(rest[12]), "rss_kb": rss}
        except (OSError, ValueError, IndexError):
            continue
    return out


class Sampler:
    def __init__(self, interval=0.05):
        self.interval = interval
        self.samples = []
        self.stop_flag = False

    def run(self):
        while not self.stop_flag:
            t = time.monotonic_ns()
            self.samples.append({"t_ns": t, "procs": proc_snapshot()})
            time.sleep(self.interval)


class SocketWatcher:
    """100ms grid listing of the worker socket dir; records appearances."""
    def __init__(self, socket_dir, t0):
        self.socket_dir = socket_dir
        self.t0 = t0
        self.events = []
        self.seen = set()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        while not self.stop.is_set():
            try:
                for name in os.listdir(self.socket_dir):
                    if name.startswith("worker-") and name not in self.seen:
                        self.seen.add(name)
                        self.events.append((time.monotonic_ns(), name))
            except OSError:
                pass
            time.sleep(0.1)

    def finish(self):
        self.stop.set()
        self.thread.join(timeout=1.0)
        return [{"t_ns": t, "name": n} for t, n in self.events]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trial-dir", required=True)
    ap.add_argument("--binary", required=True)
    ap.add_argument("--fixture", required=True)
    ap.add_argument("--fixture-label", default="")
    ap.add_argument("--leg", choices=["open", "agents"], required=True)
    ap.add_argument("--rows", type=int, default=40)
    ap.add_argument("--cols", type=int, default=120)
    ap.add_argument("--needle-chat", default="Goal cleared.")
    ap.add_argument("--needle-agents", default="viz-builder")
    ap.add_argument("--settle-s", type=float, default=2.0)
    ap.add_argument("--quiet-ms", type=int, default=400)
    ap.add_argument("--max-wait-s", type=float, default=120.0)
    ap.add_argument("--label", default="")
    ap.add_argument("--drop-caches", action="store_true", help="sync + drop page caches before the trial (cold-cache legs)")
    args = ap.parse_args()

    if args.drop_caches:
        subprocess.run(["bash", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches"], capture_output=True)
        meta_drop = True
    else:
        meta_drop = False

    trial = os.path.abspath(args.trial_dir)
    os.makedirs(trial, exist_ok=True)
    agent_dir = os.path.join(trial, "agent")
    session_dir = os.path.join(trial, "sessions")
    os.makedirs(agent_dir, exist_ok=True)
    os.makedirs(session_dir, exist_ok=True)
    dsocket = os.path.join(trial, "daemon.sock")
    with open(os.path.join(agent_dir, "settings.json"), "w") as fh:
        json.dump({"onboardingShown": True}, fh)

    fixture = os.path.abspath(args.fixture)
    fixture_sha = hashlib.sha256(open(fixture, "rb").read()).hexdigest()
    header = json.loads(open(fixture, "rb").readline())
    session_file = os.path.join(session_dir, f"{header['id']}.jsonl")
    shutil.copy(fixture, session_file)
    seed_sha_pre = sha256f(session_file)

    binary_sha = hashlib.sha256(open(args.binary, "rb").read()).hexdigest()
    trace_path = os.path.join(trial, "trace.jsonl")

    env = dict(os.environ)
    env.update({
        "TERM": "xterm-256color",
        "PRIME_AGENT_CODING_AGENT_DIR": agent_dir,
        "PRIME_AGENT_SESSION_DIR": session_dir,
        "PRIME_AGENT_DAEMON_SOCKET": dsocket,
        "PI_OFFLINE": "1",
        "TMUX": "",
        "RLM_DEPTH": "",
        "PRIME_AGENT_IO_TRACE": trace_path,
    })
    for k in list(env):
        if k.startswith("PRIME_AGENT_WORKER") or "WORKER_" in k or k == "PRIME_AGENT_LEASE_OWNER_ID":
            del env[k]

    meta = {
        "drop_caches": meta_drop,
        "label": args.label,
        "leg": args.leg,
        "binary_sha256": binary_sha,
        "fixture": fixture,
        "fixture_label": args.fixture_label,
        "fixture_sha256": fixture_sha,
        "seed_sha_pre": seed_sha_pre,
        "session_file": session_file,
        "rows": args.rows, "cols": args.cols,
        "needle_chat": args.needle_chat, "needle_agents": args.needle_agents,
    }

    cal_pre = spin_calibration()
    la_pre = loadavg()

    daemon_log = open(os.path.join(trial, "daemon.log"), "wb")
    supervisor = subprocess.Popen(
        [args.binary, "--mode", "daemon", "--daemon-socket", dsocket],
        env=env, stdin=subprocess.DEVNULL, stdout=daemon_log, stderr=subprocess.STDOUT,
        cwd=trial,
    )
    sock_deadline = time.monotonic() + 30
    sock_live = False
    while time.monotonic() < sock_deadline:
        if os.path.exists(dsocket):
            probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                probe.connect(dsocket)
                sock_live = True
            except OSError:
                pass
            finally:
                probe.close()
            if sock_live:
                break
        if supervisor.poll() is not None:
            break
        time.sleep(0.02)
    assert sock_live, "supervisor socket never answered a live connect"

    worker_socket_dir = os.path.join(os.environ.get("TMPDIR", "/tmp"), "prime-agent-0")
    os.makedirs(worker_socket_dir, exist_ok=True)

    master, slave = os.openpty()
    fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack("HHHH", args.rows, args.cols, 0, 0))
    t0 = time.monotonic_ns()

    if args.leg == "open":
        tui_argv = [args.binary, "--cwd", trial, "--resume", session_file]
    else:
        tui_argv = [args.binary, "--cwd", trial, "--resume"]
    tui = subprocess.Popen(tui_argv, env=env, stdin=slave, stdout=slave, stderr=slave,
                           preexec_fn=os.setsid)
    os.close(slave)

    watcher = SocketWatcher(worker_socket_dir, t0)
    sampler = Sampler(0.05)
    sam_thread = threading.Thread(target=sampler.run, daemon=True)
    sam_thread.start()

    raw = open(os.path.join(trial, "raw.pt"), "wb", buffering=0)
    chunks = []
    frames = []
    sightings = {}
    buf = b""
    frame_open = False
    frame_begin_t = None
    frame_offset = 0
    raw_offset = [0]
    scan_tail = [b""]
    t_first_byte = [None]
    state = {"phase": None, "leg_start_ns": None, "last_frame_t": None,
             "leg_bytes": 0, "leg_frames": 0}

    needle_chat = args.needle_chat.encode()
    needle_agents = args.needle_agents.encode()

    def scan_chunk(data, t_now):
        nonlocal buf, frame_open, frame_begin_t, frame_offset
        chunks.append((t_now, len(data), raw_offset[0]))
        raw_offset[0] += len(data)
        raw.write(data)
        if t_first_byte[0] is None:
            t_first_byte[0] = t_now
        if state["leg_start_ns"] is not None:
            state["leg_bytes"] += len(data)
        buf += data
        scan_tail[0] = (scan_tail[0] + data)[-(1 << 17):]
        i = 0
        while True:
            bi = buf.find(SYNC_BEGIN, i)
            ei = buf.find(SYNC_END, i)
            if bi < 0 and ei < 0:
                break
            if bi >= 0 and (ei < 0 or bi < ei):
                if not frame_open:
                    frame_open = True
                    frame_begin_t = t_now
                    frame_offset = raw_offset[0] - len(data) + bi
                i = bi + len(SYNC_BEGIN)
            else:
                if frame_open:
                    frames.append({"t_begin_ns": frame_begin_t, "t_end_ns": t_now,
                                   "bytes": ei + len(SYNC_END),
                                   "begin_offset": frame_offset,
                                   "end_offset": raw_offset[0] - len(data) + ei + len(SYNC_END),
                                   "leg": state["phase"]})
                    if state["leg_start_ns"] is not None:
                        state["leg_frames"] += 1
                    state["last_frame_t"] = t_now
                    frame_open = False
                i = ei + len(SYNC_END)
        if i > 0:
            buf = buf[i:]
        if len(buf) > (1 << 20):
            buf = buf[-(1 << 17):]
        if state["phase"]:
            for tag, needle in (("chat", needle_chat), ("agents", needle_agents)):
                key = f"{state['phase']}:{tag}"
                if key not in sightings and needle in scan_tail[0]:
                    sightings[key] = t_now

    alive = {"ok": True}

    def pump(timeout=0.05):
        if not alive["ok"]:
            return False
        rl, _, _ = select.select([master], [], [], timeout)
        if master in rl:
            try:
                data = os.read(master, 1 << 20)
            except OSError:
                alive["ok"] = False
                return False
            if not data:
                alive["ok"] = False
                return False
            scan_chunk(data, time.monotonic_ns())
        return True

    def begin_leg(phase, key_bytes):
        state["phase"] = phase
        state["leg_frames"] = 0
        state["leg_bytes"] = 0
        state["leg_start_ns"] = time.monotonic_ns()
        state["last_frame_t"] = None
        scan_tail[0] = b""
        if key_bytes:
            os.write(master, key_bytes)

    def wait_leg(phase, needle_tag, timeout_s):
        deadline = time.monotonic() + timeout_s
        needle_key = f"{phase}:{needle_tag}"
        last_report = 0
        while time.monotonic() < deadline and alive["ok"]:
            pump()
            if time.monotonic() - last_report >= 2.0:
                last_report = time.monotonic()
                print(f"LEG {phase} needle={needle_tag} elapsed={time.monotonic() + timeout_s - deadline:.0f}s seen={needle_key in sightings} frames={state['leg_frames']} bytes={state['leg_bytes']}", flush=True)
            if needle_key in sightings:
                break
        if needle_key not in sightings:
            return False
        quiet_deadline = time.monotonic() + 30
        while time.monotonic() < quiet_deadline and alive["ok"]:
            pump()
            since = ((time.monotonic_ns() - state["last_frame_t"]) / 1e6
                     if state["last_frame_t"] is not None else 1e9)
            if since >= args.quiet_ms:
                break
        settle_until = time.monotonic() + args.settle_s
        while time.monotonic() < settle_until and alive["ok"]:
            pump()
        return True

    legs = {}
    completed = {}
    if args.leg == "open":
        begin_leg("open_chat", b"")
        completed["open_chat"] = wait_leg("open_chat", "chat", args.max_wait_s)
        legs["open_chat"] = state["leg_start_ns"]
    else:
        begin_leg("agents_view", b"")
        completed["agents_view"] = wait_leg("agents_view", "agents", args.max_wait_s)
        legs["agents_view"] = state["leg_start_ns"]
        begin_leg("agents_to_chat", b"\r")
        completed["agents_to_chat"] = wait_leg("agents_to_chat", "chat", args.max_wait_s)
        legs["agents_to_chat"] = state["leg_start_ns"]

    # exit: ctrl+c pair (the exit guard)
    try:
        os.write(master, b"\x03")
        time.sleep(0.4)
        os.write(master, b"\x03")
    except OSError:
        pass
    exit_deadline = time.monotonic() + 15
    while time.monotonic() < exit_deadline:
        if not pump():
            break
        if tui.poll() is not None:
            break
    rc = tui.poll()
    if rc is None:
        try:
            os.killpg(os.getpgid(tui.pid), signal.SIGKILL)
        except OSError:
            pass
        tui.wait()
        rc = -9

    sampler.stop_flag = True
    watcher.finish()
    time.sleep(0.15)
    for _ in range(10):
        pump(0.05)
    samples = sampler.samples
    worker_sockets = watcher.finish()

    raw.close()
    os.close(master)

    seed_sha_post = sha256f(session_file) if os.path.exists(session_file) else None

    try:
        subprocess.run([args.binary, "shutdown", "--force", "--daemon-socket", dsocket],
                       env=env, capture_output=True, timeout=15)
    except Exception:
        pass
    try:
        supervisor.wait(timeout=10)
    except subprocess.TimeoutExpired:
        supervisor.kill()
        supervisor.wait()
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        try:
            with open(f"/proc/{entry}/cmdline", "rb") as fh:
                cmdline = fh.read().decode(errors="replace")
        except OSError:
            continue
        argv0 = cmdline.split("\0")[0]
        if "prime-agent" in argv0 and trial in cmdline and int(entry) not in (os.getpid(), supervisor.pid):
            try:
                os.kill(int(entry), signal.SIGKILL)
            except OSError:
                pass

    cal_post = spin_calibration()
    la_post = loadavg()

    with open(os.path.join(trial, "frames.jsonl"), "w") as fh:
        for f in frames:
            fh.write(json.dumps(f) + "\n")
    with open(os.path.join(trial, "samples.json"), "w") as fh:
        json.dump(samples, fh)

    summary = {}
    for phase, needle_tag in (("open_chat", "chat"), ("agents_view", "agents"), ("agents_to_chat", "chat")):
        key = f"{phase}:{needle_tag}"
        if key in sightings:
            summary[phase] = {
                "spawn_to_needle_ms": round((sightings[key] - t0) / 1e6, 1),
                "key_to_needle_ms": round((sightings[key] - legs[phase]) / 1e6, 1) if phase in legs else None,
            }
    out = {
        "meta": meta,
        "t0_ns": t0,
        "ttff_ms": round((t_first_byte[0] - t0) / 1e6, 1) if t_first_byte[0] else None,
        "completed": completed,
        "sightings_ns": {k: v for k, v in sightings.items()},
        "summary": summary,
        "frames": len(frames),
        "bytes_out": raw_offset[0],
        "worker_sockets": worker_sockets,
        "seed_sha_post": seed_sha_post,
        "tui_rc": rc,
        "calibration": {"pre": cal_pre, "post": cal_post, "loadavg_pre": la_pre, "loadavg_post": la_post},
    }
    with open(os.path.join(trial, "trace.json"), "w") as fh:
        json.dump(out, fh, indent=1)
    print(json.dumps({"trial": trial, "completed": completed, "summary": summary, "ttff_ms": out["ttff_ms"]}))


if __name__ == "__main__":
    main()
