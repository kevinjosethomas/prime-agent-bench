#!/usr/bin/env python3
"""Phase-ledger analysis for one io_open_bench trial directory."""
import json, sys, pathlib

trial = pathlib.Path(sys.argv[1])
trace = json.load(open(trial / "trace.json"))
meta = trace["meta"]

recs = []
tp = trial / "trace.jsonl"
if tp.exists():
    for line in open(tp):
        try:
            recs.append(json.loads(line))
        except Exception:
            pass

procs = {}
for r in recs:
    if r.get("anchor"):
        procs[r["pid"]] = r["argv"]
pid_role = {}
for pid, argv in procs.items():
    if "--mode daemon" in argv and "worker" not in argv:
        pid_role[pid] = "supervisor"
    elif "--mode worker" in argv or "worker" in argv:
        pid_role[pid] = "worker"
    elif "--cwd" in argv:
        pid_role[pid] = "tui"
    else:
        pid_role[pid] = "other"

marks = {}  # (pid, phase) -> (wall_ms, t_ms, v, s)
seq = []
for r in recs:
    if r.get("anchor"):
        continue
    key = (r["pid"], r["phase"])
    rec = {"wall": r["wall_ms"], "t": r["t_ms"], "v": r.get("v"), "s": r.get("s"), "pid": r["pid"]}
    marks.setdefault(key, []).append(rec)
    seq.append((r["wall_ms"], r["pid"], r["phase"], r.get("v")))

def first(role, phase):
    for (pid, ph), lst in marks.items():
        if ph == phase and pid_role.get(pid) == role:
            return lst[0]
    return None

def span(role, a, b):
    ra, rb = first(role, a), first(role, b)
    if ra and rb:
        return round(rb["wall"] - ra["wall"], 1)
    return None

def val(role, phase):
    r = first(role, phase)
    return r.get("v") if r else None

out = {
    "trial": str(trial), "label": meta.get("label"), "leg": meta["leg"],
    "fixture_label": meta.get("fixture_label"),
    "ttff_ms": trace.get("ttff_ms"),
    "summary": trace.get("summary"),
    "completed": trace.get("completed"),
    "phases": {
        "tui_open_start_wall": (first("tui","open_start") or {}).get("wall"),
        "tui_connected": span("tui","open_start","connected"),
        "tui_create_wall": span("tui","create_sent","create_done"),
        "tui_attach_wire": span("tui","attach_sent","attach_done"),
        "wire_msgs": val("tui","attach_wire_msgs"),
        "tui_fold": span("tui","attach_done","reconstructed"),
        "tui_roster": span("tui","reconstructed","roster_done"),
        "tui_hb": span("tui","roster_done","hb_done"),
        "tui_bash": span("tui","hb_done","bash_done"),
        "tui_stats": span("tui","bash_done","stats"),
        "tui_rebuild": span("tui","stats","rebuilt"),
        "tui_first_frame": span("tui","rebuilt","frame_done"),
        "layout_entries": val("tui","layout_start"),
        "layout_rows_total": val("tui","layout_done"),
        "compose_rows": val("tui","compose_done"),
        "worker_store_open": span("worker","store_open_start","store_open_done"),
        "worker_scan": span("worker","store_open_start","store_window_open"),
        "worker_rows": val("worker","store_rows"),
        "worker_persist": span("worker","create_persist_start","create_persist_done"),
        "worker_attach_build": span("worker","attach_in","attach_built"),
        "worker_attach_msgs": val("worker","attach_msgs_n"),
        "sf_scan_jsonl_bytes": val("worker","sf_scan_done"),
        "sf_scan_ranges": val("worker","sf_scan_ranges"),
        "sf_retained": val("worker","sf_retained_rows"),
        "sf_ctx_msgs": val("worker","ctx_msgs"),
        "sf_open_span": span("worker","sf_open_start","sf_scan_done"),
        "ctx_span": span("worker","ctx_build_start","ctx_msgs"),
        "supervisor_list_wall": span("supervisor","list_start","list_done") if False else None,
    },
    "list_files": [],
}
# supervisor list per-file records
lf = {}
for (pid, ph), lst in marks.items():
    if ph == "list_file" and pid_role.get(pid) == "supervisor":
        for rec in lst:
            lf.setdefault(rec["s"], {"bytes": None, "ms": []})
for (pid, ph), lst in marks.items():
    if pid_role.get(pid) != "supervisor":
        continue
    if ph == "list_file_bytes":
        for rec in lst:
            pass
out["list_files"] = None
# per-file ms+bytes by order: list_file(s=name) followed by list_file_ms + list_file_bytes
per_file = []
cur = None
for wall, pid, ph, v in sorted(seq):
    if pid_role.get(pid) != "supervisor":
        continue
    if ph == "list_file":
        cur = {"name": None, "ms": [], "bytes": []}
        per_file.append(cur)
    elif ph == "list_file_ms" and cur is not None:
        cur["ms"].append(v)
    elif ph == "list_file_bytes" and cur is not None:
        cur["bytes"].append(v)
out["list_files"] = per_file
print(json.dumps(out, indent=1))
