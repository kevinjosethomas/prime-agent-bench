//! Probe-only phase-trace instrument for measurement lanes (never ships):
//! env-gated via `PRIME_AGENT_IO_TRACE=<path>`; every mark appends one
//! JSONL record carrying the pid, the process-local monotonic offset,
//! the wall clock, and the phase. Unset -> one env read, then no-ops.
use std::io::Write;
use std::sync::{Mutex, OnceLock};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

struct State {
    file: Mutex<std::fs::File>,
    anchor: Instant,
}

static STATE: OnceLock<Option<State>> = OnceLock::new();

fn state() -> Option<&'static State> {
    STATE
        .get_or_init(|| {
            let path = std::env::var("PRIME_AGENT_IO_TRACE").ok()?;
            let file = std::fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(path)
                .ok()?;
            let argv = std::env::args().collect::<Vec<_>>().join(" ").replace('"', "'");
            let st = State {
                file: Mutex::new(file),
                anchor: Instant::now(),
            };
            if let Ok(mut lock) = st.file.lock() {
                let _ = writeln!(
                    lock,
                    "{{\"pid\":{},\"anchor\":true,\"argv\":\"{argv}\"}}",
                    std::process::id()
                );
            }
            Some(st)
        })
        .as_ref()
}

fn wall_ms() -> f64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_secs_f64() * 1000.0)
        .unwrap_or_default()
}

fn emit(line: String) {
    let Some(state) = state() else { return };
    let t_ms = state.anchor.elapsed().as_secs_f64() * 1000.0;
    if let Ok(mut file) = state.file.lock() {
        let _ = writeln!(
            file,
            "{{\"pid\":{},\"t_ms\":{t_ms:.3},\"wall_ms\":{:.3},\"phase\":{}}}",
            std::process::id(),
            wall_ms(),
            line
        );
    }
}

/// One phase mark.
pub fn mark(phase: &str) {
    emit(format!("\"{phase}\""));
}

/// One phase mark carrying a numeric value.
pub fn mark_n(phase: &str, value: f64) {
    emit(format!("\"{phase}\",\"v\":{value:.3}"));
}

/// One phase mark carrying a short string payload.
pub fn mark_s(phase: &str, value: &str) {
    let escaped = value.replace('\\', "\\\\").replace('"', "\\\"");
    emit(format!("\"{phase}\",\"s\":\"{escaped}\""));
}
