#!/usr/bin/env python3
# compact-visibility analyzer v2: paired ABBA stats + parity oracles,
# pairing trials per block (baseline blocks excluded from the paired arms).
import json, os, re, statistics, sys

STATE = "/root/cvis-legs/state.json"

def load():
    return json.load(open(STATE))

def stats(vals):
    if not vals:
        return None
    vals = sorted(vals)
    return {"n": len(vals), "p50": round(statistics.median(vals), 3),
            "min": round(vals[0], 3), "max": round(vals[-1], 3)}

def norm(line):
    line = re.sub(r'"sessionId":"[^"]*"', '"sessionId":"<SID>"', line)
    line = re.sub(r'"sessionFile":"[^"]*"', '"sessionFile":"<PATH>"', line)
    line = re.sub(r'"timestamp":"[^"]*"', '"timestamp":"<TS>"', line)
    line = re.sub(r'"cwd":"[^"]*"', '"cwd":"<CWD>"', line)
    line = re.sub(r'"id":"[0-9a-f]{8}"', '"id":"<EID>"', line)
    line = re.sub(r'"parentId":"[0-9a-f]{8}"', '"parentId":"<EID>"', line)
    line = re.sub(r'"firstKeptEntryId":"[0-9a-f]{8}"', '"firstKeptEntryId":"<EID>"', line)
    line = re.sub(r'"timestamp":[0-9]{13}', '"timestamp":<MS>', line)
    return line

def row_norm(row):
    if not isinstance(row, dict):
        return json.dumps(row, sort_keys=True)
    drop = {k for k in row if "timestamp" in k.lower() or k in ("id", "parentId")}
    clean = {k: v for k, v in row.items() if k not in drop}
    return json.dumps(clean, sort_keys=True)

def main():
    st = load()
    blocks = [b for b in st["blocks"] if not b["block"].startswith("base-")]
    per_arm = {}
    for b in blocks:
        if not os.path.exists(b.get("out", "")):
            continue
        d = json.load(open(b["out"]))
        fx = "stock" if "stock" in b["block"] else "small"
        arm = "cand" if "-cand" in b["block"] else "base"
        for r in d["receipts"]:
            per_arm.setdefault((fx, arm), []).append(r)
    for fx in ("stock", "small"):
        for arm in ("base", "cand"):
            rs = per_arm.get((fx, arm), [])
            cs = [r["cs_ms"] for r in rs if r.get("cs_ms") is not None]
            ce = [r["ce_ms"] for r in rs if r.get("ce_ms") is not None]
            resp = [r["resp_ms"] for r in rs if r.get("resp_ms") is not None]
            print("RPC %s %s cs=%s" % (fx, arm, stats(cs)))
            print("RPC %s %s ce=%s resp=%s" % (fx, arm, stats(ce), stats(resp)))
    for fx in ("stock", "small"):
        base = per_arm.get((fx, "base"), [])
        cand = per_arm.get((fx, "cand"), [])
        if not base or not cand:
            continue
        print("== parity %s (base n=%d cand n=%d)" % (fx, len(base), len(cand)))
        # frame-stream identity: per-trial pair by index within the ABBA blocks
        same = diff = 0
        shown = 0
        for rb, rc in zip(base, cand):
            lb = [norm(l) for l in rb["raw_lines"]]
            lc = [norm(l) for l in rc["raw_lines"]]
            if len(lb) != len(lc):
                print("  FRAME_COUNT_DIFF trial %s n=%d vs %s n=%d" % (rb["trial"], len(lb), rc["trial"], len(lc)))
                diff += 1
                continue
            ok = True
            for i, (a, b) in enumerate(zip(lb, lc)):
                if a != b:
                    if shown < 2:
                        p = next((j for j in range(min(len(a), len(b))) if a[j] != b[j]), min(len(a), len(b)))
                        print("  FRAME_DIFF %s idx=%d at byte %d:" % (rb["trial"], i, p))
                        print("    base: ...%s" % a[max(0, p-40):p+60])
                        print("    cand: ...%s" % b[max(0, p-40):p+60])
                        shown += 1
                    ok = False
                    break
            if ok:
                same += 1
            else:
                diff += 1
        print("PARITY frames %s identical_trials=%d differing_trials=%d" % (fx, same, diff))
        br = sorted(row_norm(r.get("compaction_row")) for r in base)
        cr = sorted(row_norm(r.get("compaction_row")) for r in cand)
        identical = br == cr
        print("PARITY compaction_row %s identical=%s" % (fx, identical))
        if not identical:
            for a, b in list(zip(br, cr))[:1]:
                if a != b:
                    print("  base=%s" % a[:400])
                    print("  cand=%s" % b[:400])
        print("SESSION %s base_rows=%s cand_rows=%s" % (
            fx,
            sorted(set((r["post_session"] or {}).get("rows") for r in base)),
            sorted(set((r["post_session"] or {}).get("rows") for r in cand))))
        okb = all(r.get("response_success") for r in base)
        okc = all(r.get("response_success") for r in cand)
        print("SUCCESS %s base=%s cand=%s" % (fx, okb, okc))
    print("PROBES %s" % [(p["tag"], (p.get("out") or "?").split()[1] if p.get("out") else "?") for p in st.get("probes", [])])

if __name__ == "__main__":
    main()
