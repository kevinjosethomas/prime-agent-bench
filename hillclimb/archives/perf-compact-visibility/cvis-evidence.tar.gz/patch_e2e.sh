#!/bin/bash
set -euxo pipefail
cd /root/prime-agent-cand/crates/pa-cli/tests
python3 - <<'EOF'
import re
p = 'rpc_mode_e2e.rs'
s = open(p).read()
s = s.replace('.args(["--mode", "rpc", "--resume", fixture])',
              '.args(["--mode", "rpc", "--resume", fixture.to_str().unwrap()])')
s = s.replace('let cs_ms = sent.elapsed().saturating_sub(cs_at.duration_since(sent)).as_millis_f64();',
              'let cs_ms = sent.elapsed().saturating_sub(cs_at.duration_since(sent)).as_secs_f64() * 1000.0;')
s = s.replace('let start_to_end_ms = ce_at.duration_since(cs_at).as_millis_f64();',
              'let start_to_end_ms = ce_at.duration_since(cs_at).as_secs_f64() * 1000.0;')
s = s.replace('let mut push = |rows: &mut String, row: &str| {',
              'let push = |rows: &mut String, row: &str| {')
open(p, 'w').write(s)
print('PATCHED')
EOF
cd /root/prime-agent-cand
source /root/.cargo/env
cargo fmt --check && echo FMT_GREEN
cargo test --release -p pa-cli --test rpc_mode_e2e 2>&1 | tail -14
