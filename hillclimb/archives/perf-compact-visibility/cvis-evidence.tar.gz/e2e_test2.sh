#!/bin/bash
set -euxo pipefail
source /root/.cargo/env
cd /root/prime-agent-cand
echo RPC_E2E_START
cargo test --release -p pa-cli --test rpc_mode_e2e 2>&1 | tail -14
echo RPC_E2E_DONE
