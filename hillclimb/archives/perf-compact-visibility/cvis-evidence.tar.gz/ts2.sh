#!/bin/bash
set -euxo pipefail
if ! pgrep -f "mock_provider.*8890" >/dev/null; then
  cd /root/bench-harness
  PYTHONPATH=/root/bench-harness nohup python3 -m bench.drivers.mock_provider /root/rpc-mock/rpc-script.json 8890 > /root/mock-ts.log 2>&1 &
  sleep 1.5
  head -1 /root/mock-ts.log
fi
cd /root
MOCK_BASE=http://127.0.0.1:8890/v1 python3 /root/cvis_probe.py 4 /root/.local/share/prime-agent/bin/prime-agent /root/rpc-fixtures/session-10mib.jsonl /root/cvis-legs/rpc/ts-stock.json
echo TS_LEG_DONE
