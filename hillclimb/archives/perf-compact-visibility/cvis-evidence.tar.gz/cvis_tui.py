#!/usr/bin/env python3
# compact-visibility TUI legs (wave-6): the first-client-visible-byte
# latency of the /compact loader through the REAL kitty-mode TUI over
# the daemon (worker) path.
#
# Launch shape = the tui-typing lane's proven PTYSession protocol
# (--offline --resume 10MiB, per-trial HOME/agent-dir/socket, mock
# provider via models.json); per-trial: sentinel wait, 3s settle, typed
# /compact (30ms inter-key), then the chunk-ledger first-byte search for
# the loader label, the loader-clear wait (compaction_end visible), and
# the settled screen snapshot (the arm-vs-arm screen oracle).
#
# Usage: cvis_tui.py <trials> <bin> <fixture> <out.json>
import hashlib, json, os, pathlib, shutil, subprocess, sys, time

sys.path.insert(0, "/root/bench-harness")
from bench.adapters.terminals.pty import PTYSession  # noqa: E402
from bench.core.env import scrubbed_env, write_models_json  # noqa: E402

MOCK_PORT = 8890
TRIALS_ROOT = "/root/cvis-tui-trials"
SENTINEL = "CORPUS-TAIL-9f3a1c70"
LOADER_TEXT = "Compacting context"

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def loadavg():
    with open("/proc/loadavg") as f:
        return float(f.read().split()[0])

def zombie_sweep():
    out = subprocess.run(["ps", "-eo", "pid,comm,args"], capture_output=True, text=True).stdout
    me = os.getpid()
    pids = []
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid, comm, args = parts
        pid = int(pid)
        if pid == me or "cvis_tui" in args:
            continue
        is_product = (comm.startswith("prime-agent")
                      or (comm in ("python", "python3") and "rlm.repl" in args))
        if is_product:
            pids.append(pid)
    for pid in pids:
        try:
            os.kill(pid, 15)
        except ProcessLookupError:
            pass
    if pids:
        time.sleep(1.5)
    return pids

def run_trial(i, binpath, fixture, root):
    tag = os.environ.get("CVIS_TUI_TAG", "x")
    trial = os.path.join(root, "tui-%s-%02d" % (tag, i))
    os.makedirs(trial, exist_ok=True)
    home = os.path.join(trial, "home")
    agent_dir = os.path.join(home, "agent")
    tmp = os.path.join(home, "tmp")
    for d in (agent_dir, tmp, os.path.join(home, ".prime")):
        os.makedirs(d, exist_ok=True)
    for name in ("settings.json", "auth.json"):
        src = os.path.join("/root/.prime/agent", name)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(agent_dir, name))
    # The trial's daemon must accept the mock model (the bench settings'
    # allowedModels blocks it) and must not fire the threshold
    # auto-compaction on the 10MiB resume (the loader must be the MANUAL
    # /compact's).
    settings_path = os.path.join(agent_dir, "settings.json")
    settings = {}
    if os.path.exists(settings_path):
        try:
            settings = json.load(open(settings_path))
        except ValueError:
            settings = {}
    settings["allowedModels"] = None
    settings["compaction"] = {"enabled": False}
    json.dump(settings, open(settings_path, "w"), indent=1)
    write_models_json(pathlib.Path(agent_dir), "http://127.0.0.1:%d/v1" % MOCK_PORT)
    fixture_copy = os.path.join(trial, "sess", "fixture.jsonl")
    os.makedirs(os.path.dirname(fixture_copy), exist_ok=True)
    shutil.copy(fixture, fixture_copy)
    src_sha = sha256_file(fixture)
    assert sha256_file(fixture_copy) == src_sha, "fixture prehash mismatch"
    sock = os.path.join(trial, "d.sock")
    env = {"HOME": home, "TMPDIR": tmp, "PRIME_AGENT_CODING_AGENT_DIR": agent_dir,
           "PRIME_API_KEY": "sk-bench-missing", "MOCK_BASE": "http://127.0.0.1:%d/v1" % MOCK_PORT}
    env = scrubbed_env(env)
    argv = [binpath, "--daemon-socket", sock,
            "--provider", "prime-inference", "--model", "mock-1",
            "--offline", "--resume", fixture_copy]
    receipt = {"trial": trial, "fixture_sha256": src_sha}
    zombie_sweep()
    while loadavg() > 1.0:
        time.sleep(2.0)
    app = PTYSession(argv, env=env, cwd=home, cols=120, rows=40)
    try:
        # sentinel: the resumed transcript's tail rendered
        t0 = time.perf_counter()
        sentinel_s = None
        while time.perf_counter() - t0 < 180:
            if SENTINEL in app.screen_text():
                sentinel_s = time.perf_counter() - t0
                break
            time.sleep(0.02)
        if sentinel_s is None:
            receipt["error"] = "sentinel never rendered"
            receipt["screen_dump"] = app.screen_text()[:3000]
            return receipt
        receipt["sentinel_s"] = round(sentinel_s, 2)
        time.sleep(3.0)
        receipt["screen_before"] = app.screen_text()
        if "Context compacted" in receipt["screen_before"] or LOADER_TEXT in receipt["screen_before"]:
            receipt["error"] = "pre-existing compaction state at screen_before (auto-compaction or stale session)"
            return receipt
        # type /compact then submit
        with app._lock:
            offset_before = (app.chunks[-1][1] if app.chunks else 0) - app.trimmed
        for ch in "/compact":
            app.send(ch)
            time.sleep(0.03)
        t_submit = app.send("\r")
        # first loader byte: the first chunk after submit whose raw bytes
        # contain the loader label
        loader_first_ms = None
        deadline = time.perf_counter() + 60.0
        while time.perf_counter() < deadline:
            with app._lock:
                for (t, end) in app.chunks:
                    if t < t_submit:
                        continue
                    start = 0
                    for (t2, end2) in app.chunks:
                        if t2 == t:
                            break
                        start = end2
                    seg = bytes(app.raw[max(0, start - app.trimmed):end - app.trimmed])
                    if LOADER_TEXT.encode() in seg:
                        loader_first_ms = (t - t_submit) * 1000.0
                        break
            if loader_first_ms is not None:
                break
            time.sleep(0.002)
        receipt["loader_first_ms"] = round(loader_first_ms, 3) if loader_first_ms is not None else None
        # loader clear = the compaction_end visible (loader gone)
        loader_clear_ms = None
        deadline = time.perf_counter() + 120.0
        while time.perf_counter() < deadline:
            screen = app.screen_text()
            if LOADER_TEXT not in screen:
                loader_clear_ms = (time.perf_counter() - t_submit) * 1000.0
                break
            time.sleep(0.005)
        receipt["loader_clear_ms"] = round(loader_clear_ms, 1) if loader_clear_ms is not None else None
        time.sleep(2.0)
        receipt["screen_after"] = app.screen_text()
        receipt["pty_bytes_after_submit"] = (app.chunks[-1][1] if app.chunks else 0)
        receipt["alive"] = app.alive()
    finally:
        try:
            app.kill_tree()
        except Exception:
            pass
        time.sleep(1.0)
    return receipt

def main():
    trials = int(sys.argv[1])
    binpath = os.path.abspath(sys.argv[2])
    fixture = sys.argv[3]
    out = sys.argv[-1]
    bin_sha = sha256_file(binpath)
    root = TRIALS_ROOT
    os.makedirs(root, exist_ok=True)
    receipts = []
    print("CVIS_TUI_START trials", trials, "bin_sha", bin_sha[:16], flush=True)
    for i in range(trials):
        print("TRIAL_START", i, flush=True)
        t0 = time.monotonic()
        r = run_trial(i, binpath, fixture, root)
        r["trial_wall_s"] = round(time.monotonic() - t0, 2)
        receipts.append(r)
        print("TRIAL %d sentinel=%.1f loader_first=%s clear=%s" % (
            i, r.get("sentinel_s", -1), r.get("loader_first_ms"), r.get("loader_clear_ms")), flush=True)
        time.sleep(2.0)
    with open(out, "w") as f:
        json.dump({"trials": trials, "binary_sha256": bin_sha, "fixture": fixture,
                   "receipts": receipts}, f, indent=1)
    import statistics
    vals = sorted(r.get("loader_first_ms") for r in receipts if r.get("loader_first_ms") is not None)
    if vals:
        print("STAT loader_first_ms n=%d p50=%.3f min=%.3f max=%.3f" % (
            len(vals), statistics.median(vals), vals[0], vals[-1]), flush=True)
    print("OUT %s" % out, flush=True)

if __name__ == "__main__":
    main()
