#!/usr/bin/env python3
# compact-visibility probe (wave-6 lane): the compaction_start client-
# visibility latency over the RPC stdio surface.
#
# Per-trial cold-resume legs over the REAL assembly (models.json -> offline
# mock), fleet conventions verbatim from the ctxrebuild decompose: fresh
# agent dir + home + tmp per trial, per-trial fixture prehash assert,
# binary sha assert, loadavg quiet gate, product-only zombie sweep,
# arrival-accurate frame pump (parse timestamps; window-bounded select,
# NEVER the select-park), full frame timeline with RAW frame bytes (the
# byte-identity oracle across arms), and the post-compact session rows
# (the compaction-content oracle).
#
# The metric: cs_ms = the compaction_start frame's arrival minus the
# compact command's send wall (the decompose's +48.2ms p50 finding); plus
# ce_ms (compaction_end arrival), resp_ms (the response = the command
# wall), and the start->end span.
#
# Usage: cvis_probe.py <trials> <bin> <fixture> <out.json>
import hashlib, json, os, pathlib, shutil, statistics, subprocess, sys, time

MOCK_PORT = 8890
MOCK_BASE = os.environ.get("MOCK_BASE", f"http://127.0.0.1:{MOCK_PORT}/v1")
TRIALS_ROOT = "/root/cvis-trials"
TRACE_ENV = "PA_COMPACTION_TRACE"
MOCK_LOG = "/root/rpc-mock/rpc-script.json.requests.jsonl"

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def write_models_json(agent_dir):
    agent_dir = pathlib.Path(agent_dir)
    agent_dir.mkdir(parents=True, exist_ok=True)
    models = {"providers": {"prime-inference": {
        "api": "openai-completions", "baseUrl": MOCK_BASE, "apiKey": "sk-bench",
        "models": [{"id": "mock-1", "name": "Mock 1", "api": "openai-completions",
                    "baseUrl": MOCK_BASE, "contextWindow": 128000, "maxTokens": 4096}]}}}
    (agent_dir / "models.json").write_text(json.dumps(models, indent=1))

def scrub_env(base):
    env = {}
    for k, v in base.items():
        if k.startswith(("PI_", "PRIME_", "UV_", "XDG_")):
            continue
        env[k] = v
    return env

def loadavg():
    with open("/proc/loadavg") as f:
        return float(f.read().split()[0])

def zombie_sweep():
    out = subprocess.run(["ps", "-eo", "pid,comm,args"], capture_output=True, text=True).stdout
    me = os.getpid()
    pids = []
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid, comm, args = parts
        pid = int(pid)
        if pid == me:
            continue
        is_product = (comm.startswith("prime-agent")
                      or (comm in ("python", "python3") and "rlm.repl" in args))
        if is_product:
            pids.append(pid)
    for pid in pids:
        try:
            os.kill(pid, 15)
        except ProcessLookupError:
            pass
    if pids:
        time.sleep(1.0)
    return pids

import threading, select

class Conn:
    def __init__(self, proc):
        self.proc = proc
        self.frames = []      # (wall, mono, obj, raw_line_bytes)
        self._raw_buf = b""
        self.stderr_tail = []
        self._stderr_thread = threading.Thread(target=self._drain_stderr, daemon=True)
        self._stderr_thread.start()
    def _drain_stderr(self):
        for raw in iter(self.proc.stderr.readline, b""):
            self.stderr_tail.append((time.time(), raw.decode(errors="replace")))
            if len(self.stderr_tail) > 4000:
                self.stderr_tail.pop(0)
    def _read_frames(self, timeout_s, idle_s=None, max_s=30.0):
        fd = self.proc.stdout.fileno()
        os.set_blocking(fd, False)
        t0 = time.monotonic()
        last = t0
        n = 0
        while True:
            now = time.monotonic()
            if now - t0 > min(timeout_s, max_s):
                break
            if idle_s is not None and now - last > idle_s:
                break
            budget = min(timeout_s, max_s) - (now - t0)
            ready, _, _ = select.select([fd], [], [], max(0.0, budget))
            if ready:
                try:
                    chunk = os.read(fd, 65536)
                except (BlockingIOError, OSError):
                    chunk = b""
                if chunk:
                    self._raw_buf += chunk
                    last = time.monotonic()
                while b"\n" in self._raw_buf:
                    raw, self._raw_buf = self._raw_buf.split(b"\n", 1)
                    if not raw.strip():
                        continue
                    try:
                        obj = json.loads(raw)
                    except ValueError:
                        continue
                    self.frames.append((time.time(), time.monotonic(), obj, raw))
                    n += 1
        return n, last
    def send(self, obj):
        self.proc.stdin.write((json.dumps(obj) + "\n").encode())
        self.proc.stdin.flush()
    def read_until_response(self, rid, timeout=180.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            before = len(self.frames)
            self._read_frames(timeout_s=0.01, max_s=0.01)
            for _, mono, obj, _ in self.frames[before:]:
                if obj.get("type") == "response" and obj.get("id") == rid:
                    return obj, mono
            if self.proc.poll() is not None and not self._raw_buf:
                raise RuntimeError("rpc exited rc=%s; stderr_tail=%s" % (
                    self.proc.returncode,
                    "".join(x[1] for x in self.stderr_tail)[-1500:]))
        raise TimeoutError("no response for %s in %ss; partial_buf=%r; frames=%s; stderr_tail=%s" % (
            rid, timeout, self._raw_buf[-300:],
            [(round(m, 2), o.get("type")) for _, m, o, _ in self.frames][-12:],
            "".join(x[1] for x in self.stderr_tail)[-1500:]))
    def drain_events(self, idle_s=0.35, max_s=10.0):
        _, last = self._read_frames(timeout_s=max_s, idle_s=idle_s, max_s=max_s)
        return last

def session_rows(path):
    if not os.path.exists(path):
        return None
    n = 0
    with open(path, "rb") as f:
        for _ in f:
            n += 1
    return {"rows": n, "bytes": os.path.getsize(path)}

def run_trial(i, binpath, fixture, root, trace=False):
    trial = os.path.join(root, "compact-%02d" % i)
    os.makedirs(trial, exist_ok=True)
    agent = os.path.join(trial, "agent")
    write_models_json(agent)
    for name in ("auth.json", "settings.json"):
        src = os.path.join("/root/.prime/agent", name)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(agent, name))
    proj = os.path.join(trial, "proj")
    home = os.path.join(trial, "home")
    tmp = os.path.join(trial, "tmp")
    for d in (proj, home, tmp):
        os.makedirs(d, exist_ok=True)
    fixture_copy = os.path.join(trial, "sess", "fixture.jsonl")
    os.makedirs(os.path.dirname(fixture_copy), exist_ok=True)
    shutil.copy(fixture, fixture_copy)
    src_sha = sha256_file(fixture)
    if sha256_file(fixture_copy) != src_sha:
        raise RuntimeError("fixture prehash mismatch")
    args = [binpath, "--mode", "rpc",
            "--provider", "prime-inference", "--model", "mock-1",
            "--daemon-socket", os.path.join(trial, "d.sock"),
            "--resume", fixture_copy]
    env = scrub_env(os.environ)
    env.update({"HOME": home, "TMPDIR": tmp,
                "PRIME_AGENT_CODING_AGENT_DIR": agent,
                "PRIME_API_KEY": "sk-bench",
                "RUST_LOG": "error",
                "PATH": "/root/.cargo/bin:/root/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"})
    if trace:
        env[TRACE_ENV] = os.path.join(trial, "compact-trace.jsonl")
    venv_env_path = os.path.join(TRIALS_ROOT, "venv-env.json")
    if os.path.exists(venv_env_path):
        env.update(json.load(open(venv_env_path)))
    else:
        env.update({"UV_CACHE_DIR": "/root/cvis-uv-cache",
                    "UV_PYTHON_INSTALL_DIR": "/root/cvis-uv-python"})
    receipt = {"trial": trial, "fixture_sha256": src_sha, "trace": trace}
    zombie_sweep()
    while loadavg() > 1.0:
        time.sleep(2.0)
    pre_session = session_rows(fixture_copy)
    t_spawn_wall, t_spawn_mono = time.time(), time.monotonic()
    proc = subprocess.Popen(args, cwd=proj, env=env,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    conn = Conn(proc)
    receipt["pre_session"] = pre_session
    try:
        rid = "rdy"
        conn.send({"type": "get_state", "id": rid})
        resp, resp_mono = conn.read_until_response(rid)
        receipt["ready_ms"] = (resp_mono - t_spawn_mono) * 1000.0
        state = resp.get("data") or {}
        receipt["ready_state"] = {"sessionId": state.get("sessionId"),
                                  "messageCount": state.get("messageCount"),
                                  "model": (state.get("model") or {}).get("id"),
                                  "success": resp.get("success")}
        cid = "cmd1"
        t0w, t0m = time.time(), time.monotonic()
        conn.send({"id": cid, "type": "compact"})
        r, t1m = conn.read_until_response(cid, timeout=300.0)
        resp_ms = (t1m - t0m) * 1000.0
        cs_mono = ce_mono = None
        for _, mono, obj, _ in conn.frames:
            t = obj.get("type")
            if t == "compaction_start" and cs_mono is None:
                cs_mono = mono
            elif t == "compaction_end" and ce_mono is None:
                ce_mono = mono
        receipt["cs_ms"] = (cs_mono - t0m) * 1000.0 if cs_mono is not None else None
        receipt["ce_ms"] = (ce_mono - t0m) * 1000.0 if ce_mono is not None else None
        receipt["resp_ms"] = resp_ms
        receipt["start_end_gap_ms"] = (ce_mono - cs_mono) * 1000.0 if (cs_mono and ce_mono) else None
        receipt["response_success"] = r.get("success")
        receipt["response_error"] = r.get("error")
        settle_last = conn.drain_events(idle_s=0.5, max_s=10.0)
        receipt["settle_ms"] = (settle_last - t0m) * 1000.0
        t0m3 = time.monotonic()
        proc.stdin.close()
        rc = proc.wait(timeout=120)
        receipt["stdin_close_to_exit_ms"] = (time.monotonic() - t0m3) * 1000.0
        receipt["exit_code"] = rc
    finally:
        if proc.poll() is None:
            proc.kill()
        try:
            proc.wait(timeout=10)
        except Exception:
            pass
        receipt["stderr_tail"] = "".join(x[1] for x in conn.stderr_tail)[-2000:]
    receipt["frames"] = [(w, round(m, 3), o.get("type"), o.get("id")) for w, m, o, _ in conn.frames]
    receipt["raw_lines"] = [raw.decode(errors="replace") for _, _, _, raw in conn.frames]
    receipt["post_session"] = session_rows(fixture_copy)
    compaction_row = None
    with open(fixture_copy, "rb") as f:
        for ln in f:
            try:
                row = json.loads(ln)
            except ValueError:
                continue
            if row.get("type") == "compaction":
                compaction_row = row
    receipt["compaction_row_present"] = compaction_row is not None
    receipt["compaction_row"] = compaction_row
    with open(os.path.join(trial, "receipt.json"), "w") as f:
        json.dump(receipt, f, indent=1)
    return receipt

def main():
    trials = int(sys.argv[1])
    binpath = os.path.abspath(sys.argv[2])
    fixture = sys.argv[3]
    out = sys.argv[-1]
    trace = os.environ.get("CVIS_TRACE") == "1"
    assert os.path.exists(binpath), binpath
    bin_sha = sha256_file(binpath)
    root = TRIALS_ROOT
    os.makedirs(root, exist_ok=True)
    receipts = []
    print("CVIS_PROBE_START trials", trials, "bin_sha", bin_sha[:16],
          "fixture", os.path.basename(fixture), "trace", trace, flush=True)
    for i in range(trials):
        print("TRIAL_START", i, flush=True)
        t0 = time.monotonic()
        r = run_trial(i, binpath, fixture, root, trace=trace)
        r["trial_wall_s"] = round(time.monotonic() - t0, 2)
        receipts.append(r)
        print("TRIAL %d ready=%.1f cs=%.2f ce=%.2f resp=%.1f ok=%s exit=%s" % (
            i, r.get("ready_ms", -1), r.get("cs_ms", -1), r.get("ce_ms", -1),
            r.get("resp_ms", -1), r.get("response_success"), r.get("exit_code")), flush=True)
        time.sleep(2.0)
    summary = {"trials": trials, "binary_sha256": bin_sha,
               "fixture": fixture, "trace": trace,
               "loadavg_last": loadavg(), "receipts": receipts}
    with open(out, "w") as f:
        json.dump(summary, f, indent=1)
    for key in ("ready_ms", "cs_ms", "ce_ms", "resp_ms", "start_end_gap_ms"):
        vals = sorted(r.get(key) for r in receipts if r.get(key) is not None)
        if vals:
            print("STAT %s n=%d p50=%.2f min=%.2f max=%.2f" % (
                key, len(vals), statistics.median(vals), vals[0], vals[-1]), flush=True)
    print("OUT %s" % out, flush=True)

if __name__ == "__main__":
    main()
