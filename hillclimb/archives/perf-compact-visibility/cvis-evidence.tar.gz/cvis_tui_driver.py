#!/usr/bin/env python3
# TUI legs driver: interleaved base/cand arms, sha-asserted swaps.
# Usage: cvis_tui_driver.py
import json, os, subprocess, sys, time

sys.path.insert(0, "/root/bench-harness")

BIN_BASE = "/root/bins/base/prime-agent"
BIN_CAND = "/root/bins/cand/prime-agent"
FIXTURE = "/root/rpc-fixtures/session-10mib.jsonl"
OUT = "/root/cvis-legs/tui"

def swap(arm):
    import hashlib, shutil
    src = BIN_BASE if arm == "base" else BIN_CAND
    h = hashlib.sha256(open(src, "rb").read()).hexdigest()
    dst = "/root/bin-active/prime-agent"
    if os.path.exists(dst):
        os.unlink(dst)
    shutil.copy(src, dst)
    os.chmod(dst, 0o755)
    got = hashlib.sha256(open(dst, "rb").read()).hexdigest()
    assert got == h, "swap sha mismatch"
    return h

def probe(tag):
    r = subprocess.run(["python3", "/root/probe_v09.py", "/root/cvis-legs/io-probe", tag, "20.0"],
                       capture_output=True, text=True, timeout=180)
    return (tag, (r.stdout.strip().split() or ["?"])[1] if r.stdout.strip() else "?")

def block(arm, n, tag):
    out = os.path.join(OUT, tag + ".json")
    sha = swap(arm)
    p = probe(tag + "-pre")
    print("BLOCK", tag, "arm", arm, "bin", sha[:16], "probe", p[1], flush=True)
    env = dict(os.environ)
    env["CVIS_TUI_TAG"] = tag
    r = subprocess.run(["python3", "/root/cvis_tui.py", str(n), "/root/bin-active/prime-agent",
                       FIXTURE, out], capture_output=True, text=True, env=env, timeout=3600)
    print(r.stdout[-2200:], flush=True)
    print("BLOCK_DONE", tag, "rc", r.returncode, flush=True)
    json.dump({"tag": tag, "arm": arm, "bin": sha, "probe": p, "rc": r.returncode,
               "out": out}, open(os.path.join(OUT, tag + ".meta.json"), "w"))

os.makedirs(OUT, exist_ok=True)
block("base", 3, "T1-base")
block("cand", 3, "T2-cand")
block("cand", 3, "T3-cand")
block("base", 3, "T4-base")
print("TUI_BATTERY_DONE", flush=True)
