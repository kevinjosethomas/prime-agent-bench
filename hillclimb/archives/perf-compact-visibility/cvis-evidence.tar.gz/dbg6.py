#!/usr/bin/env python3
# timestamped faux-child compact debug
import json, os, subprocess, sys, time, threading, select

BIN = sys.argv[1]
fixture = "/root/rpc-fixtures/session-10mib.jsonl"
script = json.dumps({"responses": [
    {"text": "corpus history summary: the scale corpus ran"},
    {"text": "corpus turn-prefix summary: the final marker"},
]})
home = "/tmp/dbg5/h"
os.makedirs(home + "/t", exist_ok=True)
os.makedirs("/tmp/dbg5/p", exist_ok=True)
env = dict(os.environ)
env.update({"HOME": home, "TMPDIR": home + "/t", "PRIME_AGENT_FAUX_SCRIPT": script, "RUST_LOG": "error"})
proc = subprocess.Popen([BIN, "--mode", "rpc", "--resume", fixture], cwd="/tmp/dbg5/p",
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
frames = []
def reader():
    buf = b""
    fd = proc.stdout.fileno()
    os.set_blocking(fd, False)
    while True:
        r, _, _ = select.select([fd], [], [], 0.5)
        if not r:
            if proc.poll() is not None:
                return
            continue
        try:
            chunk = os.read(fd, 65536)
        except OSError:
            return
        if not chunk:
            return
        t = time.monotonic()
        buf += chunk
        while b"\n" in buf:
            raw, buf = buf.split(b"\n", 1)
            if raw.strip():
                frames.append((t, json.loads(raw)))
threading.Thread(target=reader, daemon=True).start()
def send(obj):
    proc.stdin.write((json.dumps(obj) + "\n").encode())
    proc.stdin.flush()
send({"type": "get_state", "id": "rdy"})
deadline = time.monotonic() + 60
while time.monotonic() < deadline:
    for t, o in list(frames):
        if o.get("id") == "rdy":
            break
    else:
        time.sleep(0.005)
        continue
    break
t0 = time.monotonic()
send({"type": "compact", "id": "cmd1"})
deadline = time.monotonic() + 60
while time.monotonic() < deadline:
    for t, o in list(frames):
        if o.get("id") == "cmd1":
            print("RESPONSE_AT_MS", round((t - t0) * 1000, 2))
            break
    else:
        time.sleep(0.002)
        continue
    break
for t, o in frames:
    typ = o.get("type")
    if typ in ("compaction_start", "compaction_end"):
        print(typ, "AT_MS", round((t - t0) * 1000, 2))
proc.stdin.close()
proc.wait(timeout=30)
print("EXIT", proc.returncode)
