#!/usr/bin/env python3
# compact-visibility legs driver (VM top-level).
#
# Baseline-first battery (base arms only) then the paired ABBA (base vs
# candidate, sha-asserted unlink-then-copy binary swaps). I/O advisory
# v1.0 preflights pre/mid/post + before every block (PHASE MODEL,
# re-classified at every leg boundary; NO-CEILING in-leg stalls are
# regime evidence, labeled). Quiet gate + product-only zombie sweep per
# block; per-trial fixture prehash assert (in the probe).
#
# Usage: cvis_driver.py <phase>
#   io-pre / io-mid / io-post   probe_v09 preflight
#   baseline                    base arms: stock n=8 + 256kib n=6
#   abba                        A B B A blocks x (stock 4 + 256kib 3)
import fcntl, hashlib, json, os, shutil, statistics, subprocess, sys, time

_fh = open("/root/cvis-driver.lock", "a")
try:
    fcntl.flock(_fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    print("another driver holds the lock; exiting", flush=True)
    sys.exit(0)

BENCH = "/root/bench-harness"
BIN_BASE = "/root/bins/base/prime-agent"
BIN_CAND = "/root/bins/cand/prime-agent"
BIN_ACTIVE = "/root/bin-active/prime-agent"
FIXTURES = {"stock": "/root/rpc-fixtures/session-10mib.jsonl",
            "small": "/root/rpc-fixtures/session-256kib.jsonl"}
OUT = "/root/cvis-legs"
STATE = os.path.join(OUT, "state.json")
MOCK_PORT = 8890

def load_state():
    if os.path.exists(STATE):
        return json.load(open(STATE))
    os.makedirs(OUT, exist_ok=True)
    return {"blocks": [], "probes": []}

def save_state(st):
    json.dump(st, open(STATE, "w"), indent=1)

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

def loadavg():
    return float(open("/proc/loadavg").read().split()[0])

def quiet_gate(max_wait=300):
    t0 = time.monotonic()
    while loadavg() > 1.0 and time.monotonic() - t0 < max_wait:
        time.sleep(2.0)
    return loadavg()

def sweep():
    out = subprocess.run(["ps", "-eo", "pid=,comm=,args="], capture_output=True, text=True).stdout
    killed = []
    for line in out.splitlines()[1:]:
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid, comm, args = parts
        if comm.startswith("prime-agent") and "cvis_driver" not in args:
            killed.append(int(pid))
    for p in killed:
        try:
            os.kill(p, 9)
        except ProcessLookupError:
            pass
    if killed:
        time.sleep(1.0)
    return killed

def probe(tag):
    r = subprocess.run(["python3", "/root/probe_v09.py", "/root/cvis-legs/io-probe", tag, "20.0"],
                       capture_output=True, text=True, timeout=180)
    return {"tag": tag, "rc": r.returncode, "out": r.stdout.strip(),
            "err": r.stderr.strip()[-500:], "t": time.time()}

def swap(arm):
    # the ABBA unlink-then-copy swap: the active path's inode is replaced
    # (a running process keeps the old inode; the next exec sees the new)
    src = BIN_BASE if arm == "base" else BIN_CAND
    src_sha = sha256(src)
    os.makedirs(os.path.dirname(BIN_ACTIVE), exist_ok=True)
    if os.path.exists(BIN_ACTIVE):
        os.unlink(BIN_ACTIVE)
    shutil.copy(src, BIN_ACTIVE)
    os.chmod(BIN_ACTIVE, 0o755)
    got = sha256(BIN_ACTIVE)
    assert got == src_sha, "swap sha mismatch: %s != %s" % (got[:16], src_sha[:16])
    return src_sha

def probe_block(fixture_key, trials, block_id):
    st = load_state()
    done = {b["block"] for b in st["blocks"]}
    if block_id in done:
        print("SKIP", block_id, flush=True)
        return st
    p = probe("%s-pre" % block_id)
    st["probes"].append(p)
    save_state(st)
    quiet_gate()
    sweep()
    out = os.path.join(OUT, "rpc", block_id + ".json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    env = dict(os.environ)
    env["MOCK_BASE"] = "http://127.0.0.1:%d/v1" % MOCK_PORT
    args = ["python3", "/root/cvis_probe.py", str(trials), BIN_ACTIVE,
            FIXTURES[fixture_key], out]
    t0 = time.time()
    r = subprocess.run(args, capture_output=True, text=True, env=env, timeout=7200)
    rec = {"block": block_id, "fixture": fixture_key, "trials": trials,
           "rc": r.returncode, "wall_s": round(time.time() - t0, 1),
           "bin_sha_at_start": sha256(BIN_ACTIVE),
           "bin_sha_at_end": sha256(BIN_ACTIVE),
           "loadavg_after": loadavg(),
           "pre_probe": p.get("out") or p.get("err"),
           "out_tail": r.stdout[-3000:], "err_tail": r.stderr[-2000:], "out": out}
    st["blocks"].append(rec)
    save_state(st)
    print(json.dumps({k: rec[k] for k in ("block", "rc", "wall_s")}), flush=True)
    return st

MOCK_PROC = None

def mock_start():
    global MOCK_PROC
    out = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True, text=True).stdout
    for ln in out.splitlines():
        if "mock_provider" in ln and "cvis_driver" not in ln:
            try:
                os.kill(int(ln.split()[0]), 9)
            except (ProcessLookupError, ValueError):
                pass
            time.sleep(0.5)
    env = dict(os.environ)
    env["PYTHONPATH"] = BENCH
    MOCK_PROC = subprocess.Popen(["python3", "-m", "bench.drivers.mock_provider",
                                   "/root/rpc-mock/rpc-script.json", str(MOCK_PORT)],
                                  cwd=BENCH, env=env,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    line = MOCK_PROC.stdout.readline().decode().strip()
    if not line.isdigit():
        raise SystemExit("mock provider failed to start: %r" % line)
    print("MOCK_SERVER", line, flush=True)
    return int(line)

def main():
    phase = sys.argv[1]
    st = load_state()
    if phase in ("io-pre", "io-mid", "io-post"):
        p = probe(phase)
        st["probes"].append(p)
        save_state(st)
        print(p["out"] or p["err"])
        return
    if phase in ("baseline", "abba", "abba2"):
        mock_start()
    try:
        if phase == "abba2":
            # the pristine-fixture stock rerun: the first ABBA's stock arms
            # ran on a fixture a debug compact had appended to (6cdf9f13;
            # caught by the per-trial fixture prehash receipts) - rerun the
            # stock arms on the restored canonical fixture (dadaecfc)
            probe_block("stock", 4, "R1-stock-base")
            swap("cand")
            probe_block("stock", 4, "R2-stock-cand")
            probe_block("stock", 4, "R3-stock-cand")
            swap("base")
            probe_block("stock", 4, "R4-stock-base")
        if phase == "baseline":
            os.makedirs("/root/bin-active", exist_ok=True)
            s = swap("base")
            print("BASE_SHA", s[:16], flush=True)
            probe_block("stock", 8, "base-stock-1")
            probe_block("small", 6, "base-small-1")
        elif phase == "abba":
            probe_block("stock", 4, "A1-stock-base")
            swap("cand")
            probe_block("stock", 4, "B1-stock-cand")
            probe_block("stock", 4, "B2-stock-cand")
            swap("base")
            probe_block("stock", 4, "A2-stock-base")
            probe_block("small", 3, "A3-small-base")
            swap("cand")
            probe_block("small", 3, "B3-small-cand")
            probe_block("small", 3, "B4-small-cand")
            swap("base")
            probe_block("small", 3, "A4-small-base")
    finally:
        pass

if __name__ == "__main__":
    main()
